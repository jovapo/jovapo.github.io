
if(~exist('HOMECODE','var'))
    HOMECODE = pwd;
end

SetupEnv;

RunSample;