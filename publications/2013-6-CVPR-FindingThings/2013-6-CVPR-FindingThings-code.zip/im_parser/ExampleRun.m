sEnv;
SetupEnv;
dbNum = 6;
superparsingExampleRun = true;
SetUpConstants;

justDetectors=false;
if(~exist('loadDone','var') || loadDone == false)
    LoadData2;
end
loadDone = true;
testParams.Rs = Rs;

%% Train per-exemplar detectors
mineImsWithLabel=true; %do negative mining in images with the same label, restricting to only areas without that label (usually you would turn this off)
PreTrainDetectors;

%% compute region and detector dataterms for both test and training sets
temp = testParams.TestString;
placeHolder = cell(size(HOMELABELSETS));
testParams.TestString = 'RunOnTraining';
testParams.range = rangeTrain;
fullSPDesc{1} = LoadSegmentDesc(trainFileList,trainIndex{1},HOMEDATA,testParams.segmentDescriptors,testParams.K(1),testParams.segSuffix);
timing = ParseTestImagesWDetectors(HOMEDATA,HOMEDATA,HOMELABELSETS,trainFileList,trainGlobalDesc,trainFileList,trainGlobalDesc,trainIndex,trainCounts,labelPenality,Labels,classifiers,placeHolder,testParams,fullSPDesc);
    
testParams.TestString = temp;
testParams.range = rangeTest;
timing = ParseTestImagesWDetectors(HOMEDATA,HOMEDATA,HOMELABELSETS,testFileList,testGlobalDesc,trainFileList,trainGlobalDesc,trainIndex,trainCounts,labelPenality,Labels,classifiers,placeHolder,testParams,fullSPDesc);

%% Train combination SVM 
% after training look at Data\TestFolder\SVMs\results.txt to pick the best performing svm configuration
matlabpool
TrainDetectorSVM
matlabpool close;

%% perform smoothing
TestDetectorSVM;
EvaluateInOutDoor;
