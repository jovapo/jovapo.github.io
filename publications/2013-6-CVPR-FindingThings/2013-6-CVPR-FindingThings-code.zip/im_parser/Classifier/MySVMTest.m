function [ rates, pl, predictor ] = MySVMTest( testFeats,testLabels,svm )
[testFeats] = MySVMNormalize(testFeats,svm.params);
rates = zeros(length(svm.params.labelList)+2,2);
predictor = zeros(length(testLabels),length(svm.params.labelList));
if(isequal(svm.params.testFun, @liblinearpredict)||isequal(svm.params.testFun, @liblineardensepredict))
    aW =  zeros(size(testFeats,2),length(svm.model));
    for lndx = 1:length(svm.model)
        aW(:,lndx) = svm.model{lndx}.w'.*svm.model{lndx}.Label(1); 
    end
    predictor = testFeats*aW;
else
    parfor lndx = 1:length(svm.params.labelList)
        [a b p] = svm.params.testFun(ones(size(testLabels)),testFeats,svm.model{lndx});
        predictor(:,lndx) = p*svm.model{lndx}.Label(1);
    end
end
[a pl] = max(predictor,[],2);
pl = svm.params.labelList(pl);
if(nargout>2)
    p = min(predictor(:))*ones(size(predictor,1),max(svm.params.labelList));
    p(:,svm.params.labelList) = predictor;
    predictor = p;
end
rates = MySVMRates(pl,testLabels);
