function [ rates, pl, predictor ] = MySVMTestInMem( testFeats,testLabels,svm, memLim )

[temp] = MySVMNormalize(testFeats(1,:),svm.params);

memUsed = size(testFeats,1)*size(temp,2)*8;
split = ceil(memUsed/memLim);
cSz = ceil(size(testFeats,1)/split);

rates = zeros(length(svm.params.labelList)+2,2);
predictor = zeros(length(testLabels),max(svm.params.labelList));
pl = zeros(size(testLabels));
for s = 1:split
    %range = s:split:length(testLabels);
    range = ((s-1)*cSz+1):min((s*cSz),length(testLabels));
    [t, pl(range), predictor(range,:)] =  MySVMTest( testFeats(range,:),testLabels(range),svm);
end
rates = MySVMRates(pl,testLabels);
