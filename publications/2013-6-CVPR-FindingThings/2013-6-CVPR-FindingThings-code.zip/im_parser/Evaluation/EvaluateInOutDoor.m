[foo labelset] = fileparts(HOMELABELSETS{UseLabelSet(1)});
folds = dir_recurse(fullfile(HOMEDATA,testParams.TestString,testParams.MRFFold,labelset,'*'),1,0);
good = true;
if(~exist('careGood','var'))
    careGood = true;
end
if(careGood)
    for i = 1:length(folds)
        files = dir_recurse(fullfile(folds{i},'*.mat'),0,1);
        if(length(files)<length(testFileList))
            good = false;
            fprintf('Eval: %d missing files in: %s\n',length(testFileList)-length(files), folds{i});
            %break;
        end
    end
end
if(good)
    if(~exist('rangeN','var'));rangeN = [1 1];end
    clear metadata;
    EvaluateTests(HOMEDATA,HOMELABELSETS(UseLabelSet),{testParams.TestString},testParams.MRFFold,[],[],testParams.MRFFold,rangeN);
    if(exist('inoutEval','var') && inoutEval)
        metadata.inout = 'indoor';
        EvaluateTests(HOMEDATA,HOMELABELSETS(UseLabelSet),{testParams.TestString},[testParams.MRFFold 'indoor'],metadata,[],testParams.MRFFold,rangeN);
        metadata.inout = 'outdoor';
        EvaluateTests(HOMEDATA,HOMELABELSETS(UseLabelSet),{testParams.TestString},[testParams.MRFFold 'outdoor'],metadata,[],testParams.MRFFold,rangeN);
    end
end