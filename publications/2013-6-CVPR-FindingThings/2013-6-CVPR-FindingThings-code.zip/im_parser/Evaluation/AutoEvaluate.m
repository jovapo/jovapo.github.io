SetUpConstants;
EvaluateInOutDoor;