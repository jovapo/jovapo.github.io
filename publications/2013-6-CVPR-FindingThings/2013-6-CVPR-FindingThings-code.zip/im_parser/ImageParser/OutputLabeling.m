function  OutputLabeling(outFileName,L,labelList,S,names,Lobj,objClassList)
%OUTPUTMLLABELING Summary of this function goes here
%   Detailed explanation goes here
make_dir(outFileName);
if(exist('Lobj','var'))
    save(outFileName,'L','labelList','Lobj','objClassList');
else
    save(outFileName,'L','labelList');
end
if(~isempty(S)&&~isempty(names))
    [perPixelStat perLabelStat] = EvalPixelLabeling(L,labelList,S,names);
    metaData = [];
    save([outFileName '.cache'],'perPixelStat','perLabelStat','metaData','-mat');
end
end

