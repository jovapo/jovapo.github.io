function [a] = get_arg_2(fun)
[tmp,a] = fun();