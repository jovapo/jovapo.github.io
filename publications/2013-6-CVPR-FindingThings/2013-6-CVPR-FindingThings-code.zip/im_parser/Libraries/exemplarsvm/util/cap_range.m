function r = cap_range(r2,starter,ender)
r = min(r2,ender);
r = max(r,starter);
