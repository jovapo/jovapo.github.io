function polygonsout = ProjectDetectorPolygons(bbs, model_polygons)

polygonsout = struct('x',[],'y',[]);
if(size(bbs,1)>0)
    polygonsout(size(bbs,1),1).x = [];
    polygonsout(size(bbs,1),1).y = [];
end;
for i = 1:size(bbs,1)
    modelNdx = bbs(i,6);
    flipped = bbs(i,7);
    if(isfield(model_polygons{modelNdx},'polygon'))
        gtbb = model_polygons{modelNdx}.gt_box;
        if(isfield(model_polygons{modelNdx}.polygon,'pt'))
            poly.x = str2double({model_polygons{modelNdx}.polygon.pt.x});
            poly.y = str2double({model_polygons{modelNdx}.polygon.pt.y});
        else
            poly = model_polygons{modelNdx}.polygon;
        end
    elseif(ischar(model_polygons{modelNdx}(1).x))
        poly.x = str2double({model_polygons{modelNdx}.x});
        poly.y = str2double({model_polygons{modelNdx}.y});
        gtbb = [min(poly.x) min(poly.y) max(poly.x) max(poly.y)];
    else
        poly.x = model_polygons{modelNdx}.x;
        poly.y = model_polygons{modelNdx}.y;
        gtbb = [min(poly.x) min(poly.y) max(poly.x) max(poly.y)];
    end
    tbb = bbs(i,1:4);
    
    sx = (tbb(3)-tbb(1))/(gtbb(3)-gtbb(1));
    sy = (tbb(4)-tbb(2))/(gtbb(4)-gtbb(2));
    if(isnan(sx)||isnan(sy)||isinf(sx)||isinf(sy))
        continue;
    end
    tx = tbb(1) - gtbb(1);
    ty = tbb(2) - gtbb(2);
    polygonsout(i).x = double(poly.x-gtbb(1)).*sx+tbb(1);
    polygonsout(i).y = double(poly.y-gtbb(2)).*sy+tbb(2);
    if(flipped)
        polygonsout(i).x = (tbb(3)+tbb(1))/2-(polygonsout(i).x-(tbb(3)+tbb(1))/2);
    end
end