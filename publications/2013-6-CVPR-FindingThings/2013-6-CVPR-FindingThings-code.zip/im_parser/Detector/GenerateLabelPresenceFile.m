%LoadForDetectors;

labelPresenceMap = false(length(trainFileList),length(Labels{1}));
pfig = ProgressBar('Computing label Presence Map');
for i = 1:length(trainFileList)
    [fold base] = fileparts(trainFileList{i});
    xmlFile = fullfile(HOMEANNOTATIONS,fold,[base '.xml']);
    if(exist(xmlFile,'file'))
        [ann] = LMread(xmlFile);
        if(~isfield(ann,'object'))
            continue;
        end
        clsNums = str2double({ann.object.namendx});
        cls = {ann.object.name};
        clsNums2 = cellfun(@(x)find(strcmp(names,x)),cls);
        if(~all(clsNums==clsNums2))
            fprintf('Error in xml file. Wrong class number!\n');
            keyboard;
        end
    else
        glLabelFile = fullfile(HOMELABELSETS{1},fold,[base '.mat']);
        load(glLabelFile); %S names
        clsNums2 = unique(S);
        clsNums2(clsNums2==0) = [];
        if(max(clsNums2)>length(names))
            fprintf('Error in label map\n');
            keyboard;
        end
    end
    labelPresenceMap(i,unique(clsNums2)) = true;
    if(mod(i,10) == 0)
        ProgressBar(pfig,i,length(trainFileList));
    end
end
close(pfig);