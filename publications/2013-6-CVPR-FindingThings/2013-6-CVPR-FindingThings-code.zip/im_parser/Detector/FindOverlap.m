function overlap = FindOverlap(bbs1,bbs2)

overlap = zeros(size(bbs1,1),size(bbs2,1));

if isempty(bbs1) || isempty(bbs2)
  return;
end

x11 = bbs1(:,1);
y11 = bbs1(:,2);
x12 = bbs1(:,3);
y12 = bbs1(:,4);

x21 = bbs2(:,1);
y21 = bbs2(:,2);
x22 = bbs2(:,3);
y22 = bbs2(:,4);

area1 = (x12-x11+1) .* (y12-y11+1);
area2 = (x22-x21+1) .* (y22-y21+1);


for i = 1:size(bbs1,1)
  xx1 = max(x11(i), x21);
  yy1 = max(y11(i), y21);
  xx2 = min(x12(i), x22);
  yy2 = min(y12(i), y22);
  
  w = max(0.0, xx2-xx1+1);
  h = max(0.0, yy2-yy1+1);
  
  o = w.*h ./ (repmat(area1(i),size(w))-w.*h+area2);
  
  overlap(i,:) = o;
end
