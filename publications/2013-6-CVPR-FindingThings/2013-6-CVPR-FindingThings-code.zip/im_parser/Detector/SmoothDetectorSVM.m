
testName = 'trial';
baseFName = fullfile(fold,base);
Labels{1} = labelList;
imSP = superPixels;
MAX_COST = 10000;
MAX_EXPECTED = 10;
pn = 1./(1+exp(-predictors));
ps = sum(pn,2);
pn = -log(bsxfun(@rdivide,pn,ps));
dataCost{1} = pn./max(pn(:));
dataCost{1} = int32(dataCost{1}*MAX_COST);
clear params;
params.edgeParam = 11;
params.connected=8;
params.S{1} = S;
params.names{1} = names;
smoothOver = [2.^(0:5)];
%{
timerVar = 0;
for smoothing = smoothOver
    testName = sprintf('SigRowNorm-%s-SS%03d',testSVMList{i},smoothing);
    smoothingMatrix = smoothing*(ones(length(labelList))-eye(length(labelList)));
    timerVarTic = tic;
    [LabelPixels] = MultiLevelPixMRF(fullfile(TestFold,testParams.MRFFold),HOMELABELSETS,testName,baseFName,Labels,imSP,im,dataCost,smoothingMatrix,[],params);
    timerVar=timerVar+toc(timerVarTic);
    show(LabelPixels{1},1);
end
fieldName= ['timeMRFSigNorm' num2str(i)];
avgTime = timerVar/length(smoothOver);
if(~isfield(fileStats,fieldName) || fileStats.(fieldName)<avgTime)
    fileStats.(fieldName) = avgTime;
end
save(timingFile,'fileStats');
dataCost{1} = pn/10;
dataCost{1} = int32(dataCost{1}*MAX_COST);
smoothOver = [2.^(0:5)];
timerVar = 0;
for smoothing = smoothOver
    testName = sprintf('SigRow-%s-SS%03d',testSVMList{i},smoothing);
    smoothingMatrix = smoothing*(ones(length(labelList))-eye(length(labelList)));
    timerVarTic = tic;
    [LabelPixels] = MultiLevelPixMRF(fullfile(TestFold,testParams.MRFFold),HOMELABELSETS,testName,baseFName,Labels,imSP,im,dataCost,smoothingMatrix,[],params);
    timerVar=timerVar+toc(timerVarTic);
    show(LabelPixels{1},1);
end

pn = log(1+exp(-predictors));
dataCost{1} = pn./max(pn(:));
dataCost{1} = int32(dataCost{1}*MAX_COST);
smoothOver = [2.^(1:5)];
timerVar = 0;
for smoothing = smoothOver
    testName = sprintf('SigNorm-%s-SS%03d',testSVMList{i},smoothing);
    smoothingMatrix = smoothing*(ones(length(labelList))-eye(length(labelList)));
    timerVarTic = tic;
    [LabelPixels] = MultiLevelPixMRF(fullfile(TestFold,testParams.MRFFold),HOMELABELSETS,testName,baseFName,Labels,imSP,im,dataCost,smoothingMatrix,[],params);
    timerVar=timerVar+toc(timerVarTic);
    show(LabelPixels{1},1);
end
dataCost{1} = pn/5;
dataCost{1} = int32(dataCost{1}*MAX_COST);
smoothOver = [2.^(1:5)];
timerVar = 0;
for smoothing = smoothOver
    testName = sprintf('Sig-%s-SS%03d',testSVMList{i},smoothing);
    smoothingMatrix = smoothing*(ones(length(labelList))-eye(length(labelList)));
    timerVarTic = tic;
    [LabelPixels] = MultiLevelPixMRF(fullfile(TestFold,testParams.MRFFold),HOMELABELSETS,testName,baseFName,Labels,imSP,im,dataCost,smoothingMatrix,[],params);
    timerVar=timerVar+toc(timerVarTic);
    show(LabelPixels{1},1);
end

%}
dataCost{1} = (max(MAX_EXPECTED,max(predictors(:)))-predictors)./(MAX_EXPECTED*2);%-log(bsxfun(@rdivide,p,ps));%
dataCost{1} = int32(dataCost{1}*MAX_COST);
timerVar = 0;
for smoothing = smoothOver
    testName = sprintf('LinNorm-%s-SS%03d',testSVMList{i},smoothing);
    smoothingMatrix = smoothing*(ones(length(labelList))-eye(length(labelList)));
    timerVarTic = tic;
    [LabelPixels] = MultiLevelPixMRF(fullfile(TestFold,testParams.MRFFold),HOMELABELSETS,testName,baseFName,Labels,imSP,im,dataCost,smoothingMatrix,[],params);
    timerVar=timerVar+toc(timerVarTic);
    show(LabelPixels{1},1);
end
fieldName= ['timeMRF' num2str(i)];
avgTime = timerVar/length(smoothOver);
if(~isfield(fileStats,fieldName) || fileStats.(fieldName)<avgTime)
    fileStats.(fieldName) = avgTime;
end
save(timingFile,'fileStats');

clear pn dataConst;


