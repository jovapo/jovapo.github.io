
SetUpConstants;

justDetectors = true;
if(~exist('loadDone','var') || loadDone == false)
    LoadData2;
end
loadDone = true;

testParams.range = rangeTest;
if(justDetectors)
    placeHolder = cell(size(HOMELABELSETS));
    testParams.TestString = 'RunOnTraining';
    testParams.range = rangeTrain;
    timing = ParseTestImagesWDetectors(HOMEDATA,HOMETESTDATA,HOMELABELSETS,trainFileList,trainGlobalDesc,trainFileList,trainGlobalDesc,[],[],[],Labels,[],placeHolder,testParams,[]);
    
    %{
    placeHolder = cell(size(HOMELABELSETS));
    testParams.TestString = 'CVPR12Single';
    HOMECLASSIFIER = fullfile(HOMEDATA,'Classifier','ExemplarSingle');
    testParams.HOMECLASSIFIER = HOMECLASSIFIER;
    testParams.MaxModelPerCls = 100;
    %timing = ParseTestImagesWDetectors(HOMEDATA,HOMETESTDATA,HOMELABELSETS,testFileList,testGlobalDesc,trainFileList,trainGlobalDesc,[],[],[],Labels,[],placeHolder,testParams,[]);
    
    testParams.MaxModelPerCls = 1000;
    %timing = ParseTestImagesWDetectors(HOMEDATA,HOMETESTDATA,HOMELABELSETS,testFileList,testGlobalDesc,trainFileList,trainGlobalDesc,[],[],[],Labels,[],placeHolder,testParams,[]);
    
    testParams.MaxModelPerCls = 100;
    testParams.TestString = 'RunOnTrainingSingle';
    testParams.range = rangeTrain;
    timing = ParseTestImagesWDetectors(HOMEDATA,HOMETESTDATA,HOMELABELSETS,trainFileList,trainGlobalDesc,trainFileList,trainGlobalDesc,[],[],[],Labels,[],placeHolder,testParams,[]);
    
    testParams.MaxModelPerCls = 1000;
    timing = ParseTestImagesWDetectors(HOMEDATA,HOMETESTDATA,HOMELABELSETS,trainFileList,trainGlobalDesc,trainFileList,trainGlobalDesc,[],[],[],Labels,[],placeHolder,testParams,[]);
    
    
    testParams.TestString = 'CVPR12';
    HOMECLASSIFIER = fullfile(HOMEDATA,'Classifier','Exemplar');
    testParams.HOMECLASSIFIER = HOMECLASSIFIER;
    testParams.MaxModelPerCls = 100;
    testParams.range = rangeTest;
    %timing = ParseTestImagesWDetectors(HOMEDATA,HOMETESTDATA,HOMELABELSETS,testFileList,testGlobalDesc,trainFileList,trainGlobalDesc,[],[],[],Labels,[],placeHolder,testParams,[]);
    
    testParams.MaxModelPerCls = 1000;
    %timing = ParseTestImagesWDetectors(HOMEDATA,HOMETESTDATA,HOMELABELSETS,testFileList,testGlobalDesc,trainFileList,trainGlobalDesc,[],[],[],Labels,[],placeHolder,testParams,[]);
    
    testParams.MaxModelPerCls = 100;
    testParams.TestString = 'RunOnTraining';
    testParams.range = rangeTrain;
    timing = ParseTestImagesWDetectors(HOMEDATA,HOMETESTDATA,HOMELABELSETS,trainFileList,trainGlobalDesc,trainFileList,trainGlobalDesc,[],[],[],Labels,[],placeHolder,testParams,[]);
    
    testParams.MaxModelPerCls = 1000;
    timing = ParseTestImagesWDetectors(HOMEDATA,HOMETESTDATA,HOMELABELSETS,trainFileList,trainGlobalDesc,trainFileList,trainGlobalDesc,[],[],[],Labels,[],placeHolder,testParams,[]);
    %}
else
end


