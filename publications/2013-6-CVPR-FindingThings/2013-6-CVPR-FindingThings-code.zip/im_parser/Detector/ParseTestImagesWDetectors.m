function timing = ParseTestImagesWDetectors(HOMEDATA,HOMETESTDATA,HOMELABELSETS,testFileList,testGlobalDesc,trainFileList,trainGlobalDesc,trainIndex,trainCounts,labelPenality,Labels,classifiers,globalSVM,testParams,fullSPDesc)

TestFold = fullfile(HOMETESTDATA,testParams.TestString);
if(~exist('fullSPDesc','var'))
    fullSPDesc = cell(length(HOMELABELSETS),length(testParams.K));
end
probType = 'ratio';
if(isfield(testParams,'probType'))
    probType = testParams.probType;
end

if(~isfield(testParams,'segSuffix'))
    testParams.segSuffix = '';
end

HOME = fileparts(HOMEDATA);

dataset_params.datadir = HOMEDATA;
dataset_params.localdir = '';%fullfile(HOMEDATA,testParams.TestString);
dataset_params.display = 0;
detectorParams = esvm_get_default_params;
detectorParams.dataset_params = dataset_params;
%detectorParams.calibration_threshold = testParams.calibration_threshold;
lc = [rand([length(Labels{1}) 3]); [0 0 0]];

display = false;

%close all;
pfig = ProgressBar('Parsing Images');
range = 1:length(testFileList);
if(isfield(testParams,'range'))
    range = testParams.range;
end
timing = zeros(length(testFileList),4);
glSuffix = '';
%range = range(randperm(length(range)));
for i = range(:)'
    fprintf('Starting %s\n',testFileList{i});
    [fold base] = fileparts(testFileList{i});
    busyFile = fullfile(TestFold,'Busy',fold,base);
    if(isfield(testParams,'doneDir'))
        if(exist(fullfile(TestFold,'ML',testParams.doneDir,fold,[base '.mat']),'file'))
            fprintf('Already Done\n');
            continue;
        end
    end
    if(isfield(testParams,'BusyFold'))
        busyFile = fullfile(TestFold,testParams.BusyFold,fold,base);
    end
    if(exist(busyFile,'file'))
        continue;
    end
    %mkdir(busyFile);
    %try
    im = imread(fullfile(HOME,'Images',testFileList{i}));
    [ro co ch] = size(im);
    baseFName = fullfile(fold,base);
    timingFile = fullfile(TestFold,'Timing',fold,[base '.mat']);make_dir(timingFile);
    if(exist(timingFile,'file'))
        load(timingFile);
    else
        fileStats = [];
    end
    fileStats.imSize = [ro co];
    
    timeRetSet=tic;  [retInds rank]= FindRetrievalSet(trainGlobalDesc,SelectDesc(testGlobalDesc,i,1),TestFold,baseFName,testParams,glSuffix);  timeRetSet=toc(timeRetSet);
    if(~isfield(fileStats,'timeRetSet') || fileStats.timeRetSet<timeRetSet)
        fileStats.timeRetSet=timeRetSet;
    end
    rmInds = find(strcmp(trainFileList,testFileList{i}));
    if(isfield(testParams,'numFrames2Skip'))
        rmInds = [rmInds-testParams.numFrames2Skip:rmInds+testParams.numFrames2Skip];
    end
    [a keepInds] =setdiff(retInds,rmInds);
    keepInds = sort(keepInds);
    retInds = retInds(keepInds);
    
    svmstr = '';
    %% Short List Comp
    shortListMask = cell(size(Labels));
    for ls=1:length(HOMELABELSETS)
        if(~isempty(globalSVM{ls}))
            svmstr = testParams.SVMType;
            if(isfield(testParams,'SVMSoftMaxCutoff'))
                fs = svmShortListSoftMax(globalSVM(ls,:),SelectDesc(testGlobalDesc,i,1),testParams.SVMDescs);
                shortListInds = fs>=testParams.SVMSoftMaxCutoff{ls};
                if(all(~shortListInds))
                    [foo ind] = max(fs);
                    shortListInds(ind) = 1;
                end
            elseif(strcmp(testParams.SVMType,'SVMPerf'))
                dataFile = fullfile(HOMELABELSETS{ls},fold,[base '.mat']);
                load(dataFile); %S names
                shortListInds = zeros(size(names));
                ind = unique(S(:));
                ind(ind<1) = [];
                shortListInds(ind)=true;
            elseif(strcmp(testParams.SVMType,'SVMTop10'))
                [~, ind] = sort(trainCounts{ls},'descend');
                shortListInds = zeros(size(trainCounts{ls}));
                shortListInds(ind(1:min(end,10)))=true;
            elseif(strcmp(testParams.SVMType,'SVMLPBP'))
                svmstr = [testParams.SVMType num2str(testParams.svmLPBPItt)];
                [shortListInds] = svmShortListLPBPSoftMax(globalSVM{ls}(testParams.svmLPBPItt),SelectDesc(testGlobalDesc,i,1),testParams.SVMDescs);
            elseif(length(globalSVM{ls}) ==2)
                svmOutput = [];
                [shortListInds svmOutput.svm]  = svmShortList(globalSVM{ls}{1},SelectDesc(testGlobalDesc,i,1),testParams.SVMDescs,0);
                [shortListInds fs] = svmShortList(globalSVM{ls}{2},svmOutput,{'svm'},0);
            else
                shortListInds = svmShortList(globalSVM{ls},SelectDesc(testGlobalDesc,i,1),testParams.SVMDescs,0);
            end
        elseif(isfield(testParams,'SVMOutput'))
            shortListInds = testParams.SVMOutput{ls}(i,:)>0;
            minSL = 1;
            if(sum(shortListInds)<minSL)
                [a inds] = sort(testParams.SVMOutput{ls}(i,:),'descend');
                shortListInds(inds(1:minSL)) = true;
            end
            svmstr = [testParams.SVMType 'Min' num2str(minSL)];
            Labels{ls}(shortListInds)
        else
            shortListInds = ones(size(Labels{ls}));
        end
        shortListMask{ls} = shortListInds==1;
    end
    
    if(isfield(testParams,'RetrievalMetaMatch'))
        if(strcmp('GroundTruth',testParams.RetrievalMetaMatch))
            svmstr = [svmstr 'RetGT'];
            metaFields = fieldnames(testParams.TrainMetadata);
            totalMask = ones(size(retInds))==1;
            for f = 1:length(metaFields)
                mask = strcmp(testParams.TrainMetadata.(metaFields{f})(retInds),testParams.TestMetadata.(metaFields{f}){i});
                totalMask = mask&totalMask;
            end
            retInds = retInds(totalMask);
        end
        if(strcmp('SVM',testParams.RetrievalMetaMatch))
            svmstr = [svmstr 'RetSVM'];
            metaFields = fieldnames(testParams.TrainMetadata);
            totalMask = ones(size(retInds))==1;
            for f = 1:length(metaFields)
                mask = strcmp(testParams.TrainMetadata.(metaFields{f})(retInds),testParams.TestMetadataSVM.(metaFields{f}){i});
                totalMask = mask&totalMask;
            end
            retInds = retInds(totalMask);
        end
    end
    
    %% Superpixel dataterm
    if(~isempty(trainIndex))
        FGSet = 0;Kndx = 1;
        classifierStr = repmat('0',[1 length(HOMELABELSETS)]);
        preStr = '';
        probSuffix = sprintf('K%d',testParams.K(Kndx));
        clear imSP testImSPDesc;
        [testImSPDesc imSP] = LoadSegmentDesc(testFileList(i),[],HOMETESTDATA,testParams.segmentDescriptors,testParams.K,testParams.segSuffix);
        probPerLabel = cell(size(HOMELABELSETS));
        dataCost = cell(size(probPerLabel));
        for ls=1:length(HOMELABELSETS)
            [foo labelSet] = fileparts(HOMELABELSETS{ls});
            if(strcmp(labelSet,'LabelsForgroundBK'))
                FGSet = ls;
            end
            if(isempty(classifiers{ls}))
                if(testParams.retSetSize == length(trainFileList) )
                    retSetIndex = trainIndex{ls,Kndx};
                else
                    [retSetIndex descMask] = PruneIndex(trainIndex{ls,Kndx},retInds,testParams.retSetSize,testParams.minSPinRetSet);
                end
                suffix = sprintf('R%dK%dTNN%d',testParams.retSetSize,testParams.K(Kndx),testParams.targetNN);%nn%d  ,testParams.targetNN
                suffix = [suffix testParams.globalDescSuffix];
                suffix = [suffix glSuffix];
                probSuffix = [suffix '-sc' myN2S(testParams.smoothingConst) probType];
                labelNums = 1:length(trainCounts{ls});
                probPerLabel{ls} = GetAllProbPerLabel(fullfile(TestFold,labelSet),baseFName,probSuffix,retSetIndex,[],labelNums,trainCounts{ls,Kndx},probType,testParams.smoothingConst,1); %#ok<AGROW>
                if(~isempty(probPerLabel{ls}) && size(probPerLabel{ls},1)~=size(testImSPDesc.sift_hist_dial,1))
                    suffix = [suffix 'added'];
                    probPerLabel{ls} = [];
                end
                if(isempty(probPerLabel{ls}))
                    rawNNs = DoRNNSearch(testImSPDesc,[],fullfile(TestFold,labelSet),baseFName,suffix,testParams,Kndx);
                    if(isempty(rawNNs))
                        if(testParams.retSetSize >= length(trainFileList) )
                            if(isempty(fullSPDesc{ls,Kndx}))
                                fullSPDesc{ls,Kndx} = LoadSegmentDesc(trainFileList,retSetIndex,HOMEDATA,testParams.segmentDescriptors,testParams.K(Kndx),testParams.segSuffix);
                            end
                        end
                        if(isempty(fullSPDesc{ls,Kndx}))
                            retSetSPDesc = LoadSegmentDesc(trainFileList,retSetIndex,HOMEDATA,testParams.segmentDescriptors,testParams.K(Kndx),testParams.segSuffix);
                        else
                            retSetSPDesc = [];
                            for dNdx = 1:length(testParams.segmentDescriptors)
                                retSetSPDesc.(testParams.segmentDescriptors{dNdx}) = fullSPDesc{ls,Kndx}.(testParams.segmentDescriptors{dNdx})(descMask,:);
                            end
                        end
                        %timing(i,2)=toc;  rawNNs = DoRNNSearch(testImSPDesc,retSetSPDesc,fullfile(DataDir,labelSet),baseFName,suffix,testParams,Kndx);  timing(i,2)=toc-timing(i,2);
                        [rawNNs fileStats.timeNNSearch totalMatches] = DoRNNSearch(testImSPDesc,retSetSPDesc,fullfile(TestFold,labelSet),baseFName,suffix,testParams,Kndx);
                        fprintf('%03d: %d\n',i',totalMatches);
                    end
                    [probPerLabel{ls} fileStats.timeGetProb] = GetAllProbPerLabel(fullfile(TestFold,labelSet),baseFName,probSuffix,retSetIndex,rawNNs,labelNums,trainCounts{ls,Kndx},probType,testParams.smoothingConst,1);
                    save(timingFile,'fileStats');
                end

                %nomalize the datacosts for mrf. This is especiall important when using some classifier or when some labelsets are under represented
                probPerLabel{ls}(:,~shortListMask{ls}) = min(probPerLabel{ls}(:))-1;
                dataCost{ls} = testParams.maxPenality*(1-1./(1+exp(-(testParams.BConst(2)*probPerLabel{ls}+testParams.BConst(1)))));
                dataCost{ls}(:,~shortListMask{ls}) = testParams.maxPenality;
                %for k = 1:size(probPerLabel{ls},2)
                %    temp = mnrval(testParams.BConst,probPerLabel{ls}(:,k));
                %    dataCost{ls}(:,k) = testParams.maxPenality*(1-temp(:,1));
                %end
            else
                probCacheFile = fullfile(TestFold,'ClassifierOutput',[labelSet testParams.CLSuffix],[baseFName  '.mat']);
                classifierStr(ls) = '1';
                if(~exist(probCacheFile,'file'))
                    features = GetFeaturesForClassifier(testImSPDesc);
                    prob = test_boosted_dt_mc(classifiers{ls}, features);
                    make_dir(probCacheFile);save(probCacheFile,'prob');
                else
                    clear prob;
                    load(probCacheFile);
                end
                probPerLabel{ls} = prob;
                if(size(prob,2) == 1 && length(Labels{ls}) ==2)
                    probPerLabel{ls}(:,2) = -prob;
                end
                if(ls == FGSet)
                    probPerLabel{ls}(:,1) = probPerLabel{ls}(:,1);
                    probPerLabel{ls}(:,2) = probPerLabel{ls}(:,2);
                end

                %nomalize the datacosts for mrf. This is especiall important when using some classifier or when some labelsets are under represented
                probPerLabel{ls}(:,~shortListMask{ls}) = min(probPerLabel{ls}(:))-1;
                dataCost{ls} = testParams.maxPenality*(1-1./(1+exp(-(testParams.BConstCla(2)*probPerLabel{ls}+testParams.BConstCla(1)))));
                dataCost{ls}(:,~shortListMask{ls}) = testParams.maxPenality;
                %for k = 1:size(probPerLabel{ls},2)
                %    temp = mnrval(testParams.BConstCla,probPerLabel{ls}(:,k));
                %    dataCost{ls}(:,k) = testParams.maxPenality*(1-temp(:,1));
                %end
            end
        end

        fprintf('Finished SuperParsing\n');
    end
    
    %% Detector Dataterm
    retIndsSm = retInds(1:min(testParams.retSetSize,length(retInds)));
    ls = 1;
    min_val = -1;
    detectorSuffix = [testParams.ModelFold '-MM' myN2S(testParams.MaxModelPerCls,4) '-R' myN2S(testParams.retSetSize)];
    detectorDataSuffix = [detectorSuffix '-NMS' num2str(testParams.NMS)];
    dataResultFile = fullfile(TestFold,'ExemplarDataTerm',detectorDataSuffix,fold,[base '.mat']);
    detectionResultFile = fullfile(TestFold,'ExemplarDetectionResults',detectorDataSuffix,fold,[base '.mat']);
    testResultFile = fullfile(TestFold,'ExemplarResult',detectorSuffix,fold,[base '.mat']);
    clear dataTerm;
    if(true || ~exist(dataResultFile,'file') || ~exist(detectionResultFile,'file') || ~exist(testResultFile,'file'))
        %load(dataResultFile);
    %end
    %if(~exist('dataTerm','var'))
        clear test_struct polygons;
        if(exist(detectionResultFile,'file'))
            %load(detectionResultFile);
        end
        if(~exist('test_struct','var'))
            allModels = cell(0);
            fileStats.timeLoadDetectors = tic;
            for rNdx = 1:length(retIndsSm)
                [retFold retBase] = fileparts(trainFileList{retIndsSm(rNdx)});
                modelFile = fullfile(HOMETESTDATA,'Classifier','Exemplar',testParams.ModelFold,retFold,[retBase '.mat']);
                if(exist(modelFile,'file'))
                    load(modelFile);
                    models = AddPolyToModel(fullfile(HOME,'Annotations'),models,modelFile);
                    allModels = [allModels(:); models(:)];
                end
            end
            fileStats.timeLoadDetectors = toc(fileStats.timeLoadDetectors);
            modelCls = cellfun2(@(x)x.cls,allModels);
            [unmodelCls a mNdx] = unique(modelCls);
            fileStats.numDetRaw = length(modelCls);
            if(testParams.MaxModelPerCls>0)
                [a b] = UniqueAndCounts(mNdx);
                rmNdx = [];
                for ovNdx = find(b>testParams.MaxModelPerCls)'
                    ndx = find(mNdx == a(ovNdx));
                    rmNdx = [rmNdx; ndx(testParams.MaxModelPerCls+1:end)];
                end
                allModels(rmNdx) = [];
                modelCls(rmNdx) = [];
                [unmodelCls a mNdx] = unique(modelCls);
            end
            m2lnum = 1:length(unmodelCls);
            fileStats.numDetReduced = length(modelCls);
            for m2lNdx = 1:length(unmodelCls)
                m2lnum(m2lNdx) = find(strcmp(strtrim(unmodelCls{m2lNdx}),Labels{ls}));
            end
            modelLnum = m2lnum(mNdx);

            
            if(exist(testResultFile,'file'))
                load(testResultFile);
            else
                fileStats.timeDetect = tic;test_grid = esvm_detect_imageset({fullfile(HOME,'Images',testFileList{i})}, allModels, detectorParams); fileStats.timeDetect = toc(fileStats.timeDetect);
                fileStats.numDetect = size(test_grid{1}.coarse_boxes,1);
                save(timingFile,'fileStats');
                make_dir(testResultFile);save(testResultFile,'test_grid');
            end
            cls_test_grid = cell(size(Labels{ls}));
            for l = 1:length(Labels{ls});
                cls_test_grid{l} = test_grid{1};
                if(~isempty(cls_test_grid{l}.coarse_boxes))
                    rmNdx = modelLnum(cls_test_grid{l}.coarse_boxes(:,6))~=l;
                    cls_test_grid{l}.coarse_boxes(rmNdx,:) = [];
                    cls_test_grid{l}.bboxes(rmNdx,:) = [];
                end
            end
            M = [];
            detectorParams.do_nms = testParams.NMS;
            test_struct = esvm_pool_exemplar_dets(cls_test_grid, allModels, M, detectorParams);
            
            if(isfield(allModels{1}.polygon,'pt'))
                polygons = cellfun2(@(x) x.polygon.pt,allModels);
            else
                polygons = cellfun2(@(x) x.polygon,allModels);
            end
            make_dir(detectionResultFile);save(detectionResultFile,'test_struct','polygons');
        end
        %{-
        clear dataTermAvg;
        if(exist(dataResultFile,'file'))
            load(dataResultFile);
        else
            dataTerm = zeros([ro co length(Labels{ls})]);
            dataTermMax = zeros([ro co length(Labels{ls})]);
            fileStats.timeProjectDetectors = tic;
            for l = 1:length(test_struct.unclipped_boxes)
                [dt] = ProjectDetectorResponses(im,test_struct.final_boxes{l},polygons,min_val);
                dataTerm(:,:,l) = dt;
            end
            fileStats.timeProjectDetectors = toc(fileStats.timeProjectDetectors);
            save(timingFile,'fileStats');
            make_dir(dataResultFile);save(dataResultFile,'dataTerm','-v7.3');
        end
        %}0
    end
%     
%     
%     retIndsSm = retInds(1:min(testParams.retSetSize,length(retInds)));
%     
%     detectorSuffix = [testParams.ModelFold '-MM' myN2S(testParams.MaxModelPerCls,4) '-R' myN2S(testParams.retSetSize)];
%     detectorDataSuffix = [detectorSuffix '-NMS' num2str(testParams.NMS)];
%     dataResultFile = fullfile(TestFold,'ExemplarDataTerm',detectorDataSuffix,fold,[base '.mat']);
%     detectionResultFile = fullfile(TestFold,'ExemplarDetectionResults',detectorDataSuffix,fold,[base '.mat']);
%     clear dataTerm;
%     if(exist(dataResultFile,'file'))
%         load(dataResultFile);
%     end
%     if(~exist('dataTerm','var'))
%         clear test_struct polygons;
%         if(exist(detectionResultFile,'file'))
%             load(detectionResultFile);
%             continue;
%         end
%         if(~exist('test_struct','var'))
%             allModels = cell(0);
%             fileStats.timeLoadDetectors = tic;
%             for rNdx = 1:length(retIndsSm)
%                 [retFold retBase] = fileparts(trainFileList{retIndsSm(rNdx)});
%                 modelFile = fullfile(HOMETESTDATA,'Classifier','Exemplar',testParams.ModelFold,retFold,[retBase '.mat']);
%                 if(exist(modelFile,'file'))
%                     load(modelFile);
%                     models = AddPolyToModel(fullfile(HOME,'Annotations'),models,modelFile);
%                     allModels = [allModels(:); models(:)];
%                 end
%             end
%             fileStats.timeLoadDetectors = toc(fileStats.timeLoadDetectors);
%             modelCls = cellfun2(@(x)x.cls,allModels);
%             [unmodelCls a mNdx] = unique(modelCls);
%             fileStats.numDetRaw = length(modelCls);
%             if(testParams.MaxModelPerCls>0)
%                 [a b] = UniqueAndCounts(mNdx);
%                 rmNdx = [];
%                 for ovNdx = find(b>testParams.MaxModelPerCls)'
%                     ndx = find(mNdx == a(ovNdx));
%                     rmNdx = [rmNdx; ndx(testParams.MaxModelPerCls+1:end)];
%                 end
%                 allModels(rmNdx) = [];
%                 modelCls(rmNdx) = [];
%                 [unmodelCls a mNdx] = unique(modelCls);
%             end
%             m2lnum = 1:length(unmodelCls);
%             fileStats.numDetReduced = length(modelCls);
%             for m2lNdx = 1:length(unmodelCls)
%                 m2lnum(m2lNdx) = find(strcmp(strtrim(unmodelCls{m2lNdx}),Labels{ls}));
%             end
%             modelLnum = m2lnum(mNdx);
% 
%             testResultFile = fullfile(TestFold,'ExemplarResult',detectorSuffix,fold,[base '.mat']);
%             if(exist(testResultFile,'file'))
%                 load(testResultFile);
%             else
%                 fileStats.timeDetect = tic;test_grid = esvm_detect_imageset({fullfile(HOME,'Images',testFileList{i})}, allModels, detectorParams); fileStats.timeDetect = toc(fileStats.timeDetect);
%                 fileStats.numDetect = size(test_grid{1}.coarse_boxes,1);
%                 save(timingFile,'fileStats');
%                 make_dir(testResultFile);save(testResultFile,'test_grid');
%             end
%             cls_test_grid = cell(size(Labels{ls}));
%             for l = 1:length(Labels{ls});
%                 cls_test_grid{l} = test_grid{1};
%                 rmNdx = modelLnum(cls_test_grid{l}.coarse_boxes(:,6))~=l;
%                 cls_test_grid{l}.coarse_boxes(rmNdx,:) = [];
%                 cls_test_grid{l}.bboxes(rmNdx,:) = [];
%             end
%             M = [];
%             min_val = -1;
%             detectorParams.do_nms = testParams.NMS;
%             test_struct = esvm_pool_exemplar_dets(cls_test_grid, allModels, M, detectorParams);
% 
%             if(isfield(allModels{1}.polygon,'pt'))
%                 polygons = cellfun2(@(x) x.polygon.pt,allModels);
%             else
%                 polygons = cellfun2(@(x) x.polygon,allModels);
%             end
%             make_dir(detectionResultFile);save(detectionResultFile,'test_struct','polygons');
%             
%             if(display)
%                 all_bb = cell2mat(test_struct.final_boxes');
%                 rmLabel = find(strcmp(Labels{1},'null'),1);
%                 if(~isempty(rmLabel))
%                     all_bb(modelLnum(all_bb(:,6))==rmLabel,:) = [];
%                 end
%                 [a,b] = sort(all_bb(:,12),'descend');
%                 all_bb = all_bb(b(1:5),:);
%                 projPolys = ProjectDetectorPolygons(all_bb, allModels);
% 
%                 show(im,1);hold on;
%                 colors = uint8([255 0 0; 0 255 0; 0 0 255; 255 255 0; 255 0 255; 0 255 255; 0 0 0; 255 255 255]);
%                 for k = 1:size(all_bb,1)
%                     patch(projPolys(k).x,projPolys(k).y,'r','FaceColor','none','EdgeColor',double(colors(mod(k-1,8)+1,:))/255,'LineWidth',2)
%                 end
%                 legend(Labels{1}(modelLnum(all_bb(:,6))));
%                 drawnow;
%             end
%         end
%         %{
%         clear dataTermAvg;
%         if(exist(dataResultFile,'file'))
%             load(dataResultFile);
%         else
%             dataTerm = zeros([ro co length(Labels{ls})]);
%             dataTermMax = zeros([ro co length(Labels{ls})]);
%             fileStats.timeProjectDetectors = tic;
%             for l = 1:length(test_struct.unclipped_boxes)
%                 [dt dtm] = ProjectDetectorResponses(im,test_struct.final_boxes{l},allModels,min_val);
%                 dataTerm(:,:,l) = dt;
%             end
%             fileStats.timeProjectDetectors = toc(fileStats.timeProjectDetectors);
%             save(timingFile,'fileStats');
%             make_dir(dataResultFile);save(dataResultFile,'dataTerm');
%         end
%         %}
%     end
    
    fprintf('Finished Detectors\n');
    %% MRF Prep
    %{
    
    
    detectorDataSuffix = [testParams.plBetaType  '-' detectorDataSuffix];
    if(~isstruct(testParams.plBetas))
        clear dataTermMax dataTermAvg;
        dataCostPix = cell(size(probPerLabel));
        if(testParams.PixelMRF)
            spTransform = imSP;%SPtoSkel(imSP);%
            spTransform(spTransform==0) = size(probPerLabel{1},1)+1;
            for ls=1:length(HOMELABELSETS)
                temp = probPerLabel{ls};
                temp(end+1,:) = 0;
                dataCostPix{ls} = reshape(temp(spTransform,:),[size(imSP) length(Labels{ls})]);
            end
        end
        
        load(fullfile(HOMELABELSETS{ls},fold,[base '.mat']));%S names
        labelList = Labels{ls};
        
        [dta Lda] = max(dataCostPix{ls},[],3);
        testName = sprintf('AAASP-%s',detectorDataSuffix);
        outFileName = fullfile(DataDir,'ML','LabelsSemantic',testName,fold,[base '.mat']);
        L = Lda;
        OutputLabeling(outFileName,L,labelList,S,names);
        
        for ls=1:length(HOMELABELSETS)
            for l = 1:length(Labels{ls})
                pX = dataCostPix{ls}(:,:,l);
                pY = dataTerm(:,:,l);
                a = mnrval(testParams.plBetas(:,l),[pX(:) pY(:)],'model',testParams.betaModel,'interactions','on');
                dataCostPix{ls}(:,:,l) = reshape(a(:,1),size(pX));
            end
        end
        

        [~, Lda] = max(dataCostPix{ls},[],3);
        comboStr = ['2DSig-' sprintf('%.1f',testParams.plBetas(:,1))];
        testName = sprintf('%s-%s',comboStr,detectorDataSuffix);
        outFileName = fullfile(DataDir,'ML','LabelsSemantic',testName,fold,[base '.mat']);
        OutputLabeling(outFileName,Lda,labelList,S,names);
        
        
    else
    for ls=1:length(HOMELABELSETS)
        for l = 1:length(Labels{ls})
            dataCost{ls}(:,l) = 1./(1+exp(-(testParams.plBetas.prob(2,l)*probPerLabel{ls}(:,l)+testParams.plBetas.prob(1,l))));
            dataTerm(:,:,l) = 1./(1+exp(-(testParams.plBetas.detAdd(2,l)*dataTerm(:,:,l)+testParams.plBetas.detAdd(1,l))));
            %dataTermAvg(:,:,l) = 1./(1+exp(-(testParams.plBetas.detAvg(2,l)*dataTermAvg(:,:,l)+testParams.plBetas.detAvg(1,l))));
            %dataTermMax(:,:,l) = 1./(1+exp(-(testParams.plBetas.detMax(2,l)*dataTermMax(:,:,l)+testParams.plBetas.detMax(1,l))));
        end
    end
            
    dataCostPix = cell(size(probPerLabel));
    if(testParams.PixelMRF)
        spTransform = imSP;%SPtoSkel(imSP);%
        spTransform(spTransform==0) = size(dataCost{1},1)+1;
        for ls=1:length(HOMELABELSETS)
            temp = dataCost{ls};
            temp(end+1,:) = 0;
            dataCostPix{ls} = reshape(temp(spTransform,:),[size(imSP) length(Labels{ls})]);
        end
    end
    
    addDataCostPix = zeros(size(dataCostPix{ls}));
    if(isfield(testParams,'StuffLabels'))
        dataTerm(:,:,testParams.StuffLabels) = 0;
        dataTermMax(:,:,testParams.StuffLabels) = 0;
        dataTermAvg(:,:,testParams.StuffLabels) = 0;
        %addDataCostPix(:,:,testParams.StuffLabels) = 1-dataCostPix{ls}(:,:,testParams.StuffLabels)./testParams.maxPenality;
        detectorDataSuffix = ['Stf' num2str(sum(testParams.StuffLabels)) '-' detectorDataSuffix];
    end
    %% Output Labeling
    load(fullfile(HOMELABELSETS{ls},fold,[base '.mat']));%S names
    
    labelList = Labels{ls};
    
    [dt Ld] = max(dataTerm,[],3);
    testName = sprintf('Add-%s-Winf',detectorDataSuffix);
    outFileName = fullfile(DataDir,'ML','LabelsSemantic',testName,fold,[base '.mat']);
    L = Ld;
    OutputLabeling(outFileName,L,labelList,S,names);
    
    %{
    [~, Lda] = max(dataTermAvg,[],3);
    testName = sprintf('Avg-%s-Winf',detectorDataSuffix);
    outFileName = fullfile(DataDir,'ML','LabelsSemantic',testName,fold,[base '.mat']);
    OutputLabeling(outFileName,Lda,labelList,S,names);
    
    
    [dtm Ldm] = max(dataTermMax,[],3);
    testName = sprintf('Max-%s-Winf',detectorDataSuffix);
    outFileName = fullfile(DataDir,'ML','LabelsSemantic',testName,fold,[base '.mat']);
    L = Ldm;
    OutputLabeling(outFileName,L,labelList,S,names);
    %}
    
    [dta Lda] = max(dataCostPix{ls},[],3);
    testName = sprintf('AAASP-%s',detectorDataSuffix);
    outFileName = fullfile(DataDir,'ML','LabelsSemantic',testName,fold,[base '.mat']);
    L = Lda;
    OutputLabeling(outFileName,L,labelList,S,names);
    
    w = [4.^(-1:1)];
    for wNdx = 1:length(w)
        comboDataTerm = dataTerm.*w(wNdx) + addDataCostPix + dataCostPix{ls};
        [dt L] = max(comboDataTerm,[],3);
        %DrawImLabels(im,L,lc,Labels{ls},[],1,0,wNdx+7);
        %show(dt,wNdx+7+5);
        comboStr = 'Add';
        if(~testParams.UseBetas)
            comboStr = [comboStr '-' sprintf('%.1f',testParams.plBetas.detAdd(:,1))];
        end
        testName = sprintf('%s-%s-W%.2f',comboStr,detectorDataSuffix,w(wNdx));
        outFileName = fullfile(DataDir,'ML','LabelsSemantic',testName,fold,[base '.mat']);
        OutputLabeling(outFileName,L,labelList,S,names);
        %{
        comboDataTerm = dataTermAvg.*w(wNdx) + addDataCostPix + dataCostPix{ls};
        [dt L] = max(comboDataTerm,[],3);
        %DrawImLabels(im,L,lc,Labels{ls},[],1,0,wNdx+7);
        %show(dt,wNdx+7+5);
        comboStr = 'Avg';
        if(~testParams.UseBetas)
            comboStr = [comboStr '-' sprintf('%.1f',testParams.AvgBetas)];
        end
        testName = sprintf('%s-%s-W%.2f',comboStr,detectorDataSuffix,w(wNdx));
        outFileName = fullfile(DataDir,'ML','LabelsSemantic',testName,fold,[base '.mat']);
        OutputLabeling(outFileName,L,labelList,S,names);
        
        comboDataTerm = dataTermMax.*w(wNdx) + addDataCostPix + dataCostPix{ls};
        [dt L] = max(comboDataTerm,[],3);
        %DrawImLabels(im,L,lc,Labels{ls},[],1,0,wNdx+7);
        %show(dt,wNdx+7+5);
        comboStr = 'Max';
        if(~testParams.UseBetas)
            comboStr = [comboStr '-' sprintf('%.1f',testParams.MaxBetas)];
        end
        testName = sprintf('%s-%s-W%.2f',comboStr,detectorDataSuffix,w(wNdx));
        outFileName = fullfile(DataDir,'ML','LabelsSemantic',testName,fold,[base '.mat']);
        OutputLabeling(outFileName,L,labelList,S,names);
        %}
    end
    
    end
    %{
    adjFile = fullfile(HOMETESTDATA,'Descriptors',sprintf('SP_Desc_k%d%s',testParams.K,testParams.segSuffix),'sp_adjacency',[baseFName '.mat']);
    load(adjFile);
    useLabelSets = 1:length(HOMELABELSETS);
    
    meanSPColors = zeros(size(probPerLabel{1},1),ch);
    imFlat = reshape(im,[ro*co ch]);
    for spNdx = 1:size(meanSPColors,1)
        meanSPColors(spNdx,:) = mean(imFlat(imSP(:)==spNdx,:),1);
    end
    
    endStr = [];
    preStr = [preStr probSuffix glSuffix]; %testParams.CLSuffix
    for ls=1:length(HOMELABELSETS)
        if(testParams.weightBySize)
            [foo spSize] = UniqueAndCounts(imSP);
            dataCost{ls} = dataCost{ls}.*repmat(spSize(:),[1 size(dataCost{ls},2)])./mean(spSize);
        end
        dataCost{ls} = int32(dataCost{ls});
        dataCostPix{ls} = int32(dataCostPix{ls});
    end
    %}
    
    %}
    %% MRF Run
    %{
    for labelSmoothingInd = 1:length(testParams.LabelSmoothing)
        if(iscell(testParams.LabelSmoothing))
            labelSmoothing = testParams.LabelSmoothing{labelSmoothingInd};
            lsStr = myN2S(labelSmoothingInd,3);
        else
            labelSmoothing = repmat(testParams.LabelSmoothing(labelSmoothingInd),[length(dataCost) 3]);
            lsStr = myN2S(labelSmoothing(1),3);
        end
        for interLabelSmoothing  = testParams.InterLabelSmoothing
            interLabelSmoothingMat = repmat(interLabelSmoothing,size(labelPenality,1));
            for lPenNdx = 1:length(testParams.LabelPenality)
                if((sum(sum(labelSmoothing==0))==numel(labelSmoothing))&&lPenNdx>1); continue; end
                for ilPenNdx = 1:length(testParams.InterLabelPenality)
                    if(all(interLabelSmoothingMat(:)==0)&&ilPenNdx>1); continue; end
                    ilsStr = myN2S(interLabelSmoothing,3);
                    
                    etNdx = 1; epNdx = 1;
                    if(~testParams.PixelMRF)
                        endStr = sprintf('Seg WbS%s', num2str(testParams.weightBySize));
                    else
                        endStr = sprintf('Pix E%s EP%d Cn%d',testParams.edgeType{etNdx},testParams.edgeParam(epNdx),testParams.connected);
                    end
                    testName = sprintf('%s C%s %s S%s IS%s P%s IP%s %s%s',preStr,classifierStr,testParams.NormType,lsStr,ilsStr,...
                        testParams.LabelPenality{lPenNdx}(1:3),testParams.InterLabelPenality{ilPenNdx}(1:3),svmstr,endStr);
                                                
                    %testName = ['Pixel ' testName];
                    interLabelSmoothingMattemp = interLabelSmoothingMat;
                    if(FGSet>0 && interLabelSmoothingMat(FGSet,FGSet) < 1 && length(HOMELABELSETS)>1)
                        interLabelSmoothingMattemp(FGSet,:) = 1;
                        interLabelSmoothingMattemp(:,FGSet) = 1;
                    end

                    smoothingMatrix = BuildSmoothingMatrix(labelPenality,labelSmoothing(:,1),interLabelSmoothingMattemp,testParams.LabelPenality{lPenNdx},testParams.InterLabelPenality{ilPenNdx});
                    mrfParams = [];
                    mrfParams.labelSubSetsWeight = 0;
                    mrfParams.edgeType = testParams.edgeType{etNdx};
                    mrfParams.edgeParam = testParams.edgeParam(epNdx);
                    mrfParams.maxPenality = testParams.maxPenality;
                    mrfParams.connected = testParams.connected;
                    timing(i,4)=toc;
                    if(~testParams.PixelMRF)
                        [Ls Lsps] = MultiLevelSegMRF(fullfile(DataDir,testParams.MRFFold),HOMELABELSETS(useLabelSets),testName,baseFName,Labels,imSP,adjPairs,dataCost,smoothingMatrix,0,0);
                    else
                        [Ls Lsps] = MultiLevelPixMRF(fullfile(DataDir,testParams.MRFFold),HOMELABELSETS(useLabelSets),testName,baseFName,Labels,imSP,im,dataCostPix,smoothingMatrix,0,mrfParams);
                    end
                    timing(i,4)=toc-timing(i,4);
                    %for j=1:length(HOMELABELSETS);DrawImLabels(im,Ls{j},[rand([length(Labels{j}) 3]); [0 0 0]],Labels{j},[],1,0,j);end;show(im,7);
                end
            end
        end
    end
    %}
    ProgressBar(pfig,find(i==range),length(range));
    
    %end
    try
        %rmdir(busyFile);
    
    end
    save(timingFile,'fileStats');
end
close(pfig);

end


