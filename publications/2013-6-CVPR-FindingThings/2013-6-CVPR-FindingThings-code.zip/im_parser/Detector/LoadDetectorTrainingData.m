HOME = '~/CS/im_parser/LMSun';

HOMEIMAGES = fullfile(HOME,'Images');
HOMEANNOTATIONS = fullfile(HOME,'Annotations');
HOMELABELSETS = {fullfile(HOME,'LabelsSemantic')};
HOMEDATA = fullfile(HOME,'Data');
HOMEDESCRIPTOR = fullfile(HOMEDATA,'Descriptors');

DataFold = fullfile(HOMEDATA,'RunOnTraining');

%{-

%detectorFold = 'Model360-MM0100-R200-NMS0';
%parserFold = 'probPerLabelR200K200TNN80-SPscGistCoHist-sc01ratio';
detectorFold = 'Model1280-MM0100-R800-NMS0-CT0.01';
parserFold = 'probPerLabelR800K200TNN80-SPscGistCoHist-sc01ratio';
detFiles = dir_recurse(fullfile(DataFold,'ExemplarDataTerm',detectorFold,'*'),0);
%parserFiles = dir_recurse(fullfile(DataFold,'LabelsSemantic',parserFold,'*'),0);
suffix = [num2str(rangeN(1)) '-' num2str(rangeN(2))];
dataFile = fullfile(DataFold,['svmTrainingData-' suffix '.mat']);
if(exist(dataFile,'file'))
    load(dataFile);
else
    subSample = 111;
    for f = rangeN(1):rangeN(2):length(detFiles)
        [fold base] = fileparts(detFiles{f});
        fprintf('Starting %d: %s/%s\n',f,fold,base);
        try
            load(fullfile(DataFold,'ExemplarDataTerm',detectorFold,fold,[base '.mat'])); %dataTerm (ro x co x #l) dataTermMax
            load(fullfile(DataFold,'LabelsSemantic',parserFold,fold,[base '.mat'])); %probPerLabel (#SP x #l)
            load(fullfile(HOMEDATA,'Descriptors','SP_Desc_k200','super_pixels',fold,[base '.mat'])); %superPixels (ro x co)
            load(fullfile(HOMELABELSETS{1},fold,[base '.mat'])); %S (ro x co) names
        catch
            continue;
        end
        feats = probPerLabel(superPixels,:);
        feats = [feats reshape(dataTerm,[],size(dataTerm,3))];
        labels = S(:);
        feats(labels==0,:) = [];
        labels(labels==0) = [];
        feats = feats(1:subSample:end,:);
        labels = labels(1:subSample:end);
        allData(f).feats = feats;
        allData(f).labels = uint8(labels);
        fprintf('Finished %d: %s/%s\n',f,fold,base);
    end
    save(dataFile,'allData','-v7.3');
end