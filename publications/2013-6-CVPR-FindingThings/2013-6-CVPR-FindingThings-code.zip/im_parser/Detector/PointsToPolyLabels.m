function [ labels ] = PointsToPolyLabels( ann, X, Y, numL )

lNdx = arrayfun(@(x)str2double(x.namendx),ann.object);
%tic
labels = zeros(length(X),numL);
for k = 1:length(lNdx)
    [pX,pY] = getLMpolygon(ann.object(k).polygon);
    in = inpolygon(X,Y,pX,pY);
    labels(in,lNdx(k)) = true;
end
%toc
%{
tic
labels2 = zeros(length(X),numL);
for k = 1:length(lNdx)
    [pX,pY] = getLMpolygon(ann.object(k).polygon);
    in = inpoly([X(:) Y(:)],[pX(:) pY(:)]);
    labels2(in,lNdx(k)) = true;
end
toc
if(any(labels~=labels2))
    keyboard;
end
%}
end

