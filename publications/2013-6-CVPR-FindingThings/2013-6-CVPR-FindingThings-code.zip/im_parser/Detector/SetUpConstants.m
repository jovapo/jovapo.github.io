if(exist('superparsingExampleRun','var') && superparsingExampleRun)
    HOMEDIR = fileparts(mfilename('fullpath'));
    HOMEDIR = fileparts(HOMEDIR);
elseif(ispc())
    HOMEDIR = 'D:\im_parser';
else
    HOMEDIR = '~/CS/im_parser/';
end

clear testParams;
testParams.segmentDescriptors = {'centered_mask_sp','bb_extent','pixel_area',...'centered_mask', %Shape
    'absolute_mask','top_height',...'bottom_height', %Location
    'int_text_hist_mr','dial_text_hist_mr',...'top_text_hist_mr','bottom_text_hist_mr','right_text_hist_mr','left_text_hist_mr' %Texture
    'sift_hist_int_','sift_hist_dial','sift_hist_bottom','sift_hist_top','sift_hist_right','sift_hist_left'... %Sift
    'mean_color','color_std','color_hist','dial_color_hist',... %Color
    'color_thumb','color_thumb_mask','gist_int'}; %Appearance
testParams.MRFFold = 'MRF';
testParams.globalDescriptors = {'spatialPryScaled','colorGist','coHist'};
testParams.globalDescSuffix = '-SPscGistCoHist';
testParams.targetNN = 80;
testParams.smoothingConst = 1;
testParams.probType = 'ratio';
%testParams.Rs = Rs;
testParams.minSPinRetSet = 1500;
testParams.LabelSmoothing = [0];
testParams.LabelPenality = {'conditional'};%,'pots''conditional'
testParams.InterLabelSmoothing = [0];
testParams.InterLabelPenality = {'pots'};%,'conditional','metric'
testParams.BConstCla = [0; .5];
testParams.BConst = [0; .1];
testParams.NormType = 'B.5.1';
testParams.maxPenality = 1000;
testParams.PixelMRF = 1;
testParams.SVMType = 'SVMVal';%'SVMTrain';%'SVMTest';%'SVMRaw1.5';%
testParams.weightBySize = 1;
testParams.edgeType = {'norm'}; %,'canny','bse'
testParams.connected = 8;
testParams.edgeParam = [11];%5 5
testParams.smoothData = [0];
testParams.MaxModelPerCls = 100;
testParams.NMS = 0;
testParams.UseBetas = false;

testSVMList = [];
detectorFold = '';parserFold = '';
if(dbNum ==1)
    %camVid
    testParams.TestString = 'DetectorPreTrained';
    HOME = fullfile(HOMEDIR,'CamVid');
    HOMEDATA = fullfile(HOME,'Data');
    HOMELABELSETS = {fullfile(HOME,'LabelsSemanticSimple')};
    HOMEANNOTATIONS = fullfile(HOME,'Annotations');
    HOMECLASSIFIER = fullfile(HOMEDATA,'Classifier','Exemplar');
    HOMERUNONTRAINING = fullfile(HOMEDATA,'RunOnTraining');
    TestFold = fullfile(HOMEDATA,testParams.TestString);
    testParams.ModelFold = 'Model1280';
    max_mined_range = [468];
    testParams.ModelFold = ['Model' num2str(max_mined_range(end))];
    testParams.retSetSize = 200;
    testParams.segSuffix = '_vidSeg';
    testParams.K = 0;
    detectorFold = 'Model468-MM0100-R200-NMS0';
    parserFold = 'ClassifierOutputFull';
    svmFold = 'SVMs';
    
    trainSBin = 8;
    trainMaxScale = .5;
elseif(dbNum == 2)
    %siftflow
    testParams.TestString = 'Detector4Bin';
    HOME = fullfile(HOMEDIR,'siftFlowDetector');
    HOMEDATA = fullfile(HOME,'Data');
	HOMELABELSETS = {fullfile(HOME,'LabelsSemantic')};
    HOMEANNOTATIONS = fullfile(HOME,'Annotations');
    HOMECLASSIFIER = fullfile(HOMEDATA,'Classifier','Exemplar');
    HOMERUNONTRAINING = fullfile(HOMEDATA,'RunOnTraining');
    TestFold = fullfile(HOMEDATA,testParams.TestString);
    max_mined_range = [360 2488];
    testParams.ModelFold = ['Model' num2str(max_mined_range(end))];
    testParams.retSetSize = 200;
    testParams.segSuffix = [];
    testParams.K = 200;
    detectorFold = 'Model360-MM0100-R200-NMS0';
    parserFold = 'probPerLabelR200K200TNN80-SPscGistCoHist-sc01ratio';
    svmFold = 'SVMs';
    
    trainSBin = 4;
    trainMaxScale = 1;
    
    claParams.stopval = .001;
    claParams.num_iterations = 100;
    claParams.subSample = 600000;
    claParams.balancedsubSample = 1;
    claParams.testsetnum = 1;
    claParams.init_weight = 'cFreq';
elseif(dbNum ==3)
    %LMSun
    testParams.TestString = 'ObjectCounting';
    HOME = fullfile(HOMEDIR,'LMSun');
    HOMEDATA = fullfile(HOME,'Data');
	HOMELABELSETS = {fullfile(HOME,'LabelsSemantic')};
    HOMEANNOTATIONS = fullfile(HOME,'Annotations');
    HOMECLASSIFIER = fullfile(HOMEDATA,'Classifier','Exemplar');
    HOMERUNONTRAINING = fullfile(HOMEDATA,'RunOnTrainingNew');
    TestFold = fullfile(HOMEDATA,testParams.TestString);
    max_mined_range = [1280];
    testParams.ModelFold = ['Model' num2str(max_mined_range(end))];
    testParams.retSetSize = 800;
    testParams.segSuffix = [];
    testParams.K = 200;
    parserFold = 'probPerLabelR800K200TNN80-SPscGistCoHist-sc01ratio';
    detectorFold = 'Model1280-MM0100-R800-NMS0';
    svmFold = 'SVMs-Ovlp';
    testSVMList = {'LF-RBF-SS250k-RH0.00-RE0.33-std-G0.0000-s_3-nt','LF-RBF-SS250k-RH0.00-RE0.33-std-G0.0000-s_2-C0.0001-multicls'};
    %testSVMList = {'LF-RBF-SS250k-RH0.00-RE0.33-std-G0.0000-s_3-nt','LF-RBF-SS250k-RH0.00-RE0.33-RFD4000-std-G28.8584-s_2-nt'};
    trainSBin = 8;
    trainMaxScale = .5;
    testParams.MRFFold = 'MRF-OBJ';
elseif(dbNum ==4)
    %Fashionable
    testParams.TestString = 'CVPR12Single';
    %testParams.TestString = 'CVPR12';
    HOME = fullfile(HOMEDIR,'Fashionable');
    HOMEDATA = fullfile(HOME,'Data');
	HOMELABELSETS = {fullfile(HOME,'LabelsSemantic')};
    HOMEANNOTATIONS = fullfile(HOME,'AnnotationsSingle');
    %HOMEANNOTATIONS = fullfile(HOME,'Annotations');
    HOMECLASSIFIER = fullfile(HOMEDATA,'Classifier','ExemplarSingle');
    %HOMECLASSIFIER = fullfile(HOMEDATA,'Classifier','Exemplar');
    HOMERUNONTRAINING = fullfile(HOMEDATA,'RunOnTrainingSingle');
    %HOMERUNONTRAINING = fullfile(HOMEDATA,'RunOnTraining');
    TestFold = fullfile(HOMEDATA,testParams.TestString);
    max_mined_range = [468];
    testParams.ModelFold = ['Model' num2str(max_mined_range(end))];
    testParams.retSetSize = 468;
    testParams.segSuffix = [];
    testParams.K = 200;
    parserFold = 'probPerLabelCVPR12';
    testSVMList = {'LF-RBF-SS250k-RH0.00-RE0.33-std-G0.0000-s_2-C0.001'};
    testSVMList = {'LF-RBF-SS250k-RH0.00-RE0.33-std-G0.0000-s_2-C0.001-MM1000'};
    testSVMList = {'LF-RBF-SS250k-RH0.00-RE0.33-std-G0.0000-s_2-C0.001-MM0100'};
    
    testParams.MaxModelPerCls = 100;
    trainSBin = 8;
    trainMaxScale = 1;
    minNegOptions = 200;
    detectorFold = sprintf('Model%03d-MM%04d-R%03d-NMS0',max_mined_range,testParams.MaxModelPerCls,testParams.retSetSize);
    svmFold = sprintf('SVMs-MM%04d',testParams.MaxModelPerCls);
elseif(dbNum == 5)
    HOME = fullfile(HOMEDIR,'TestSeg');
    HOMEDATA = fullfile(HOME,'Data');
	HOMELABELSETS = {fullfile(HOME,'LabelsSemantic')};
    HOMECLASSIFIER = fullfile(HOMEDATA,'Classifier','Exemplar');
    testParams.K = 200;
    testParams.segSuffix = [];
elseif(dbNum == 6) %sample dataset
    testParams.TestString = 'TestFolder';
    HOME = fullfile(HOMEDIR,'SampleDataSet');
    HOMEDATA = fullfile(HOME,'Data');
	HOMELABELSETS = {fullfile(HOME,'LabelsSemantic')};
    HOMEANNOTATIONS = fullfile(HOME,'Annotations');
    HOMECLASSIFIER = fullfile(HOMEDATA,'Classifier','Exemplar');
    HOMERUNONTRAINING = fullfile(HOMEDATA,'RunOnTraining');
    TestFold = fullfile(HOMEDATA,testParams.TestString);
    max_mined_range = [10];
    testParams.ModelFold = ['Model' num2str(max_mined_range(end))];
    testParams.retSetSize = 100;
    testParams.segSuffix = [];
    testParams.K = 200;
    parserFold = 'probPerLabelR100K200TNN80-SPscGistCoHist-sc01ratio';
    detectorFold = 'Model10-MM0100-R100-NMS0';
    svmFold = 'SVMs';
    testSVMList = {'LF-RBF-SS2.500000e+00k-RH0.00-RE0.33-std-G0.0000-s_3-C1c3'};
    trainSBin = 4;
    trainMaxScale = 1;
end

dataset_params.datadir = HOMEDATA;
dataset_params.localdir = '';%fullfile(HOMEDATA,testParams.TestString);
dataset_params.display = 0;
detectorParams = esvm_get_default_params;
detectorParams.dataset_params = dataset_params;

HOMEIMAGES = fullfile(HOME,'Images');
HOMEDESCRIPTOR = fullfile(HOMEDATA,'Descriptors');
HOMEBUSY = fullfile(HOMECLASSIFIER,'Busy');
HOMETESTDATA = HOMEDATA;
testParams.HOMECLASSIFIER = HOMECLASSIFIER;
classifiers = cell(size(HOMELABELSETS));
spFold = sprintf('SP_Desc_k%d%s',testParams.K,testParams.segSuffix);
UseLabelSet = 1:length(HOMELABELSETS);

testName = 'TestSet1';
testSetFile = fullfile(HOME, [testName '.txt']);
testFileList = sort(importdata(testSetFile));
testFileList = strrep(testFileList,'\',filesep);
listMatFile = fullfile(HOME,'fileList.mat');
listFile = fullfile(HOME,'fileList.txt');
if(exist(listMatFile,'file'))
    load(listMatFile);
elseif(exist(listFile,'file'))
    allFileList = sort(importdata(listFile));
else
    allFileList = dir_recurse(fullfile(HOMEIMAGES,'*.*'),0);
    allFileList = strrep(allFileList,'\',filesep);
    fid = fopen(listFile,'w');
    for i = 1:length(allFileList)
        fprintf(fid,'%s\n',allFileList{i});
    end
    fclose(fid);
    save(listMatFile,'allFileList');
end
allFileList = strrep(allFileList,'\',filesep);
trainFileList = setdiff(allFileList,testFileList);
trainFileWinOrder = strrep(sort(strrep(trainFileList,'/','\')),'\',filesep);
trainFileLinOrder = strrep(sort(strrep(trainFileList,'\','/')),'/',filesep);
trainFileList = trainFileLinOrder;
fileList = allFileList;

if(length(trainFileList)+length(testFileList) ~= length(allFileList))
    fprintf('Error: file lists are not of the correct size\n');
    break;
end

Labels = cell(size(HOMELABELSETS));
for l = 1:length(HOMELABELSETS)
    [fold base] = fileparts(testFileList{l});
    try
        load(fullfile(HOMELABELSETS{l},fold,[base '.mat'])); %S (ro x co) names
        clear S S_instances;
        Labels{l} = names;
    end
end

if(~exist('valGlobalDesc','var'))
    try
        trainGlobalDesc = ComputeGlobalDescriptors([], HOMEIMAGES, HOMELABELSETS, HOMEDATA);
        testGlobalDesc = ComputeGlobalDescriptors([], HOMEIMAGES, HOMELABELSETS, HOMEDATA);
        valGlobalDesc = ComputeGlobalDescriptors([], HOMEIMAGES, HOMELABELSETS, HOMEDATA);
    catch
        try
            trainGlobalDesc = ComputeGlobalDescriptors(trainFileList, HOMEIMAGES, HOMELABELSETS, HOMEDATA);
            testGlobalDesc = ComputeGlobalDescriptors(testFileList, HOMEIMAGES, HOMELABELSETS, HOMEDATA);
            valGlobalDesc = ComputeGlobalDescriptors([], HOMEIMAGES, HOMELABELSETS, HOMEDATA);
        end
    end
end

if(exist(fullfile(HOME,'StuffLabels.txt'),'file'))
    sl = importdata(fullfile(HOME,'StuffLabels.txt'));
    [~, stuffLs] = intersect(names,sl);
end

rangeTest = 1:length(testFileList);
if(exist('rangeN','var'))
    rangeTest = rangeN(1):rangeN(2):length(testFileList);
end
rangeTrain = 1:length(trainFileList);
if(exist('rangeN','var'))
    rangeTrain = rangeN(1):rangeN(2):length(trainFileList);
end

labelColors = GetColors(HOME, HOMECODE, HOMELABELSETS, Labels);
