%{
HOME = 'D:\im_parser\siftFlowDetector';
HOME = '~/CS/im_parser/siftFlowDetector';
HOME = '~/CS/im_parser/CamVid';
%HOME = 'D:\im_parser\CamVid';
HOME = 'D:\im_parser\LMSun';
HOMEIMAGES = fullfile(HOME,'Images');
HOMEANNOTATIONS = fullfile(HOME,'Annotations');
HOMELABELSETS = {fullfile(HOME,'LabelsSemantic')};
%HOMELABELSETS = {fullfile(HOME,'LabelsSemanticSimple')};
HOMEDATA = fullfile(HOME,'Data');
HOMEDESCRIPTOR = fullfile(HOMEDATA,'Descriptors');
HOMECLASSIFIER = fullfile(HOMEDATA,'Classifier','Exemplar');
HOMEBUSY = fullfile(HOMECLASSIFIER,'Busy');


if(exist(HOMEBUSY,'file'))
    %rmdir(HOMEBUSY, 's');
end
trainFiles = fullfile(HOME,'trainSet1.mat');
if(~exist(trainFiles,'file'))
    fileList = dir_recurse(fullfile(HOMEIMAGES,'*.*'),0);
    testSetFile = fullfile(HOME,['TestSet1.txt']);
    testFiles = importdata(testSetFile);
    testFiles = strrep(testFiles,'\','/');
    fileList = strrep(fileList,'\','/');
    trainFileUnix = setdiff(fileList,testFiles);
    trainFileUnix = strrep(trainFileUnix,'\','/');
    save(trainFiles,'trainFileUnix');
end
load(trainFiles);
trainFileList = trainFileUnix;
%}

SetUpConstants;

trainFileListFull = cell(size(trainFileList));
for i = 1:length(trainFileList)
    trainFileListFull{i} = fullfile(HOMEIMAGES,trainFileList{i});
end

labelPresenceFile = fullfile(HOMECLASSIFIER,'labelPresence.mat');
if(~exist(labelPresenceFile,'file'))
    GenerateLabelPresenceFile;
    make_dir(labelPresenceFile);
    save(labelPresenceFile,'labelPresenceMap');
end
load(labelPresenceFile);

%make retrieval set files
testParams.globalDescriptors = {'spatialPryScaled','colorGist','coHist'};
%{
trainGlobalDesc = ComputeGlobalDescriptors(trainFileList, HOMEIMAGES, HOMELABELSETS, HOMEDATA);
for i = 1:length(trainFileList)
    [fold base] = fileparts(trainFileList{i});
    [retInds rank]= FindRetrievalSet(trainGlobalDesc,SelectDesc(trainGlobalDesc,i,1),HOMECLASSIFIER,fullfile(fold,base),testParams,'');
end
%}

