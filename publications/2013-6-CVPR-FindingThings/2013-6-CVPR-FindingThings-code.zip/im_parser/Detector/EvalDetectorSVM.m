
if(ispc())
    HOMEDIR = 'D:\im_parser\';
else
    HOMEDIR = '~/CS/im_parser/';
end

if(dbNum ==1)
    %camVid
    HOME = fullfile(HOMEDIR,'CamVid');
    HOMEDATA = fullfile(HOME,'Data');
    testParams.TestString = 'DetectorPreTrained';
    TestFold = fullfile(HOMEDATA,testParams.TestString);
    DataFold = fullfile(HOMEDATA,'RunOnTraining');
    spFold = 'SP_Desc_k0_vidSeg';
    detectorFold = 'Model468-MM0100-R200-NMS0';
    parserFold = 'ClassifierOutputFull';
    svmFold = 'SVMs-Final';
    HOMELABELSETS = {fullfile(HOME,'LabelsSemanticSimple')};
elseif(dbNum ==2)
    %siftflow
    HOME = fullfile(HOMEDIR,'siftFlowDetector');
    HOMEDATA = fullfile(HOME,'Data');
    testParams.TestString = 'Detector4Bin';
    TestFold = fullfile(HOMEDATA,testParams.TestString);
    DataFold = fullfile(HOMEDATA,'RunOnTraining');
    spFold = 'SP_Desc_k200';
    detectorFold = 'Model360-MM0100-R200-NMS0';
    parserFold = 'probPerLabelR200K200TNN80-SPscGistCoHist-sc01ratio';
    svmFold = 'SVMs-Final';
    HOMELABELSETS = {fullfile(HOME,'LabelsSemantic')};
elseif(dbNum ==3)
    %LMSun
    HOME = fullfile(HOMEDIR,'LMSun');
    HOMEDATA = fullfile(HOME,'Data');
    testParams.TestString = 'DetectorCalibrated';
    TestFold = fullfile(HOMEDATA,testParams.TestString);
    DataFold = fullfile(HOMEDATA,'RunOnTraining');
    spFold = 'SP_Desc_k200';
    detectorFold = 'Model1280-MM0100-R800-NMS0';
    parserFold = 'probPerLabelR800K200TNN80-SPscGistCoHist-sc01ratio';
    svmFold = 'SVMs-Final';
    HOMELABELSETS = {fullfile(HOME,'LabelsSemantic')};
end

HOMEIMAGES = fullfile(HOME,'Images');
HOMEANNOTATIONS = fullfile(HOME,'Annotations');
HOMEDATA = fullfile(HOME,'Data');
HOMEDESCRIPTOR = fullfile(HOMEDATA,'Descriptors');

[foo LabelSetFold] = fileparts(HOMELABELSETS{1});
detFiles = dir_recurse(fullfile(TestFold,'ExemplarDataTerm',detectorFold,'*'),0);
[fold base] = fileparts(detFiles{1});
load(fullfile(HOMELABELSETS{1},fold,[base '.mat'])); %S (ro x co) names

%Linear SVM
numLs = length(names);

close all;
MyCleanUp;
make_dir(fullfile(TestFold,svmFold,'resultsFullTest.txt'));
fid = fopen(fullfile(TestFold,svmFold,'resultsEvalDetector.txt'),'w');
fprintf(fid,'SVM Name\tC param\tValidation Value\tPer-pix + Per-class\tPer-pixel\tPer-class\t');
fprintf(fid,'%s\t',names{:});
fprintf(fid,'\n');
%[a b] = UniqueAndCounts(testLabels);
fprintf(fid,'Training Set Counts\t\t\t\t\t\t');
%fprintf(fid,'%d\t',b);
fprintf(fid,'\n');


testSVMList = {};
foldList = dir(fullfile(TestFold,svmFold,'*.mat'));
for i = 1:length(foldList)
    if(~foldList(i).isdir)
        [a testSVMList{end+1}] = fileparts(foldList(i).name);
    end
end

for i = 1:length(testSVMList)
    saveFile = fullfile(TestFold,svmFold,[testSVMList{i} '.mat']);
    a = load(saveFile);
    if(isfield(a,'svm'))
        svm = a.svm;
        fprintf('Testing %s\n',testSVMList{i});
        if(~isfield(a,'rates'))
            %[rates] = MySVMTestInMem(testFeats,testLabels,svm,1024^3);
            %save(saveFile,'svm','rates');
            continue;
        else
            rates = a.rates;
        end
        prates = rates(:,1)./rates(:,2);
        if(isfield(svm.params,'cvCriteria'))
            cvc = svm.params.cvCriteria;
        else
            cvc = 0;
        end
        fprintf(fid,'%s\t',svm.params.svmName);fprintf(fid,'%f\t',[svm.params.C cvc sum(prates(1:2))]);fprintf(fid,'%.3f\t',prates);fprintf(fid,'\n');
    end
end
fclose(fid);
