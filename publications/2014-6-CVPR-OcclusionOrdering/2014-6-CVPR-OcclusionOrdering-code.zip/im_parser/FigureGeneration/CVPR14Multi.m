SetUpConstants;
preDefine = true;
if(dbNum == 2)
    TestList = {'DCRF-Sig-RetPoly0-rmStDet1-stffPrs1-w04-w0.100-cw00-gd0-olp1-stb1-szt3-itt3',...
                'RetPoly0-rmStDet1-stffPrs1-w04-w0.10-w00-gd0-olp1-stb1-szt3-itt3',...
                'RetPoly0-rmStDet1-stffPrs1-w04-w0.10-w00-gd0-olp1-stb1-szt3-itt3',...
                };
    dataSetName= 'SiftFlow';
elseif(dbNum == 3)
    TestList = {'DCRF-Sig-RetPoly0-rmStDet1-stffPrs1-w04-w0.100-cw00-gd0-olp1-stb1-szt3-itt3',...
        'RetPoly0-rmStDet1-stffPrs1-w04-w0.10-w00-gd0-olp1-stb1-szt3-itt3',...
        'RetPoly0-rmStDet1-stffPrs1-w04-w0.10-w00-gd0-olp1-stb1-szt3-itt3',...
        };
     dataSetName= 'LMSun';
     
end
        
TestName = {'Initial Parsing','Final Objects','Oclusion Ordering',};
layerWidth = 3;
showTitle = true;
showText = true;
showImage = true;
groundTruth = true;
showImNum = false;
clear labelSource;
addLabels = {[],[],[],[],[],[],[],[],[],[],[],[],[],[]};
cropParams = [0 0 0 0
              0 0 0 0
              0 0 0 0
              0 0 0 0
              0 0 0 0
              0 0 0 0
              0 0 0 0
              0 0 0 0
              0 0 0 0
              0 0 0 0];
skew = [1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1];

numImPerFig = 10;
range = 1:length(testFileList);
range = [4 10 14 16 17 20 21 22 27 28 30 60 66 75 103 110 132 135 140 146 156 176 188 191 201 214 219 308 309 328 341 359 385 386 388 393 394 397 401 411 419];
range = [4 20 21 132 60];
range = [146 156 188 191 219 328 110 201 359];
%range = [135 309 388 393 394 401 419];
%range = [20 26 28 34 54 57 58 64 67 68 70 73 76 107 128 158 164 166 199];
%range = [12 34 68 70 128 158 166];
numBatches = ceil(length(range)/numImPerFig);
for i = 1:numBatches% mr
    selected = range((i-1)*numImPerFig+1:min(i*numImPerFig,length(range)));
    selected = mat2cell(selected(:));
    selectedIm = [selected{:,1}];
    selectedLabels = selected(:,2:end);
    TestType = [ 1 2 3];
    fileSuffix = sprintf('-final-examples%02d.pdf',i+1);
    CVPR141Row;
end
preDefine = false;

for i = 1:numBatches
    fprintf('\\begin{figure*}[t]\n\\centering\n\\includegraphics[width=\\linewidth]{FiguresSup/%s-final-examples%02d.pdf}\n\\caption {}\n\\end{figure*}\n\n',dataSetName,i);
end