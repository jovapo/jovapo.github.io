SetUpConstants;
close all;
showText = true;
%% SetDataSet
selectedLabels = [];
if(dbNum == 3)
    TestList = {'DCRF-Sig-LF-RBF-SS250k-RH0.00-RE0.33-std-G0.0000-s_3-nt-w04',...
        'DCRF-Sig-RetPoly0-rmStDet1-stffPrs1-w04-w0.100-cw00-gd0-olp1-stb1-szt3-itt1'};
    TestName = {'Initial Parsse','Final Parse'};%,'SMV MRF Region/Detector','SMV MRF Region/Detector'
   
    dataSetName= 'LMSun';
    
    %good images
    %{-
    selected = {
        1 'car';
        %220 'car'
        %3 'car' 'wheel' 'window' 'building' 'tree';
        };
    addLabels = {[],[],[177],[]};
    fileSuffix = '-svm.pdf';
    selectedIm = [selected{:,1}];
    selectedLabels = selected(:,2:end);
    showText = false;
    cropParams = [250 450 50 400;
                  %301 600 1 400
                 ];
elseif(dbNum == 2)
    
elseif(dbNum == 1)
    
end


%% set shared vars
labHistet = 1;
WEBLABELSETS = HOMELABELSETS(labHistet);
HOMETESTSET = fullfile(HOMEDATA,testParams.TestString);

OutDir = 'D:\P4\jtighe_localhost\CourseWork\CVPR14\Figures';
outputAssetDir = 'D:\P4\jtighe_localhost\CourseWork\CVPR14\Figures\assets';
%outputAssetDir = [];

if(iscell(selectedLabels))
    sl = zeros(size(selectedLabels));
    for i = 1:numel(sl)
        sl(i) = find(strcmp(names,selectedLabels{i}));
    end
    selectedLabels = sl;
end

mrfFold = 'MRF';
if(exist('testParams','var') && isfield(testParams,'MRFFold'))
    mrfFold = testParams.MRFFold;
end

MyCleanUp;

%% Set Configurations
dataTermPlace = length(TestList);
numRowsPerIm = 2;
includeCombo = true;

numIm = length(selectedIm);
numTests = length(TestName);
numDataterms = size(selectedLabels,2);
mul = 2;
imMul = 1;
imWidth = 256/mul;
imHeight = zeros(size(selectedIm));
gapWidth = 8/mul;
gapHeight = 38/mul;
marginT = 40/mul;
marginLR = 20/mul;
marginB = 25/mul;
titleSize = 20/mul;
txtSize = 16/mul;
legendHight = 18/mul;
legendGap = 6/mul;
dataTermGap = 6/mul;
secondRowGap = 36/mul;
txtFont = 'Helvetica';%'Myriad Pro';%
%'Helvetica', 'Times-Roman', 'Palatino', 'Bookman', 'Helvetica-Narrow', 'Symbol', ...
%                'AvantGarde', 'NewCenturySchlbk', 'Courier', 'ZapfChancery', 'ZapfDingbats'

for sNdx = 1:numIm
    sI = selectedIm(sNdx);
    im = imread(fullfile(HOMEIMAGES,testFileList{sI}));
    [ro co ch] = size(im);
    if(exist('cropParams','var') && ~isempty(cropParams) && sum(cropParams(sNdx,:))>0)
        ro = cropParams(sNdx,2) - cropParams(sNdx,1)+1;
        co = cropParams(sNdx,4) - cropParams(sNdx,3)+1;
    end
    imHeight(sNdx) = ro*imWidth/co;
end

maxLegend = floor(imHeight./(legendHight+legendGap));

totalHeight = marginT+marginB+sum(imHeight)*numRowsPerIm+(numRowsPerIm*numIm-1)*gapHeight;
totalWidth = marginLR*2+(numTests+4)*imWidth+(numTests+1)*gapWidth+(numDataterms)*imWidth/2;
figure(1);
clf;
set(1, 'Position', [0, 0, totalWidth, totalHeight]);

%% Make Figure
py = 1-(marginT+imHeight(1))/totalHeight; 
letterA= 'a';letterA= letterA-1;
for sNdx = 1:numIm
    sI = selectedIm(sNdx);
    px = marginLR/totalWidth;
    [fold base ext] = fileparts(testFileList{sI});
    [foo setBase] = fileparts(WEBLABELSETS{1});
    
    labHist = zeros(length(names)+1,numTests+1);
    
    figure(1);
    
    if(numRowsPerIm==2)
        %% Double Row
        %Display Image
        axes( ...'Units','normalized',
                'Position',[px py imWidth/totalWidth imHeight(sNdx)/totalHeight], ...
                'XTickLabel','', ...
                'YTickLabel','');
        imOrg = imread(fullfile(HOMEIMAGES,testFileList{sI}));
        [ro co ch] = size(imOrg);
        if(~isempty(outputAssetDir))
            make_dir(fullfile(outputAssetDir,num2str(sI),base));
            imwrite(imOrg,fullfile(outputAssetDir,num2str(sI),[base '-im.png']));
        end
        im = imOrg;
        if(exist('cropParams','var') && ~isempty(cropParams) && sum(cropParams(sNdx,:))>0)
            im = im(cropParams(sNdx,1):cropParams(sNdx,2),cropParams(sNdx,3):cropParams(sNdx,4),:);
        end
        im = imresize(im,mul*imMul*[ imHeight(sNdx) imWidth]);
        imshow(im);
        if(sNdx==1)
            text(mul*imMul*imWidth/2,-3/mul,'Query & Ground Truth','FontName',txtFont,'FontSize',titleSize,'VerticalAlignment','bottom','HorizontalAlignment','center');
        end 
        
        %Display Ground Truth
        axes('Units','normalized', ...
                'Position',[px py-(imHeight(sNdx)+secondRowGap)/totalHeight imWidth/totalWidth imHeight(sNdx)/totalHeight], ...
                'XTickLabel','', ...
                'YTickLabel','');
        px = px+(imWidth+gapWidth)/totalWidth;
        groundTruthFile = fullfile(WEBLABELSETS{1},fold,[base '.mat']);
        load(groundTruthFile); %S metaData names
        [a b] = UniqueAndCounts(S);
        labHist(a+1,1) = b;
        STemp = S+1;
        STemp(STemp<1) = 1;
        if(exist('cropParams','var') && ~isempty(cropParams) && sum(cropParams(sNdx,:))>0)
            STemp = STemp(cropParams(sNdx,1):cropParams(sNdx,2),cropParams(sNdx,3):cropParams(sNdx,4));
        end
        [imLabeled] = DrawImLabels(im,STemp,[0 0 0; labelColors{1}],{'unlabeled' names{:}},[],0,0,2);
        if(~isempty(outputAssetDir))
            imwrite(imLabeled,fullfile(outputAssetDir,num2str(sI),[base '-gtLabels.png']));
        end
        imLabeled = imresize(imLabeled,mul*imMul*[round(imHeight(sNdx)) round(imWidth)]);
        figure(1);
        imshow(imLabeled); 
        if(numIm>1)
            text(mul*imMul*imWidth/2,3/mul+imHeight(sNdx)*mul*imMul,['(' letterA+sNdx ')'],'FontName',txtFont,'FontSize',txtSize,'VerticalAlignment','top','HorizontalAlignment','center'); 
        end
        
        
        bigImWidth = (2*imWidth+secondRowGap);
        bigImHeight = (2*imHeight(sNdx)+secondRowGap);
        maxLegend(sNdx) = floor(bigImHeight./(legendHight+legendGap));
        if(~isempty(selectedLabels))
            load(fullfile(TestFold,'ExemplarDataTerm',detectorFold,fold,[base '.mat'])); %dataTerm (ro x co x #l) dataTermMax
            dminmax = [min(min(min(dataTerm(:,:,selectedLabels(sNdx,:))))) median(max(max(dataTerm(:,:,selectedLabels(sNdx,:)))))];
            a = load(fullfile(TestFold,setBase,parserFold,fold,[base '.mat'])); %probPerLabel (#SP x #l)
            if(isfield(a,'probPerLabel'))
                probPerLabel = a.probPerLabel;
            elseif(isfield(a,'prob'))
                probPerLabel = a.prob;
            end
            load(fullfile(HOMEDATA,'Descriptors',spFold,'super_pixels',fold,[base '.mat'])); %superPixels (ro x co)
            uSP = unique(superPixels);
            spMap = zeros(max(uSP),1);
            spMap(uSP) = 1:length(uSP);
            feat = [probPerLabel(spMap(superPixels),:) reshape(dataTerm,[],size(dataTerm,3))];
            
            dataW = imWidth;%(bigImWidth-dataTermGap)/2;
            dataH = (bigImHeight-secondRowGap)/2;
            
            predictorCell = cell(2,1);
            for svmNdx = 1:length(testSVMList)
                svmFile = fullfile(TestFold,svmFold,[testSVMList{svmNdx} '.mat']);
                trainedSVM = load(svmFile);
                [rates, pl, predictorCell{svmNdx}] = MySVMTestInMem(feat,S(:),trainedSVM.svm,1024^3);
                minmax(svmNdx,:) = [-1 median(max(predictorCell{svmNdx}(:,selectedLabels(sNdx,:))))];
            end
            
            if(~isempty(outputAssetDir))
                %pminmax = [-20 50];dminmax = [0 .7]; cminmax = [-1.5 1];
            end
            for dNdx = 1:numDataterms
                pyt = py-(imHeight(sNdx)+secondRowGap)/totalHeight;
                                
                axes('Units','normalized', ...
                        'Position',[px pyt dataW/totalWidth dataH/totalHeight], ...
                        'XTickLabel','', ...
                        'YTickLabel','');
                if(size(selectedLabels,1) >= sNdx)
                    dataVis = VisDataTerm(reshape(predictorCell{2}(:,selectedLabels(sNdx,dNdx)),size(superPixels)),labelColors{1}(selectedLabels(sNdx,dNdx),:),minmax(2,:));%
                    if(~isempty(outputAssetDir))
                        imwrite(dataVis,fullfile(outputAssetDir,num2str(sI),[base '-detector-' names{selectedLabels(sNdx,dNdx)} '.png']));
                    end
                    if(exist('cropParams','var') && ~isempty(cropParams) && sum(cropParams(sNdx,:))>0)
                        dataVis = dataVis(cropParams(sNdx,1):cropParams(sNdx,2),cropParams(sNdx,3):cropParams(sNdx,4),:);
                    end
                    dataVis = imresize(dataVis,mul*imMul*[dataH dataW]);
                    imshow(dataVis);
                    %text(mul*imMul*dataW/2,-3/mul,names{selectedLabels(sNdx,dNdx)},'FontName',txtFont,'FontSize',txtSize,'VerticalAlignment','bottom','HorizontalAlignment','center');
                    text(mul*imMul*dataW/(2-~mod(numDataterms,2)),-3/mul,'Non-Exclusive SVM','FontName',txtFont,'FontSize',titleSize,'VerticalAlignment','bottom','HorizontalAlignment','center');
                end
                
                if(dNdx==ceil(numDataterms/2)&&sNdx==1)
                    %text(mul*imMul*dataW/(2-~mod(numDataterms,2)),3/mul+dataH*mul*imMul,'Non-Exclusive SVM','FontName',txtFont,'FontSize',titleSize,'VerticalAlignment','top','HorizontalAlignment','center');
                end
                
                pyt = pyt+(dataH+secondRowGap)/totalHeight;
                axes('Units','normalized', ...
                        'Position',[px pyt dataW/totalWidth dataH/totalHeight], ...
                        'XTickLabel','', ...
                        'YTickLabel','');
                if(size(selectedLabels,1) >= sNdx)
                    dataVis = VisDataTerm(reshape(predictorCell{1}(:,selectedLabels(sNdx,dNdx)),size(superPixels)),labelColors{1}(selectedLabels(sNdx,dNdx),:),minmax(1,:));%
                    if(~isempty(outputAssetDir))
                        imwrite(dataVis,fullfile(outputAssetDir,num2str(sI),[base '-region-' names{selectedLabels(sNdx,dNdx)} '.png']));
                    end
                    if(exist('cropParams','var') && ~isempty(cropParams) && sum(cropParams(sNdx,:))>0)
                        dataVis = dataVis(cropParams(sNdx,1):cropParams(sNdx,2),cropParams(sNdx,3):cropParams(sNdx,4),:);
                    end
                    dataVis = imresize(dataVis,mul*imMul*[dataH dataW]);
                    imshow(dataVis);
                end
                
                if(dNdx==ceil(numDataterms/2)&&sNdx==1)
                    text(mul*imMul*dataW/(2-~mod(numDataterms,2)),-3/mul,'Exclusive SVM','FontName',txtFont,'FontSize',titleSize,'VerticalAlignment','bottom','HorizontalAlignment','center');
                end
                px = px+(dataW+dataTermGap)/totalWidth;
            end
            px = px+(gapWidth-dataTermGap)/totalWidth;
        end
        axes('Units','normalized', ...
                            'Position',[px py imWidth/totalWidth imHeight(sNdx)/totalHeight], ...
                            'XTickLabel','', ...
                            'YTickLabel','');
                        
        unary = -log(1./(1+exp(-predictorCell{1})));
        sp = imresize(-log(spatialPrior),[ro co],'nearest');
        sp = reshape(sp,size(unary));
        L0 = SmoothCRF(imOrg,unary+sp.*.1,[],4);
        perPixelStat = EvalPixelLabeling(L0,names,S,names);
        if(exist('cropParams','var') && ~isempty(cropParams) && sum(cropParams(sNdx,:))>0)
            L0 = L0(cropParams(sNdx,1):cropParams(sNdx,2),cropParams(sNdx,3):cropParams(sNdx,4));
        end
        [imLabeledFul] = DrawImLabels(im,L0+1,[0 0 0; labelColors{1}],{'unlabeled' names{:}},[],0,0,2);
        imLabeled = imresize(imLabeledFul,mul*imMul*[round(imHeight(sNdx)) round(imWidth)]);
        figure(1);
        imshow(imLabeled); 
        rate = perPixelStat(1)/perPixelStat(2);
        rateTxt = sprintf('%.1f%%',100*rate);
        if(showText)
            text(mul*imMul*imWidth/2,3/mul+imHeight(sNdx)*mul*imMul,rateTxt,'FontName',txtFont,'FontSize',txtSize,'VerticalAlignment','top','HorizontalAlignment','center');
        end
        text(size(imLabeled,2)/2,-3/mul,'Parsing Result','FontName',txtFont,'FontSize',titleSize,'VerticalAlignment','bottom','HorizontalAlignment','center');
                        
                
        axes('Units','normalized', ...
                'Position',[px py-(imHeight(sNdx)+secondRowGap)/totalHeight imWidth/totalWidth imHeight(sNdx)/totalHeight], ...
                'XTickLabel','', ...
                'YTickLabel','');
        unary = -log(1./(1+exp(-predictorCell{2})));
        L0 = SmoothCRF(imOrg,unary+sp.*.1,[],4);
        perPixelStat = EvalPixelLabeling(L0,names,S,names);
        if(exist('cropParams','var') && ~isempty(cropParams) && sum(cropParams(sNdx,:))>0)
            L0 = L0(cropParams(sNdx,1):cropParams(sNdx,2),cropParams(sNdx,3):cropParams(sNdx,4));
        end
        [imLabeledFul] = DrawImLabels(im,L0+1,[0 0 0; labelColors{1}],{'unlabeled' names{:}},[],0,0,2);
        imLabeled = imresize(imLabeledFul,mul*imMul*[round(imHeight(sNdx)) round(imWidth)]);
        figure(1);
        imshow(imLabeled); 
        rate = perPixelStat(1)/perPixelStat(2);
        rateTxt = sprintf('%.1f%%',100*rate);
        if(showText)
            text(mul*imMul*imWidth/2,3/mul+imHeight(sNdx)*mul*imMul,rateTxt,'FontName',txtFont,'FontSize',txtSize,'VerticalAlignment','top','HorizontalAlignment','center');
        end
        px = px+(imWidth+gapWidth)/totalWidth;
        
        py = py-(imHeight(sNdx)+secondRowGap)/totalHeight;
        
        
    end
    
    
    topLs = [];
    if(size(selectedLabels,1) >= sNdx)
        topLs = selectedLabels(sNdx,:)';
    end
    if(exist('addLabels','var'))
        topLs = [topLs; addLabels{sNdx}];
    end
    labHist(1,:) = [];
    [val,topLsF] = sort(labHist(:,end),'descend');
    topLsF = topLsF(val>0);
    [~,ind] = setdiff(topLsF,topLs);
    topLsF = topLsF(sort(ind));
    topLs = [topLs; topLsF(1:min(length(topLsF),ceil(maxLegend(sNdx)/2)))];
    [val,topLsC] = sort(sum(labHist(:,1),2),'descend');
    topLsC = topLsC(val>0);
    [~,ind] = setdiff(topLsC,topLs);
    topLsC = topLsC(sort(ind));
    topLs = [topLs; topLsC(1:min(length(topLsC),maxLegend(sNdx)-length(topLs)))];
     
    if(numRowsPerIm==2)
        axes('Units','normalized', ...
                'Position',[px py (legendHight)/totalWidth bigImHeight/totalHeight], ...
                'XTickLabel','', ...
                'YTickLabel','');
        blankIm = ones(round(bigImHeight),legendHight);
    else
        axes('Units','normalized', ...
                'Position',[px py (legendHight)/totalWidth imHeight(sNdx)/totalHeight], ...
                'XTickLabel','', ...
                'YTickLabel','');
        blankIm = ones(imHeight(sNdx),legendHight);
    end
    px = px+(imWidth+gapWidth)/totalWidth;
    imshow(blankIm);
    for lNdx = 1:length(topLs)
        rectangle('Position',[1,(lNdx-1)*(legendHight+legendGap),legendHight,legendHight],'FaceColor',labelColors{1}(topLs(lNdx),:),'EdgeColor','none')
        text(legendHight+legendGap,lNdx*legendHight+(lNdx-1)*legendGap,names{topLs(lNdx)},'FontName',txtFont,'FontSize',legendHight,'VerticalAlignment','baseline','HorizontalAlignment','left');
    end
    
    if(~isempty(outputAssetDir))
        figure(2);
        totalHeightL = marginT+marginB+imHeight(sNdx)*numRowsPerIm;
        totalWidthL = marginLR*2+imWidth;
        clf;
        set(2, 'Position', [0, 0, totalWidthL, totalHeightL]);
        
        pyL = marginT/totalHeightL; 

        pxL = marginLR/totalWidthL;
        if(numRowsPerIm==2)
            axes('Units','normalized', ...
                    'Position',[0 0 (legendHight)/totalWidthL bigImHeight/totalHeightL], ...
                    'XTickLabel','', ...
                    'YTickLabel','');
            blankIm = ones(round(bigImHeight),legendHight);
        else
            axes('Units','normalized', ...
                    'Position',[pxL pyL (legendHight)/totalWidthL imHeight(sNdx)/totalHeightL], ...
                    'XTickLabel','', ...
                    'YTickLabel','');
            blankIm = ones(imHeight(sNdx),legendHight);
        end
        
        imshow(blankIm);
        for lNdx = 1:length(topLs)
            rectangle('Position',[1,(lNdx-1)*(legendHight+legendGap),legendHight,legendHight],'FaceColor',labelColors{1}(topLs(lNdx),:),'EdgeColor','none')
            text(legendHight+legendGap,lNdx*legendHight+(lNdx-1)*legendGap,names{topLs(lNdx)},'FontName',txtFont,'FontSize',legendHight,'VerticalAlignment','baseline','HorizontalAlignment','left');
        end
        export_fig(fullfile(outputAssetDir,num2str(sI),[base '-legend.png']),'-m3','-transparent');%'-nocrop',
    end
    
   
    
    if(sNdx<numIm)
        py = py-(imHeight(sNdx+1)+gapHeight)/totalHeight;
    end
end

figure(1);
export_fig(fullfile(OutDir,[dataSetName fileSuffix]),'-m0','-transparent');%'-nocrop',
%fp = fillpage(gcf,'margins',[0 0 0 0],'papersize',[totalWidth totalHeight]/96);
%print(gcf,'-PPDF Printer','-dpdf', '-r96',fullfile(OutDir,[dataSetName '-examples.pdf']));
%set(gcf, fp);
