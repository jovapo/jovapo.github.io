SetUpConstants;
close all;
addLabels = {[],[],[],[],[],[],[],[],[],[],[],[],[],[]};
cropParams = [0 0 0 0
                  0 0 0 0
                  0 0 0 0
                  0 0 0 0
                  0 0 0 0
                  0 0 0 0
                  0 0 0 0
                  0 0 0 0];
centerLegend = false;
lastBig = false;
groundTruth = true;
showImage = true;
layerWidth = 2;
letterEach = false;
showText = true;
%% SetDataSet
selectedLabels = [];
if(dbNum == 3)
    %LMSun Detector Tests
    TestList = {'Lin-Sig-LF-RBF-SS250k-RH0.00-RE0.33-std-G0.0000-s_3-nt-w65',...'Lin-Sig-LF-RBF-SS250k-RH0.00-RE0.33-RFD4000-std-G28.8584-s_2-nt-w65',...
        'RetPoly0-rmStDet1-stffPrs1-w65-cw00-gd1-olp1-stb1-szt3',...
        'DCRF-Sig-RetPoly0-rmStDet1-stffPrs1-w65-w0.100-cw00-gd0-olp1-stb1-szt3-itt1',...
        'RetPoly0-rmStDet1-stffPrs1-w65-w0.10-w00-gd0-olp1-stb1-szt3-itt1',...
        'DCRF-Sig-RetPoly0-rmStDet1-stffPrs1-w65-w0.100-cw00-gd0-olp1-stb1-szt3-itt3',...
        'RetPoly0-rmStDet1-stffPrs1-w65-w0.10-w00-gd0-olp1-stb1-szt3-itt3',...
        };
    TestType = [1 2 1 2 1 2 1 2 1 2];
    TestName = {'Iteration 1','Iteration 1 obj','Iteration 2','Iteration 2 obj','Iteration 3','Iteration 3 obj'};%,'SMV MRF Region/Detector','SMV MRF Region/Detector'
    
    dataSetName= 'LMSun';
    
    testParams.TestString = 'ObjectCounting';
    testParams.MRFFold = 'MRF-8connSmoothing-linear';%'MRF-8-Ap';%
    
    %good images
    %{-
    selected = {
        125};%;440
    fileSuffix = '-itt-rbf-8conn.pdf';
    cropParams = [0 0 0 0
                  75 325 1 250
                  0 0 0 0
                  0 0 0 0
                  0 0 0 0
                  0 0 0 0
                  0 0 0 0
                  0 0 0 0];
    addLabels = {[],[136],[],[],[],[],[],[],[],[],[],[],[],[]};
    showText = true;
    
    groundTruth = true;
    showImage = true;
    %{
    TestList = {'DCRF-Sig-RetPoly0-rmStDet1-stffPrs1-w04-w0.100-cw00-gd0-olp1-stb1-szt3-itt3',...
        'RetPoly0-rmStDet1-stffPrs1-w04-w0.10-w00-gd0-olp1-stb1-szt3-itt3',...
        'RetPoly0-rmStDet1-stffPrs1-w04-w0.10-w00-gd0-olp1-stb1-szt3-itt3',...
        };
     TestName = {'Parsing','','Objects'};%'Initial Parse',
    selected = { 
    103;296;201;  346;%125;
    };
    TestType = [ 1 3 2];
    fileSuffix = '-exampleslayered2.pdf';
    cropParams = [0 0 0 0
                  101 512 1 276
                  0 0 0 0
                  0 0 0 0];
    groundTruth = true;
    showImage = true;
    layerWidth = 2;
    lastBig = false;
   %}
    selectedIm = [selected{:,1}];
    selectedLabels = selected(:,2:end);
elseif(dbNum == 2)
    %siftFlow Detector Tests
    TestList = {'DCRF-Sig-LF-RBF-SS500k-RH0.00-RE0.33-std-G0.0000-s_3-nt-w04',...
        'DCRF-Sig-RetPoly0-rmStDet1-stffPrs1-w04-w0.100-cw00-gd0-olp1-stb1-szt3-itt1'};
    TestName = {'Initial/Final Parse','Final Parse'};%,'SMV MRF Region/Detector','SMV MRF Region/Detector'
    ObjList = {'RetPoly0-rmStDet1-stffPrs1-w04-w0.10-w00-gd1-olp1-stb1-szt3-itt1'};
    ObjName = {'Object Predictions'};
    %TestName = {'Initial Region/Detector','Initial Region/Detector','Combined System'};%,'SMV MRF Region/Detector','SMV MRF Region/Detector'
    
    dataSetName= 'SiftFlow';
    groundTruth = true;
    showImage = true;

    testParams.TestString = 'ObjectCounting';
    testParams.MRFFold = 'MRF-8-Ap-lm';
    TestFold = fullfile(HOMEDATA,testParams.TestString);
    
    selectedIm = [172 15 100];%];% 21];167 106 148 
    selectedLabels = [8 6 22;
                      17 28 25;
                      17 6 32];
    fileSuffix = '-examples.pdf';
    %supplimentary material
    selected = {
        156 'streetlight' 'car' 'plant'
        164 'awning' 'sidewalk' 'car'
        161 'car' 'person' 'building'
        55 'sign' 'streetlight' 'bridge'
        63 'bridge' 'sign' 'fence'
        };
    fileSuffix = '-examples.pdf';
    
    TestList = {'Lin-Sig-LF-RBF-SS250k-RH0.00-RE0.33-RFD4000-std-G12.4443-s_2-ntc3-w129',...
        'RetPoly0-rmStDet1-stffPrs1-w129-cw00-gd1-olp1-stb1-szt3',...
        'DCRF-Sig-RetPoly0-rmStDet1-stffPrs1-w129-w0.100-cw00-gd1-olp1-stb1-szt3-itt3',...
        'RetPoly0-rmStDet1-stffPrs1-w129-w0.10-w00-gd1-olp1-stb1-szt3-itt3',...
        'RetPoly0-rmStDet1-stffPrs1-w129-w0.10-w00-gd1-olp1-stb1-szt3-itt3'};
    TestName = {'Initial Parse & Objects','iniobj','Final Parse & Objects','finalobj','Occlusion Ordering'};%'Initial Parse',
    selected = { 
    53;%158;
    };
    TestType = [1 2 1 2 3];
    fileSuffix = '-overview-rbf-8conn.pdf';
    groundTruth = true;
    lastBig = true;
    layerWidth = 2;
    letterEach = false;
    centerLegend= true;
    showText = false;
    %{
    TestList = {'Lin-Sig-LF-RBF-SS250k-RH0.00-RE0.33-RFD4000-std-G12.4443-s_2-ntc3-w129',...
        'RetPoly0-rmStDet1-stffPrs1-w129-cw00-gd0-olp1-stb1-szt3',...
        'DCRF-Sig-RetPoly0-rmStDet1-stffPrs1-w129-w0.050-cw00-gd0-olp1-stb1-szt3-itt3',...
        'RetPoly0-rmStDet1-stffPrs1-w129-w0.10-w00-gd0-olp1-stb1-szt3-itt3'};
    TestName = {'Initial Parse','Intial Objects','Final Parse','Final Objects'};%'Initial Parse',
    selected = { 
    86;
    };
    TestType = [1 2 1 2];
    fileSuffix = '-bad-rbf-8conn.pdf';
    groundTruth = true;
    lastBig = false;
    layerWidth = 1.4;
    %}
    %{
    selected = {
        171  'car' 'road' 'building'
        20 'sun' 'sky' 'sea'
        161 'person' 'building' 'sky'
        };
    fileSuffix = '-examples-sup2.pdf';
    %}
    %{
    TestList = {'Lin-Sig-LF-RBF-SS250k-RH0.00-RE0.33-RFD4000-std-G12.4443-s_2-ntc3-w129',...
        'RetPoly0-rmStDet1-stffPrs1-w129-cw00-gd0-olp1-stb1-szt3',...
        'DCRF-Sig-RetPoly0-rmStDet1-stffPrs1-w129-w0.050-cw00-gd0-olp1-stb1-szt3-itt3',...
        'RetPoly0-rmStDet1-stffPrs1-w129-w0.10-w00-gd0-olp1-stb1-szt3-itt3'};
    TestName = {'Initial Parse','Intial Objects','Final Parse','Final Objects'};%'Initial Parse',
    selected = { 
    194;%86;
    };
    TestType = [1 2 1 2];
    fileSuffix = '-bad-rbf-8conn.pdf';
    groundTruth = true;
    lastBig = false;
    layerWidth = 2;
    letterEach = false;
    centerLegend= false;
    showText = true;
    
    addLabels = cell(size(selected,1),1);
    %}
    selectedIm = [selected{:,1}];
    selectedLabels = selected(:,2:end);
elseif(dbNum == 1)
end


%% set shared vars
labHistet = 1;
WEBLABELSETS = HOMELABELSETS(labHistet);
HOMETESTSET = fullfile(HOMEDATA,testParams.TestString);

OutDir = 'D:\P4\jtighe_localhost\CourseWork\CVPR14\Figures';
outputAssetDir = 'D:\P4\jtighe_localhost\CourseWork\CVPR14\Figures\assets';
%OutDir = 'D:\P4\jtighe_localhost\CourseWork\IJCV14\FiguresGen';
%outputAssetDir = 'D:\P4\jtighe_localhost\CourseWork\IJCV14\FiguresGen\assets14';
%outputAssetDir = [];

if(iscell(selectedLabels))
    sl = zeros(size(selectedLabels));
    for i = 1:numel(sl)
        sl(i) = find(strcmp(names,selectedLabels{i}));
    end
    selectedLabels = sl;
end

mrfFold = 'MRF';
if(exist('testParams','var') && isfield(testParams,'MRFFold'))
    mrfFold = testParams.MRFFold;
end

MyCleanUp;

%% Set Configurations
dataTermPlace = length(TestList);
numRowsPerIm = 2;
includeCombo = true;

numIm = length(selectedIm);
numTests = length(TestName);
numDataterms = size(selectedLabels,2);
mul = 1;
imMul = 4;
imWidth = 256/mul;
imHeight = zeros(size(selectedIm));
gapWidth = 8/mul;
gapHeight = 38/mul;
marginT = 40/mul;
marginLR = 20/mul;
marginB = 25/mul;
titleSize = 18/mul;
txtSize = 16/mul;
legendHight = 18/mul;
legendGap = 6/mul;
dataTermGap = 6/mul;
secondRowGap = 30/mul;%6
txtFont = 'Helvetica';%'Myriad Pro';%
%'Helvetica', 'Times-Roman', 'Palatino', 'Bookman', 'Helvetica-Narrow', 'Symbol', ...
%                'AvantGarde', 'NewCenturySchlbk', 'Courier', 'ZapfChancery', 'ZapfDingbats'

if(layerWidth ==2)
    layerWidth = (imWidth+imWidth+gapWidth)/imWidth;
end
for sNdx = 1:numIm
    sI = selectedIm(sNdx);
    im = imread(fullfile(HOMEIMAGES,testFileList{sI}));
    [ro co ch] = size(im);
    if(exist('cropParams','var') && ~isempty(cropParams) && sum(cropParams(sNdx,:))>0)
        ro = cropParams(sNdx,2) - cropParams(sNdx,1)+1;
        co = cropParams(sNdx,4) - cropParams(sNdx,3)+1;
    end
    imHeight(sNdx) = ro*imWidth/co;
end

maxLegend = floor((secondRowGap+imHeight*2)./(legendHight+legendGap));

totalHeight = marginT+marginB+sum(imHeight)*numRowsPerIm+(numRowsPerIm*numIm-1)*gapHeight;
totalWidth = 2000;%marginLR*2+(numTests+4+numObjs)*imWidth+(numTests+1)*gapWidth+(numDataterms)*imWidth/2;
figure(1);
clf;
set(1, 'Position', [0, 0, totalWidth, totalHeight]);

%% Make Figure
py = 1-(marginT+imHeight(1))/totalHeight; 
letterA= 'a';letterA= letterA-1;
for sNdx = 1:numIm
    sI = selectedIm(sNdx);
    px = marginLR/totalWidth;
    [fold base ext] = fileparts(testFileList{sI});
    [foo setBase] = fileparts(WEBLABELSETS{1});
    
    labHist = zeros(length(names)+1,numTests+1);
    letterCount = 1;
    figure(1);
    
    if(numRowsPerIm==2)
        imOrg = imread(fullfile(HOMEIMAGES,testFileList{sI}));
        [ro co ch] = size(imOrg);
        if(~isempty(outputAssetDir))
            make_dir(fullfile(outputAssetDir,num2str(sI),base));
            imwrite(imOrg,fullfile(outputAssetDir,num2str(sI),[base '-im.png']));
        end
        im = imOrg;
        if(exist('cropParams','var') && ~isempty(cropParams) && sum(cropParams(sNdx,:))>0)
            im = im(cropParams(sNdx,1):cropParams(sNdx,2),cropParams(sNdx,3):cropParams(sNdx,4),:);
        end
        im = imresize(im,mul*imMul*[ imHeight(sNdx) imWidth]);
        if(showImage)
            axes( ...'Units','normalized',
                    'Position',[px py imWidth/totalWidth imHeight(sNdx)/totalHeight], ...
                    'XTickLabel','', ...
                    'YTickLabel','');
            imshow(im);
            if(sNdx==1)
                text(mul*imMul*imWidth/2,-3/mul,'Query & Ground Truth ','FontName',txtFont,'FontSize',titleSize,'VerticalAlignment','bottom','HorizontalAlignment','center');
            end 
        end

        %Display Ground Truth
        if(groundTruth)
            axes('Units','normalized', ...
                    'Position',[px py-(imHeight(sNdx)+secondRowGap)/totalHeight imWidth/totalWidth imHeight(sNdx)/totalHeight], ...
                    'XTickLabel','', ...
                    'YTickLabel','');
            px = px+(imWidth+gapWidth)/totalWidth;
            groundTruthFile = fullfile(WEBLABELSETS{1},fold,[base '.mat']);
            load(groundTruthFile); %S metaData names
            [a b] = UniqueAndCounts(S);
            labHist(a+1,1) = b;
            STemp = S+1;
            STemp(STemp<1) = 1;
            if(exist('cropParams','var') && ~isempty(cropParams) && sum(cropParams(sNdx,:))>0)
                STemp = STemp(cropParams(sNdx,1):cropParams(sNdx,2),cropParams(sNdx,3):cropParams(sNdx,4));
            end
            [imLabeled] = DrawImLabels(im,STemp,[0 0 0; labelColors{1}],{'unlabeled' names{:}},[],0,0,2,mul*imMul*max(imHeight(sNdx),imWidth));
            figure(1);
            imshow(imLabeled);
            if(~isempty(outputAssetDir))
                imwrite(imLabeled,fullfile(outputAssetDir,num2str(sI),[base '-gt.png']));
            end
            if(numIm>1)
                text(mul*imMul*imWidth/2,3/mul+imHeight(sNdx)*mul*imMul,['(' letterA+sNdx ')'],'FontName',txtFont,'FontSize',txtSize,'VerticalAlignment','top','HorizontalAlignment','center'); 
            end  
            if(sNdx==1)
                %text(mul*imMul*imWidth/2,-3/mul,'Ground Truth','FontName',txtFont,'FontSize',titleSize,'VerticalAlignment','bottom','HorizontalAlignment','center');
            end    
        end
        
        %Intial Results
        for tNdx = 1:(numTests-lastBig)
            if(TestType(tNdx)==1)
                resultFile = fullfile(HOMETESTSET,mrfFold,setBase,TestList{tNdx},fold,[base '.mat']);
                load(resultFile); %L Lsp labelList
                [a b] = UniqueAndCounts(L);
                labHist(a+1,tNdx+1) = b;
                if(exist('cropParams','var') && ~isempty(cropParams) && sum(cropParams(sNdx,:))>0)
                    L = L(cropParams(sNdx,1):cropParams(sNdx,2),cropParams(sNdx,3):cropParams(sNdx,4));
                end
                [imLabeledFul] = DrawImLabels(imOrg,L+1,[0 0 0; labelColors{1}],{'unlabeled' names{:}},[],0,0,2,mul*imMul*max(imHeight(sNdx),imWidth));
                [r c ch] = size(imLabeledFul);
                imLabeled = imresize(imLabeledFul,mul*imMul*[round(imHeight(sNdx)) round((c/r)*(imHeight(sNdx)))]);
            else
                resultFile = fullfile(HOMETESTSET,mrfFold,'ObjectsPicked',TestList{tNdx},fold,[base '.mat']);
                load(resultFile);
                if(TestType(tNdx)==2)
                    imLabeledFul = DisplayObjects(imOrg,objs.masks,names(objs.Ls),2,objs.order, labelColors{1}(objs.Ls,:), 0);
                    if(exist('cropParams','var') && ~isempty(cropParams) && sum(cropParams(sNdx,:))>0)
                        imLabeledFul = imLabeledFul(cropParams(sNdx,1):cropParams(sNdx,2),cropParams(sNdx,3):cropParams(sNdx,4),:);
                    end
                elseif(TestType(tNdx)==3)
                    if(exist('cropParams','var') && ~isempty(cropParams) && sum(cropParams(sNdx,:))>0)
                        imC = imOrg(cropParams(sNdx,1):cropParams(sNdx,2),cropParams(sNdx,3):cropParams(sNdx,4),:);
                        masksC = reshape(objs.masks,[ro co size(objs.masks,2)]);
                        masksC = masksC(cropParams(sNdx,1):cropParams(sNdx,2),cropParams(sNdx,3):cropParams(sNdx,4),:);
                        masksC = reshape(masksC,[size(masksC,1)*size(masksC,2) size(masksC,3)]);
                        imLabeledFul = DisplayObjectsLayered(imC,masksC,names(objs.Ls),2,objs.order, labelColors{1}(objs.Ls,:),layerWidth);
                    else
                        imLabeledFul = DisplayObjectsLayered(imOrg,objs.masks,names(objs.Ls),2,objs.order, labelColors{1}(objs.Ls,:),layerWidth);
                    end
                end
                [a b] = UniqueAndCounts(objs.Ls);
                labHist(a+1,tNdx+1) = b;
                [r c ch] = size(imLabeledFul);
                imLabeled = imresize(imLabeledFul,mul*imMul*[round(imHeight(sNdx)) round((c/r)*(imHeight(sNdx)))]);
            end
            figure(1);
            [r c ch] = size(imLabeled);
            wMove = (c/r) *(imHeight(sNdx));
            if(mod(tNdx,2) == 1)
                axes('Units','normalized', ...
                        'Position',[px py wMove/totalWidth imHeight(sNdx)/totalHeight], ...
                        'XTickLabel','', ...
                        'YTickLabel','');
            else
                axes('Units','normalized', ...
                        'Position',[px py-(imHeight(sNdx)+secondRowGap)/totalHeight wMove/totalWidth imHeight(sNdx)/totalHeight], ...
                        'XTickLabel','', ...
                        'YTickLabel','');
                px = px+(imWidth+gapWidth)/totalWidth;
            end
            imshow(imLabeled); 
            resultCache = [resultFile '.cache']; 
            load(resultCache,'-mat'); %metaData perLabelStat(#labelsx2) perPixelStat([# pix correct, # pix total]);
            if(TestType(tNdx)==1)
                rate = perPixelStat(1)/perPixelStat(2);
                rateTxt = sprintf('%.1f%%',100*rate);
            else
                rateTxt = sprintf('%.2f / %.2f',sum(objP>.5)/length(objP),sum(gtInstP>.5)/length(gtInstP));
            end
            if(letterEach)
                rateTxt = ['(' letterA+letterCount ') ' rateTxt];
                letterCount = letterCount+1;
            end
            if(showText)
                text(mul*imMul*wMove/2,3/mul+imHeight(sNdx)*mul*imMul,rateTxt,'FontName',txtFont,'FontSize',txtSize,'VerticalAlignment','top','HorizontalAlignment','center');
            end
            if(sNdx==1&&mod(tNdx,2) == 1)
                text(size(imLabeled,2)/2,-3/mul,TestName{tNdx},'FontName',txtFont,'FontSize',titleSize,'VerticalAlignment','bottom','HorizontalAlignment','center');
            end
            if(~isempty(outputAssetDir))
                imwrite(imLabeledFul,fullfile(outputAssetDir,num2str(sI),[base '-' TestName{tNdx}  '.png']));%'-' rateTxt(1:end-1)
            end
        end
        if(~lastBig && mod(numTests,2))
            px = px+(imWidth+gapWidth)/totalWidth;
        end
        
        bigImWidth = (2*imWidth+secondRowGap);
        bigImHeight = (2*imHeight(sNdx)+secondRowGap);
        if(lastBig)
            tNdx = tNdx+1;
            if(TestType(tNdx)==1)
                resultFile = fullfile(HOMETESTSET,mrfFold,setBase,TestList{tNdx},fold,[base '.mat']);
                load(resultFile); %L Lsp labelList
                [a b] = UniqueAndCounts(L);
                labHist(a+1,tNdx+1) = b;
                if(exist('cropParams','var') && ~isempty(cropParams) && sum(cropParams(sNdx,:))>0)
                    L = L(cropParams(sNdx,1):cropParams(sNdx,2),cropParams(sNdx,3):cropParams(sNdx,4));
                end
                [imLabeled] = DrawImLabels(im,L+1,[0 0 0; labelColors{1}],{'unlabeled' labelList{:}},[],0,0,2,mul*imMul*max(imHeight(sNdx),imWidth));
            else
                resultFile = fullfile(HOMETESTSET,mrfFold,'ObjectsPicked',TestList{tNdx},fold,[base '.mat']);
                load(resultFile);
                if(TestType(tNdx)==2)
                    imLabeledFul = DisplayObjects(imOrg,objs.masks,names(objs.Ls),2,objs.order, labelColors{1}(objs.Ls,:), 0);
                    if(exist('cropParams','var') && ~isempty(cropParams) && sum(cropParams(sNdx,:))>0)
                        imLabeledFul = imLabeledFul(cropParams(sNdx,1):cropParams(sNdx,2),cropParams(sNdx,3):cropParams(sNdx,4),:);
                    end
                elseif(TestType(tNdx)==3)
                    if(exist('cropParams','var') && ~isempty(cropParams) && sum(cropParams(sNdx,:))>0)
                        imC = imOrg(cropParams(sNdx,1):cropParams(sNdx,2),cropParams(sNdx,3):cropParams(sNdx,4),:);
                        masksC = reshape(objs.masks,[ro co size(objs.masks,2)]);
                        masksC = masksC(cropParams(sNdx,1):cropParams(sNdx,2),cropParams(sNdx,3):cropParams(sNdx,4),:);
                        masksC = reshape(masksC,[size(masksC,1)*size(masksC,2) size(masksC,3)]);
                        imLabeledFul = DisplayObjectsLayered(imC,masksC,names(objs.Ls),2,objs.order, labelColors{1}(objs.Ls,:),layerWidth);
                    else
                        imLabeledFul = DisplayObjectsLayered(imOrg,objs.masks,names(objs.Ls),2,objs.order, labelColors{1}(objs.Ls,:),layerWidth);
                    end
                end
                [a b] = UniqueAndCounts(objs.Ls);
                labHist(a+1,tNdx+1) = b;
                [r c ch] = size(imLabeledFul);
                imLabeled = imresize(imLabeledFul,mul*imMul*[round(bigImHeight) round((c/r)*(bigImHeight))]);
            end
            figure(1);
            [r c ch] = size(imLabeled);
            wMove = (c/r) *(bigImHeight);
            axes('Units','normalized', ...
                    'Position',[px py-(imHeight(sNdx)+secondRowGap)/totalHeight wMove/totalWidth bigImHeight/totalHeight], ...
                    'XTickLabel','', ...
                    'YTickLabel','');
            imshow(imLabeled); 
            resultCache = [resultFile '.cache']; 
            load(resultCache,'-mat'); %metaData perLabelStat(#labelsx2) perPixelStat([# pix correct, # pix total]);
            if(TestType(tNdx)==1)
                rate = perPixelStat(1)/perPixelStat(2);
                rateTxt = sprintf('%.1f%%',100*rate);
            elseif(TestType(tNdx)==2)
                rateTxt = sprintf('%.2f / %.2f',sum(objP>.5)/length(objP),sum(gtInstP>.5)/length(gtInstP));
            end
            if(letterEach)
                rateTxt = ['(' letterA+letterCount ')'];
                letterCount = letterCount+1;
                text(mul*imMul*wMove/2,3/mul+bigImHeight*mul*imMul,rateTxt,'FontName',txtFont,'FontSize',txtSize,'VerticalAlignment','top','HorizontalAlignment','center');
            end
            if(sNdx==1&&mod(tNdx,2) == 1)
                text(mul*imMul*wMove/2,-3/mul,TestName{tNdx},'FontName',txtFont,'FontSize',titleSize,'VerticalAlignment','bottom','HorizontalAlignment','center');
            end
            if(~isempty(outputAssetDir))
                imwrite(imLabeledFul,fullfile(outputAssetDir,num2str(sI),[base '-' TestName{tNdx} '.png']));
            end
            px = px+(wMove+gapWidth)/totalWidth;
        end
        
        py = py-(imHeight(sNdx)+secondRowGap)/totalHeight;
    end
    
    
    topLs = [];
    if(size(selectedLabels,1) >= sNdx)
        topLs = selectedLabels(sNdx,:)';
    end
    if(exist('addLabels','var'))
        topLs = [topLs; addLabels{sNdx}];
    end
    labHist(1,:) = [];
    [val,topLsF] = sort(labHist(:,end-1),'descend');
    topLsF = topLsF(val>0);
    [~,ind] = setdiff(topLsF,topLs);
    topLsF = topLsF(sort(ind));
    topLs = [topLs; topLsF(1:min(length(topLsF),ceil(maxLegend(sNdx)/2)))];
    [val,topLsC] = sort(sum(labHist(:,1),2),'descend');
    topLsC = topLsC(val>0);
    [~,ind] = setdiff(topLsC,topLs);
    topLsC = topLsC(sort(ind));
    topLs = [topLs; topLsC(1:min(length(topLsC),maxLegend(sNdx)-length(topLs)))];
     
    if(centerLegend)
        axes('Units','normalized', ...
            'Position',[px py (legendHight)/totalWidth (1-(maxLegend(sNdx)-length(topLs))/(2*maxLegend(sNdx)))*bigImHeight/totalHeight], ...
            'XTickLabel','', ...
            'YTickLabel','');
        blankIm = ones(round((1-(maxLegend(sNdx)-length(topLs))/(2*maxLegend(sNdx)))*bigImHeight),legendHight);
    else
        axes('Units','normalized', ...
                'Position',[px py (legendHight)/totalWidth bigImHeight/totalHeight], ...
                'XTickLabel','', ...
                'YTickLabel','');
        blankIm = ones(round(bigImHeight),legendHight);
    end
    
    px = px+(imWidth+gapWidth)/totalWidth;
    imshow(blankIm);
    for lNdx = 1:length(topLs)
        rectangle('Position',[1,(lNdx-1)*(legendHight+legendGap),legendHight,legendHight],'FaceColor',labelColors{1}(topLs(lNdx),:),'EdgeColor','none')
        text(legendHight+legendGap,lNdx*legendHight+(lNdx-1)*legendGap,names{topLs(lNdx)},'FontName',txtFont,'FontSize',legendHight,'VerticalAlignment','baseline','HorizontalAlignment','left');
    end
    
    if(~isempty(outputAssetDir))
        figure(2);
        totalHeightL = marginT+marginB+imHeight(sNdx)*numRowsPerIm;
        totalWidthL = marginLR*2+imWidth;
        clf;
        set(2, 'Position', [0, 0, totalWidthL, totalHeightL]);
        
        pyL = marginT/totalHeightL; 

        pxL = marginLR/totalWidthL;
        if(numRowsPerIm==2)
            axes('Units','normalized', ...
                    'Position',[0 0 (legendHight)/totalWidthL bigImHeight/totalHeightL], ...
                    'XTickLabel','', ...
                    'YTickLabel','');
            blankIm = ones(round(bigImHeight),legendHight);
        else
            axes('Units','normalized', ...
                    'Position',[pxL pyL (legendHight)/totalWidthL imHeight(sNdx)/totalHeightL], ...
                    'XTickLabel','', ...
                    'YTickLabel','');
            blankIm = ones(imHeight(sNdx),legendHight);
        end
        
        imshow(blankIm);
        for lNdx = 1:length(topLs)
            rectangle('Position',[1,(lNdx-1)*(legendHight+legendGap),legendHight,legendHight],'FaceColor',labelColors{1}(topLs(lNdx),:),'EdgeColor','none')
            text(legendHight+legendGap,lNdx*legendHight+(lNdx-1)*legendGap,names{topLs(lNdx)},'FontName',txtFont,'FontSize',legendHight,'VerticalAlignment','baseline','HorizontalAlignment','left');
        end
        export_fig(fullfile(outputAssetDir,num2str(sI),[base '-legend.png']),'-m3','-transparent');%'-nocrop',
    end
    
   
    
    if(sNdx<numIm)
        py = py-(imHeight(sNdx+1)+gapHeight)/totalHeight;
    end
end

figure(1);
export_fig(fullfile(OutDir,[dataSetName fileSuffix]),'-m0','-transparent');%'-nocrop',
%fp = fillpage(gcf,'margins',[0 0 0 0],'papersize',[totalWidth totalHeight]/96);
%print(gcf,'-PPDF Printer','-dpdf', '-r96',fullfile(OutDir,[dataSetName '-examples.pdf']));
%set(gcf, fp);
