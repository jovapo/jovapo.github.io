SetUpConstants;
close all;
if(~exist('preDefine','var') || ~preDefine)
    showImage =  true;
    groundTruth = true;
    %% SetDataSet
    selectedLabels = [];
    clear labelSource;
    addLabels = {[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[]};
    cropParams = [0 0 0 0
                  0 0 0 0
                  0 0 0 0
                  0 0 0 0
                  0 0 0 0
                  0 0 0 0
                  0 0 0 0
                  0 0 0 0
                  0 0 0 0
                  0 0 0 0
                  0 0 0 0
                  0 0 0 0
                  0 0 0 0
                  0 0 0 0
                  0 0 0 0
                  0 0 0 0
                  0 0 0 0];
    skew = [1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1];
    showText = true;
    showTitle = true;
    if(dbNum == 3)
        
        %LMSun Detector Tests
        TestList = {'DCRF-Sig-LF-RBF-SS250k-RH0.00-RE0.33-std-G0.0000-s_3-nt-w04',...
            'RetPoly0-rmStDet1-stffPrs1-w04-w0.10-w00-gd0-olp1-stb1-szt3-itt1',...
            'DCRF-Sig-RetPoly0-rmStDet1-stffPrs1-w04-w0.100-cw00-gd0-olp1-stb1-szt3-itt1',...
            'DCRF-Sig-RetPoly0-rmStDet1-stffPrs1-w04-w0.500-cw00-gd0-olp1-stb1-szt3-itt1'};
        TestType = [1 2 1 1];
        TestName = {'Initial Parse','Predicted Objects','Object Weight .2','Object Weight 1'};%,'SMV MRF Region/Detector','SMV MRF Region/Detector'
        
        testParams.TestString = 'ObjectCounting';
        testParams.MRFFold = 'MRF-itt';
        testParams.MRFFold = 'MRF-8-Ap';
        %testParams.MRFFold = 'MRF-8connSmoothing-linear';%'MRF-8-Ap';
        dataSetName= 'LMSun';

        %good images
        %{-
        selected = {
            53;
            };
        addLabels = {[],[],[],[],[],[],[],[],[],[],[],[],[],[]};
        fileSuffix = '-objWeight.pdf';

        %% depth demo
        TestList = {%'DCRF-Sig-LF-RBF-SS250k-RH0.00-RE0.33-std-G0.0000-s_3-nt-w04',...
            'RetPoly0-rmStDet1-stffPrs1-w04-w0.10-w00-gd0-olp1-stb1-szt3-itt1',...
            'RetPoly0-rmStDet1-stffPrs1-w04-w0.10-w00-gd0-olp1-stb1-szt3-itt1',...
            'RetPoly0-rmStDet1-stffPrs1-w04-w0.10-w00-gd0-olp1-stb1-szt3-itt1'};
        TestName = {'Predicted Objects','Depth Ordering'};%'Initial Parse',
        selected = { 
        346; 28; 201; 125; 296;
        };
        TestType = [ 2 3];
        fileSuffix = '-objDepth.pdf';
        groundTruth = true;

        %% greedy vs not
        TestList = {%'DCRF-Sig-LF-RBF-SS250k-RH0.00-RE0.33-std-G0.0000-s_3-nt-w04',...
            'RetPoly0-rmStDet1-stffPrs1-w65-w0.05-w00-gd1-olp1-stb1-szt3-itt3',...
            'RetPoly0-rmStDet1-stffPrs1-w65-w0.05-w00-gd0-olp1-stb1-szt3-itt3'};
        TestName = {'Greedy','CPlex'};%'Initial Parse',
        selected = { 
        30; 220
        };
        TestType = [ 2 2];
        fileSuffix = '-greedy-rbf-8conn.pdf';
        groundTruth = false;
        showImage = false;
        showText = false;
        cropParams = [100 475 200 700;301 600 1 400];
        labelSource = 1;

        %% examples
        %{-
        TestList = {'DCRF-Sig-RetPoly0-rmStDet1-stffPrs1-w65-w0.050-cw00-gd0-olp1-stb1-szt3-itt3',...
            'RetPoly0-rmStDet1-stffPrs1-w65-w0.05-w00-gd0-olp1-stb1-szt3-itt3',...
            'RetPoly0-rmStDet1-stffPrs1-w65-w0.05-w00-gd0-olp1-stb1-szt3-itt3',...
            };
        TestName = {'Final Parsing','Final Objects','Occlusion Ordering'};%'Initial Parse',
        labelSource = 1;
        selected = { 
        296;346;130;146; %1; 308; 135;103;125;;201
        };
        TestType = [ 1 2 3];
        fileSuffix = '-exampleslayered-rbf-8conn.pdf';
        cropParams = [0 0 0 0 %151 512 1 276
                      1 533 50 750
                      0 0 0 0
                      0 0 0 0
                      0 0 0 0
                      0 0 0 0
                      0 0 0 0
                      0 0 0 0
                      0 0 0 0
                      0 0 0 0
                      0 0 0 0
                      0 0 0 0
                      0 0 0 0
                      0 0 0 0
                      ];
        groundTruth = true;
        showImage = true;
        layerWidth = 3.5;
        showText = true;
        skew = [.8 1 1 1 1 1 1 1 1 1 1 1 1 1 1];
        %}
        %% examplesjournal
        %{-
        TestList = {'DCRF-Sig-RetPoly0-rmStDet1-stffPrs1-w65-w0.050-cw00-gd0-olp1-stb1-szt3-itt3',...
            'RetPoly0-rmStDet1-stffPrs1-w65-w0.05-w00-gd0-olp1-stb1-szt3-itt3',...
            'RetPoly0-rmStDet1-stffPrs1-w65-w0.05-w00-gd0-olp1-stb1-szt3-itt3',...
            };
        TestName = {'Final Parsing','Final Objects','Occlusion Ordering'};%'Initial Parse',
        labelSource = 1;
        selected = { 
        146; 1; 308; 135;%346;%3;103;125;;201
        };
        TestType = [ 1 2 3];
        fileSuffix = '-examplesjournal-rbf-8conn.pdf';
        cropParams = [0 0 0 0 %151 512 1 276
                      0 0 0 0 
                      0 0 0 0 
                      0 0 0 0 
                      1 533 50 750
                      0 0 0 0
                      ];
        groundTruth = true;
        showImage = true;
        layerWidth = 3;
        showText = true;
        skew = [1 1 1 1 1 1 1 1];
        %}
        
        %{-
        
        TestList = {'DCRF-Sig-RetPoly0-rmStDet1-stffPrs1-w65-w0.050-cw00-gd0-olp1-stb1-szt3-itt3',...
            'RetPoly0-rmStDet1-stffPrs1-w65-w0.05-w00-gd0-olp1-stb1-szt3-itt3',...
            'RetPoly0-rmStDet1-stffPrs1-w65-w0.05-w00-gd0-olp1-stb1-szt3-itt3',...
            };
        TestName = {'Final Parsing','Final Objects','Occlusion Ordering'};%'Initial Parse',
        labelSource = 1;
        selected = { 
        296;346;130;146; 1; 308;%346;%3;103;125;;201
        };
        TestType = [ 1 2 3];
        fileSuffix = '-examplesposter.pdf';
        cropParams = [0 0 0 0 %151 512 1 276
                      1 533 50 750
                      0 0 0 0 
                      0 0 0 0 
                      0 0 0 0 
                      0 0 0 0
                      ];
        groundTruth = true;
        showImage = true;
        layerWidth = 3;
        showText = true;
        skew = [1 1 1 1 1 1 1 1];
        %}

        %{
        TestList = {'DCRF-Sig-LF-RBF-SS250k-RH0.00-RE0.33-std-G0.0000-s_3-nt-w04',...
            'RetPoly0-rmStDet1-stffPrs1-w04-cw00-gd0-olp1-stb1-szt3',...
            'DCRF-Sig-RetPoly0-rmStDet1-stffPrs1-w04-w0.100-cw00-gd0-olp1-stb1-szt3-itt3',...
            'RetPoly0-rmStDet1-stffPrs1-w04-w0.10-w00-gd0-olp1-stb1-szt3-itt3'};
        TestName = {'Initial Parse','Intial Objects','Final Parse','Final Objects'};%'Initial Parse',
        selected = { 
        444;
        };
        cropParams = [0 0 0 0
                      ];

        TestType = [1 2 1 2];
        fileSuffix = '-bad.pdf';

        TestList = {'DCRF-Sig-LF-RBF-SS250k-RH0.00-RE0.33-std-G0.0000-s_3-nt-w04',...
            'DCRF-Sig-LF-RBF-SS250k-RH0.00-RE0.33-std-G0.0000-s_3-nt-w04'};
        TestName = {'Exclusive SVM','Non-exclusive SVM'};%'Initial Parse',
        selected = { 
        128;
        };
        cropParams = [151 450 1 300
                      ];
        groundTruth= false;
        showText = false;
        TestType = [1 1];
        fileSuffix = '-stuffP.pdf';
        %}
        selectedIm = [selected{:,1}];
        selectedLabels = selected(:,2:end);


    elseif(dbNum == 2)
        %siftFlow Detector Tests
        TestList = {'DCRF-Sig-LF-RBF-SS500k-RH0.00-RE0.33-std-G0.0000-s_3-nt-w04',...
            'RetPoly0-rmStDet1-stffPrs1-w04-w0.10-w00-gd0-olp1-stb1-szt3-itt1',...
            'DCRF-Sig-RetPoly0-rmStDet1-stffPrs1-w04-w0.100-cw00-gd0-olp1-stb1-szt3-itt1',...
            'DCRF-Sig-RetPoly0-rmStDet1-stffPrs1-w04-w0.500-cw00-gd0-olp1-stb1-szt3-itt1'};
        TestName = {'Initial Parse','Predicted Objects','Object Weight .2','Object Weight 1'};%,'SMV MRF Region/Detector','SMV MRF Region/Detector'
        %TestName = {'Initial Region/Detector','Initial Region/Detector','Combined System'};%,'SMV MRF Region/Detector','SMV MRF Region/Detector'

        dataSetName= 'SiftFlow';
        groundTruth = true;
        showImage = true;
        
        testParams.TestString = 'ObjectCounting';
        testParams.MRFFold = 'MRF-itt';
        testParams.MRFFold = 'MRF-8-Ap-lm';

        %good images
        %{-
        selected = {
            53;
            };
        fileSuffix = '-objWeight.pdf';

        TestList = {%'DCRF-Sig-LF-RBF-SS250k-RH0.00-RE0.33-std-G0.0000-s_3-nt-w04',...
            'RetPoly0-rmStDet1-stffPrs1-w04-w0.05-w00-gd0-olp1-stb1-szt3-itt1',...
            'RetPoly0-rmStDet1-stffPrs1-w04-w0.05-w00-gd0-olp1-stb1-szt3-itt1'};
        TestName = {'Predicted Objects','Depth Ordering'};%'Initial Parse',
        selected = { 
        53;
        };
        TestType = [ 2 3];
        fileSuffix = '-objDepth.pdf';
        groundTruth = true;

        TestList = {'DCRF-Sig-RetPoly0-rmStDet1-stffPrs1-w129-w0.050-cw00-gd0-olp1-stb1-szt3-itt3',...
            'RetPoly0-rmStDet1-stffPrs1-w129-w0.05-w00-gd0-olp1-stb1-szt3-itt3',...
            'RetPoly0-rmStDet1-stffPrs1-w129-w0.05-w00-gd0-olp1-stb1-szt3-itt3',...
            };
        TestName = {'Initial Parsing','Final Objects','Oclusion Ordering',};
        selected = { 
        170;161;55;%164;76;54;   % 86;156;
        };
        TestType = [ 1 2 3];
        fileSuffix = '-exampleslayred2-rbf-8conn.pdf';
        layerWidth = 3.5;
        showTitle = false;
        %}
        %{-
        TestList = {'DCRF-Sig-RetPoly0-rmStDet1-stffPrs1-w129-w0.050-cw00-gd0-olp1-stb1-szt3-itt3',...
            'RetPoly0-rmStDet1-stffPrs1-w129-w0.05-w00-gd0-olp1-stb1-szt3-itt3',...
            'RetPoly0-rmStDet1-stffPrs1-w129-w0.05-w00-gd0-olp1-stb1-szt3-itt3',...
            };
        TestName = {'Initial Parsing','Final Objects','Oclusion Ordering',};
        selected = { 
        156;170;161; 55;%164;76;54;   % 86;
        };
        TestType = [ 1 2 3];
        fileSuffix = '-examplesjournal-rbf-8conn.pdf';
        layerWidth = 3;
        showTitle = true;
        %}
        %{        
        TestList = {'Lin-Sig-LF-RBF-SS250k-RH0.00-RE0.33-RFD4000-std-G12.4443-s_2-ntc3-w129',... 
            'RetPoly0-rmStDet1-stffPrs1-w129-cw00-gd0-olp1-stb1-szt3',...
            'DCRF-Sig-RetPoly0-rmStDet1-stffPrs1-w129-w0.050-cw00-gd0-olp1-stb1-szt3-itt3',...'RetPoly0-rmStDet1-stffPrs1-w129-w0.10-w00-gd0-olp1-stb1-szt3-itt3'
            };
        TestName = {'Initial Parse','Infered Objects','Final Parse'};%'Intial Objects',
        selected = { 
        194;%86;
        };
        TestType = [1 2 1];
         addLabels = {find(strcmp('boat',names))};
        fileSuffix = '-bad-rbf-8conn.pdf';
        showTitle = true;
        groundTruth = false;
        %}
        selectedIm = [selected{:,1}];
        selectedLabels = selected(:,2:end);
    end
end

%% set shared vars
labHistet = 1;
WEBLABELSETS = HOMELABELSETS(labHistet);
HOMETESTSET = fullfile(HOMEDATA,testParams.TestString);

OutDir = 'D:\P4\jtighe_localhost\CourseWork\IJCV14\FiguresGen';
OutDir = 'D:\P4\jtighe_localhost\CourseWork\CVPR14\Figures';
%outputAssetDir = 'D:\P4\jtighe_localhost\CourseWork\IJCV14\FiguresGen\assets';
outputAssetDir = [];

if(iscell(selectedLabels))
    sl = zeros(size(selectedLabels));
    for i = 1:numel(sl)
        sl(i) = find(strcmp(names,selectedLabels{i}));
    end
    selectedLabels = sl;
end

mrfFold = 'MRF';
if(exist('testParams','var') && isfield(testParams,'MRFFold'))
    mrfFold = testParams.MRFFold;
end

MyCleanUp;

%% Set Configurations
if(~exist('labelSource','var'))
    labelSource = length(TestList);
end
dataTermPlace = length(TestList);
numRowsPerIm = 1;
includeCombo = true;

numIm = length(selectedIm);
numTests = length(TestName);
numDataterms = size(selectedLabels,2);
mul = 2;
imMul = 1;
imWidth = 256/mul;
imHeight = zeros(size(selectedIm));
gapWidth = 8/mul;
gapHeight = 38/mul;
marginT = 40/mul;
marginLR = 20/mul;
marginB = 25/mul;
titleSize = 18/mul;
txtSize = 15/mul;
legendHight = 15/mul;
legendGap = 6/mul;
dataTermGap = 6/mul;
secondRowGap = 26/mul;
txtFont = 'Helvetica';%'Myriad Pro';%
%'Helvetica', 'Times-Roman', 'Palatino', 'Bookman', 'Helvetica-Narrow', 'Symbol', ...
%                'AvantGarde', 'NewCenturySchlbk', 'Courier', 'ZapfChancery', 'ZapfDingbats'

for sNdx = 1:numIm
    sI = selectedIm(sNdx);
    im = imread(fullfile(HOMEIMAGES,testFileList{sI}));
    [ro co ch] = size(im);
    if(exist('cropParams','var') && ~isempty(cropParams) && sum(cropParams(sNdx,:))>0)
        ro = cropParams(sNdx,2) - cropParams(sNdx,1)+1;
        co = cropParams(sNdx,4) - cropParams(sNdx,3)+1;
    end
    if(exist('skew','var') && ~isempty(skew) && sum(skew(sNdx))~=1)
        ro = ro*skew(sNdx);
    end
    imHeight(sNdx) = ro*imWidth/co;
end

maxLegend = floor(imHeight./(legendHight+legendGap));

totalHeight = marginT+marginB+sum(imHeight)*numRowsPerIm+(numRowsPerIm*numIm-1)*gapHeight;
totalWidth = 2000;%marginLR*2+(numTests+4)*imWidth+(numTests+1)*gapWidth+(numDataterms)*imWidth/2;
figure(1);
clf;
set(1, 'Position', [0, 0, totalWidth, totalHeight]);

%% Make Figure
py = 1-(marginT+imHeight(1))/totalHeight; 
letterA= 'a';letterA= letterA-1;
for sNdx = 1:numIm
    sI = selectedIm(sNdx);
    px = marginLR/totalWidth;
    [fold base ext] = fileparts(testFileList{sI});
    [foo setBase] = fileparts(WEBLABELSETS{1});
    
    labHist = zeros(length(names)+1,numTests+1);
    
    
    figure(1);
    imOrg = imread(fullfile(HOMEIMAGES,testFileList{sI}));
    [ro co ch] = size(imOrg);
    if(~isempty(outputAssetDir))
        make_dir(fullfile(outputAssetDir,num2str(sI),base));
        imwrite(imOrg,fullfile(outputAssetDir,num2str(sI),[base '-im.png']));
    end
    im = imresize(imOrg,mul*imMul*[ imHeight(sNdx) imWidth]);
    if(showImage)
        axes( ...'Units','normalized',
                'Position',[px py imWidth/totalWidth imHeight(sNdx)/totalHeight], ...
                'XTickLabel','', ...
                'YTickLabel','');
        px = px+(imWidth+gapWidth)/totalWidth;
        imOrg = imread(fullfile(HOMEIMAGES,testFileList{sI}));
        [ro co ch] = size(imOrg);
        if(~isempty(outputAssetDir))
            make_dir(fullfile(outputAssetDir,num2str(sI),base));
            imwrite(imOrg,fullfile(outputAssetDir,num2str(sI),[base '-im.png']));
        end
        im = imOrg;
        if(exist('cropParams','var') && ~isempty(cropParams) && sum(cropParams(sNdx,:))>0)
            im = im(cropParams(sNdx,1):cropParams(sNdx,2),cropParams(sNdx,3):cropParams(sNdx,4),:);
        end
        if(exist('skew','var') && ~isempty(skew) && sum(skew(sNdx))~=1)
            [r c ch] = size(im);
            im = imresize(im,[r*skew(sNdx) c]);
        end
        im = imresize(im,mul*imMul*[ imHeight(sNdx) imWidth]);
        imshow(im);
        if(exist('showImNum','var') && showImNum)
            text(mul*imMul*imWidth/2,3/mul+imHeight(sNdx)*mul*imMul,num2str(sI),'FontName',txtFont,'FontSize',txtSize,'VerticalAlignment','top','HorizontalAlignment','center'); 
        elseif(numIm>1)
            text(mul*imMul*imWidth/2,3/mul+imHeight(sNdx)*mul*imMul,['(' letterA+sNdx ')'],'FontName',txtFont,'FontSize',txtSize,'VerticalAlignment','top','HorizontalAlignment','center'); 
        end
        if(sNdx==1 && showTitle)
            text(mul*imMul*imWidth/2,-3/mul,'Test Image','FontName',txtFont,'FontSize',titleSize,'VerticalAlignment','bottom','HorizontalAlignment','center');
        end 
    end

    %Display Ground Truth
    if(groundTruth)
        axes('Units','normalized', ...
                'Position',[px py imWidth/totalWidth imHeight(sNdx)/totalHeight], ...
                'XTickLabel','', ...
                'YTickLabel','');
        px = px+(imWidth+gapWidth)/totalWidth;
        groundTruthFile = fullfile(WEBLABELSETS{1},fold,[base '.mat']);
        load(groundTruthFile); %S metaData names
        [a b] = UniqueAndCounts(S);
        labHist(a+1,1) = b;
        STemp = S+1;
        STemp(STemp<1) = 1;
        if(exist('cropParams','var') && ~isempty(cropParams) && sum(cropParams(sNdx,:))>0)
            STemp = STemp(cropParams(sNdx,1):cropParams(sNdx,2),cropParams(sNdx,3):cropParams(sNdx,4));
        end
        if(exist('skew','var') && ~isempty(skew) && sum(skew(sNdx))~=1)
            [r c ch] = size(STemp);
            STemp = imresize(STemp,[r*skew(sNdx) c],'nearest');
        end
        [imLabeled] = DrawImLabels(im,STemp,[0 0 0; labelColors{1}],{'unlabeled' names{:}},[],0,0,2,mul*imMul*max(imHeight(sNdx),imWidth));
        figure(1);
        imshow(imLabeled);  
        if(sNdx==1 && showTitle)
            text(mul*imMul*imWidth/2,-3/mul,'Ground Truth','FontName',txtFont,'FontSize',titleSize,'VerticalAlignment','bottom','HorizontalAlignment','center');
        end    
    end
    for tNdx = 1:numTests
        if(TestType(tNdx)==1)
            resultFile = fullfile(HOMETESTSET,mrfFold,setBase,TestList{tNdx},fold,[base '.mat']);
            load(resultFile); %L Lsp labelList
            [a b] = UniqueAndCounts(L);
            labHist(a+1,tNdx+1) = b;
            if(exist('cropParams','var') && ~isempty(cropParams) && sum(cropParams(sNdx,:))>0)
                L = L(cropParams(sNdx,1):cropParams(sNdx,2),cropParams(sNdx,3):cropParams(sNdx,4));
            end
            if(exist('skew','var') && ~isempty(skew) && sum(skew(sNdx))~=1)
                [r c ch] = size(L);
                L = imresize(L,[r*skew(sNdx) c],'nearest');
            end
            [imLabeled] = DrawImLabels(im,L+1,[0 0 0; labelColors{1}],{'unlabeled' names{:}},[],0,0,2,mul*imMul*max(imHeight(sNdx),imWidth));
        else
            resultFile = fullfile(HOMETESTSET,mrfFold,'ObjectsPicked',TestList{tNdx},fold,[base '.mat']);
            load(resultFile);
            if(TestType(tNdx)==2)
                imLabeledFul = DisplayObjects(imOrg,objs.masks,names(objs.Ls),4,objs.order, labelColors{1}(objs.Ls,:), 0);
                if(exist('cropParams','var') && ~isempty(cropParams) && sum(cropParams(sNdx,:))>0)
                    imLabeledFul = imLabeledFul(cropParams(sNdx,1):cropParams(sNdx,2),cropParams(sNdx,3):cropParams(sNdx,4),:);
                end
                if(exist('skew','var') && ~isempty(skew) && sum(skew(sNdx))~=1)
                    [r c ch] = size(imLabeledFul);
                    imLabeledFul = imresize(imLabeledFul,[r*skew(sNdx) c]);
                end
            elseif(TestType(tNdx)==3)
                imC = imOrg;
                masksC = objs.masks;
                if(exist('cropParams','var') && ~isempty(cropParams) && sum(cropParams(sNdx,:))>0)
                    imC = imOrg(cropParams(sNdx,1):cropParams(sNdx,2),cropParams(sNdx,3):cropParams(sNdx,4),:);
                    masksC = reshape(objs.masks,[ro co size(objs.masks,2)]);
                    masksC = masksC(cropParams(sNdx,1):cropParams(sNdx,2),cropParams(sNdx,3):cropParams(sNdx,4),:);
                    masksC = reshape(masksC,[size(masksC,1)*size(masksC,2) size(masksC,3)]);
                    
                end
                if(exist('skew','var') && ~isempty(skew) && sum(skew(sNdx))~=1)
                    [r c ch] = size(imC);
                    imC = imresize(imC,[r*skew(sNdx) c]);
                    
                    masksC = reshape(masksC,[r c size(objs.masks,2)]);
                    masksC = imresize(masksC,[r*skew(sNdx) c],'nearest');
                    masksC = reshape(masksC,[size(masksC,1)*size(masksC,2) size(masksC,3)]);
                end
                imLabeledFul = DisplayObjectsLayered(imC,masksC,names(objs.Ls),2,objs.order, labelColors{1}(objs.Ls,:),layerWidth);
            end
            [a b] = UniqueAndCounts(objs.Ls);
            labHist(a+1,tNdx+1) = b;
            [r c ch] = size(imLabeledFul);
            imLabeled = imresize(imLabeledFul,mul*imMul*[round(imHeight(sNdx)) round((c/r)*(imHeight(sNdx)))]);
        end
        figure(1);
        [r c ch] = size(imLabeled);
        wMove = (c/r) *(imHeight(sNdx));
        axes('Units','normalized', ...
                'Position',[px py wMove/totalWidth imHeight(sNdx)/totalHeight], ...
                'XTickLabel','', ...
                'YTickLabel','');
        px = px+(wMove+gapWidth)/totalWidth;
        imshow(imLabeled); 
        resultCache = [resultFile '.cache']; 
        load(resultCache,'-mat'); %metaData perLabelStat(#labelsx2) perPixelStat([# pix correct, # pix total]);
        if(TestType(tNdx)==1)
            rate = perPixelStat(1)/perPixelStat(2);
            rateTxt = sprintf('%.1f%%',100*rate);
        elseif(TestType(tNdx)==2)
            rateTxt = sprintf('%.2f / %.2f',sum(objP>.5)/length(objP),sum(gtInstP>.5)/length(gtInstP));
        end
        if(showText)
            text(mul*imMul*wMove/2,3/mul+imHeight(sNdx)*mul*imMul,rateTxt,'FontName',txtFont,'FontSize',txtSize,'VerticalAlignment','top','HorizontalAlignment','center');
        end
        if(sNdx==1 && showTitle)
            text(mul*imMul*wMove/2,-3/mul,TestName{tNdx},'FontName',txtFont,'FontSize',titleSize,'VerticalAlignment','bottom','HorizontalAlignment','center');
        end
    end


    topLs = [];
    if(size(selectedLabels,1) >= sNdx)
        topLs = selectedLabels(sNdx,:)';
    end
    if(exist('addLabels','var'))
        topLs = [topLs; addLabels{sNdx}];
    end
    labHist(1,:) = [];
    [val,topLsF] = sort(labHist(:,labelSource+1),'descend');
    topLsF = topLsF(val>0);
    [~,ind] = setdiff(topLsF,topLs);
    topLsF = topLsF(sort(ind));
    topLs = [topLs; topLsF(1:min(length(topLsF),ceil(maxLegend(sNdx))))];
    [val,topLsC] = sort(sum(labHist(:,1),2),'descend');
    topLsC = topLsC(val>0);
    [~,ind] = setdiff(topLsC,topLs);
    topLsC = topLsC(sort(ind));
    topLs = [topLs; topLsC(1:min(length(topLsC),maxLegend(sNdx)-length(topLs)))];
     
    axes('Units','normalized', ...
            'Position',[px py (legendHight)/totalWidth imHeight(sNdx)/totalHeight], ...
            'XTickLabel','', ...
            'YTickLabel','');
    blankIm = ones(round(imHeight(sNdx)),round(legendHight));
        
    px = px+(imWidth+gapWidth)/totalWidth;
    imshow(blankIm);
    for lNdx = 1:length(topLs)
        rectangle('Position',[1,(lNdx-1)*(legendHight+legendGap),legendHight,legendHight],'FaceColor',labelColors{1}(topLs(lNdx),:),'EdgeColor','none')
        text(legendHight+legendGap,lNdx*legendHight+(lNdx-1)*legendGap,names{topLs(lNdx)},'FontName',txtFont,'FontSize',legendHight,'VerticalAlignment','baseline','HorizontalAlignment','left');
    end
    
    if(sNdx<numIm)
        py = py-(imHeight(sNdx+1)+gapHeight)/totalHeight;
    end
end

figure(1);
export_fig(fullfile(OutDir,[dataSetName fileSuffix]),'-m0','-transparent');%'-nocrop',
%fp = fillpage(gcf,'margins',[0 0 0 0],'papersize',[totalWidth totalHeight]/96);
%print(gcf,'-PPDF Printer','-dpdf', '-r96',fullfile(OutDir,[dataSetName '-examples.pdf']));
%set(gcf, fp);
