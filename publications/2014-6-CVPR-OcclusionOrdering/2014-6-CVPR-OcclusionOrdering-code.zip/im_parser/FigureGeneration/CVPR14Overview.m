SetUpConstants;

%% SetDataSet
selectedLabels = [];
if(dbNum == 3)
    %LMSun Detector Tests
    TestList = {'DCRF-Sig-LF-RBF-SS250k-RH0.00-RE0.33-std-G0.0000-s_3-nt-w04',...
        'DCRF-Sig-RetPoly0-rmStDet1-stffPrs1-w04-w0.100-cw00-gd0-olp1-stb1-szt3-itt1'};
    TestName = {'Initial Parsse','Final Parse'};%,'SMV MRF Region/Detector','SMV MRF Region/Detector'
    ObjList = {'RetPoly0-rmStDet1-stffPrs1-w04-w0.10-w00-gd0-olp1-stb1-szt3-itt1'};
    ObjName = {'Object Predictions'};
    %TestName = {'Initial Region/Detector','Initial Region/Detector','Combined System'};%,'SMV MRF Region/Detector','SMV MRF Region/Detector'
    
    dataSetName= 'LMSun';
    
    %good images
    %{-
    selected = {
        146 'taxi' 'building' 'road';
        3 'car' 'window' 'building';
        308 'bed' 'painting' 'wall';
        135 'toilet' 'floor' 'wall'
        };
    addLabels = {[],[],[177],[]};
    fileSuffix = '-examples.pdf';
    %}
    %bad
    %{
    selectedIm = [232];%210 36 104];
    selectedLabels = {'boat' 'sea' 'water'};
    fileSuffix = '-bad.pdf';
    %}
    %{
    selectedLabels = [%40 33 229;
                      201 40 33;
                      40 229 227;
                      16 150 222;
                      206 93 222];
                      %}
    %for overview fig
    %selected = {132 'sky' 'tree' 'bus' 'car'};
    %TestName = {'Region Based','Detector Based','Combined System'};
    
    %supplimentary material
    %{
    selected = {
        219 'fire hydrant' 'sidewalk' 'parking meter'
        20 'car' 'bicycle' 'tree'
        210 'car' 'road' 'building'
        104 'car' 'van' 'motorbike'
        168 'van' 'car' 'manhole'
        };
    fileSuffix = '-examples-sup1.pdf';
    %{
    selected = {
        394 'dishwasher' 'stove' 'cupboard'
        411 'bookshelf' 'desk' 'chair'
        404 'floor' 'wall' 'ceiling'
        485 'lamp' 'sofa' 'picture'
        %136 'bed' 'lamp' 'curtain'
        309 'vase' 'bed' 'floor'
        };
    fileSuffix = '-examples-sup2.pdf';
    %}
    addLabels = cell(size(selected,1),1);
    %}
    selectedIm = [selected{:,1}];
    selectedLabels = selected(:,2:end);
elseif(dbNum == 2)
    %siftFlow Detector Tests
    TestList = {'SuperParsing',...
        'DetectorScore',...
        'LF-RBF-SS250k-RH0.00-RE0.33-RFD4000-std-G12.4443-s_2-ntc3-SS016'};
    TestName = {'Initial Region/Detector','Initial Region/Detector','Combined System'};
       dataSetName= 'SiftFlow';
    
    selectedIm = [172 15 100];%];% 21];167 106 148 
    selectedLabels = [8 6 22;
                      17 28 25;
                      17 6 32];
    fileSuffix = '-examples.pdf';
    %supplimentary material
    selected = {
        164 'awning' 'sidewalk' 'car'
        172 'car' 'road' 'building'
        55 'sign' 'streetlight' 'bridge'
        63 'bridge' 'sign' 'fence'
        };
    fileSuffix = '-examples.pdf';
    %{
    selected = {
        171  'car' 'road' 'building'
        20 'sun' 'sky' 'sea'
        161 'person' 'building' 'sky'
        };
    fileSuffix = '-examples-sup2.pdf';
    %}
    addLabels = cell(size(selected,1),1);
    %}
    selectedIm = [selected{:,1}];
    selectedLabels = selected(:,2:end);
elseif(dbNum == 1)
   
end


%% set shared vars
labHistet = 1;
WEBLABELSETS = HOMELABELSETS(labHistet);
HOMETESTSET = fullfile(HOMEDATA,testParams.TestString);

OutDir = 'D:\P4\jtighe_localhost\CourseWork\CVPR14\Figures';
outputAssetDir = 'D:\P4\jtighe_localhost\CourseWork\CVPR14\Figures\assets';
%outputAssetDir = [];

if(iscell(selectedLabels))
    sl = zeros(size(selectedLabels));
    for i = 1:numel(sl)
        sl(i) = find(strcmp(names,selectedLabels{i}));
    end
    selectedLabels = sl;
end

mrfFold = 'MRF';
if(exist('testParams','var') && isfield(testParams,'MRFFold'))
    mrfFold = testParams.MRFFold;
end

MyCleanUp;

%% Set Configurations
dataTermPlace = length(TestList);
numRowsPerIm = 2;
includeCombo = true;

numIm = length(selectedIm);
numTests = length(TestName);
numDataterms = size(selectedLabels,2);
numObjs = length(ObjList);
mul = 2;
imMul = 1;
imWidth = 256/mul;
imHeight = zeros(size(selectedIm));
gapWidth = 8/mul;
gapHeight = 38/mul;
marginT = 40/mul;
marginLR = 20/mul;
marginB = 25/mul;
titleSize = 20/mul;
txtSize = 16/mul;
legendHight = 18/mul;
legendGap = 6/mul;
dataTermGap = 6/mul;
secondRowGap = 26/mul;
txtFont = 'Helvetica';%'Myriad Pro';%
%'Helvetica', 'Times-Roman', 'Palatino', 'Bookman', 'Helvetica-Narrow', 'Symbol', ...
%                'AvantGarde', 'NewCenturySchlbk', 'Courier', 'ZapfChancery', 'ZapfDingbats'

for sNdx = 1:numIm
    sI = selectedIm(sNdx);
    im = imread(fullfile(HOMEIMAGES,testFileList{sI}));
    [ro co ch] = size(im);
    imHeight(sNdx) = ro*imWidth/co;
end

maxLegend = floor(imHeight./(legendHight+legendGap));

totalHeight = marginT+marginB+sum(imHeight)*numRowsPerIm+(numRowsPerIm*numIm-1)*gapHeight;
totalWidth = marginLR*2+(numTests+4+numObjs)*imWidth+(numTests+1)*gapWidth+(numDataterms)*imWidth/2;
figure(1);
clf;
set(1, 'Position', [0, 0, totalWidth, totalHeight]);

%% Make Figure
py = 1-(marginT+imHeight(1))/totalHeight; 
letterA= 'a';letterA= letterA-1;
for sNdx = 1:numIm
    sI = selectedIm(sNdx);
    px = marginLR/totalWidth;
    [fold base ext] = fileparts(testFileList{sI});
    [foo setBase] = fileparts(WEBLABELSETS{1});
    
    labHist = zeros(length(names)+1,numTests+1);
    
    figure(1);
    
    if(numRowsPerIm==2)
        %% Double Row
        %Display Image
        axes( ...'Units','normalized',
                'Position',[px py imWidth/totalWidth imHeight(sNdx)/totalHeight], ...
                'XTickLabel','', ...
                'YTickLabel','');
        imOrg = imread(fullfile(HOMEIMAGES,testFileList{sI}));
        if(~isempty(outputAssetDir))
            make_dir(fullfile(outputAssetDir,num2str(sI),base));
            imwrite(imOrg,fullfile(outputAssetDir,num2str(sI),[base '-im.png']));
        end
        im = imresize(imOrg,mul*imMul*[ imHeight(sNdx) imWidth]);
        imshow(im);
        if(sNdx==1)
            text(mul*imMul*imWidth/2,-3/mul,'Query & Ground Truth','FontName',txtFont,'FontSize',titleSize,'VerticalAlignment','bottom','HorizontalAlignment','center');
        end 
        
        %Display Ground Truth
        axes('Units','normalized', ...
                'Position',[px py-(imHeight(sNdx)+secondRowGap)/totalHeight imWidth/totalWidth imHeight(sNdx)/totalHeight], ...
                'XTickLabel','', ...
                'YTickLabel','');
        px = px+(imWidth+gapWidth)/totalWidth;
        groundTruthFile = fullfile(WEBLABELSETS{1},fold,[base '.mat']);
        load(groundTruthFile); %S metaData names
        [a b] = UniqueAndCounts(S);
        labHist(a+1,1) = b;
        STemp = S+1;
        STemp(STemp<1) = 1;
        [imLabeled] = DrawImLabels(im,STemp,[0 0 0; labelColors{1}],{'unlabeled' names{:}},[],0,0,2);
        if(~isempty(outputAssetDir))
            imwrite(imLabeled,fullfile(outputAssetDir,num2str(sI),[base '-gtLabels.png']));
        end
        imLabeled = imresize(imLabeled,mul*imMul*[round(imHeight(sNdx)) round(imWidth)]);
        figure(1);
        imshow(imLabeled); 
        text(mul*imMul*imWidth/2,3/mul+imHeight(sNdx)*mul*imMul,['(' letterA+sNdx ')'],'FontName',txtFont,'FontSize',txtSize,'VerticalAlignment','top','HorizontalAlignment','center'); 
        
        
        bigImWidth = (2*imWidth+secondRowGap);
        bigImHeight = (2*imHeight(sNdx)+secondRowGap);
        maxLegend(sNdx) = floor(bigImHeight./(legendHight+legendGap));
        if(~isempty(selectedLabels))
            load(fullfile(TestFold,'ExemplarDataTerm',detectorFolder,fold,[base '.mat'])); %dataTerm (ro x co x #l) dataTermMax
            dminmax = [min(min(min(dataTerm(:,:,selectedLabels(sNdx,:))))) median(max(max(dataTerm(:,:,selectedLabels(sNdx,:)))))];
            a = load(fullfile(TestFold,setBase,probFold,fold,[base '.mat'])); %probPerLabel (#SP x #l)
            if(isfield(a,'probPerLabel'))
                probPerLabel = a.probPerLabel;
            elseif(isfield(a,'prob'))
                probPerLabel = a.prob;
            end
            load(fullfile(HOMEDATA,'Descriptors',spFold,'super_pixels',fold,[base '.mat'])); %superPixels (ro x co)
            uSP = unique(superPixels);
            spMap = zeros(max(uSP),1);
            spMap(uSP) = 1:length(uSP);
            feat = [probPerLabel(spMap(superPixels),:) reshape(dataTerm,[],size(dataTerm,3))];
            
            dataW = imWidth;%(bigImWidth-dataTermGap)/2;
            dataH = (bigImHeight-dataTermGap)/2;
            
            predictorCell = cell(2,1);
            for svmNdx = 1:length(testSVMList)
                svmFile = fullfile(TestFold,svmFold,[testSVMList{svmNdx} '.mat']);
                trainedSVM = load(svmFile);
                [a b c] = intersect(selectedLabels(sNdx,:),trainedSVM.svm.params.labelList);
                [a d] = sort(b);mInd = c(d);
                trainedSVM.svm.model = trainedSVM.svm.model(mInd);
                trainedSVM.svm.params.labelList = selectedLabels(sNdx,:)';
                [rates, pl, predictorCell{svmNdx}] = MySVMTestInMem(feat,S(:),trainedSVM.svm,1024^3);
                minmax(svmNdx,:) = [-1 median(max(predictorCell{svmNdx}(:,selectedLabels(sNdx,:))))];
            end
            
            if(~isempty(outputAssetDir))
                %pminmax = [-20 50];dminmax = [0 .7]; cminmax = [-1.5 1];
            end
            for dNdx = 1:numDataterms
                pyt = py-(imHeight(sNdx)+secondRowGap)/totalHeight;
                                
                axes('Units','normalized', ...
                        'Position',[px pyt dataW/totalWidth dataH/totalHeight], ...
                        'XTickLabel','', ...
                        'YTickLabel','');
                if(size(selectedLabels,1) >= sNdx)
                    dataVis = VisDataTerm(reshape(predictorCell{2}(:,selectedLabels(sNdx,dNdx)),size(superPixels)),labelColors{1}(selectedLabels(sNdx,dNdx),:),minmax(2,:));%
                    if(~isempty(outputAssetDir))
                        imwrite(dataVis,fullfile(outputAssetDir,num2str(sI),[base '-detector-' names{selectedLabels(sNdx,dNdx)} '.png']));
                    end
                    dataVis = imresize(dataVis,mul*imMul*[dataH dataW]);
                    imshow(dataVis);
                    text(mul*imMul*dataW/2,3/mul+dataH*mul*imMul,names{selectedLabels(sNdx,dNdx)},'FontName',txtFont,'FontSize',txtSize,'VerticalAlignment','top','HorizontalAlignment','center');
                end
                
                pyt = pyt+(dataH+dataTermGap)/totalHeight;
                axes('Units','normalized', ...
                        'Position',[px pyt dataW/totalWidth dataH/totalHeight], ...
                        'XTickLabel','', ...
                        'YTickLabel','');
                if(size(selectedLabels,1) >= sNdx)
                    dataVis = VisDataTerm(reshape(predictorCell{1}(:,selectedLabels(sNdx,dNdx)),size(superPixels)),labelColors{1}(selectedLabels(sNdx,dNdx),:),minmax(1,:));%
                    if(~isempty(outputAssetDir))
                        imwrite(dataVis,fullfile(outputAssetDir,num2str(sI),[base '-region-' names{selectedLabels(sNdx,dNdx)} '.png']));
                    end
                    dataVis = imresize(dataVis,mul*imMul*[dataH dataW]);
                    imshow(dataVis);
                end
                
                if(dNdx==ceil(numDataterms/2)&&sNdx==1)
                    text(mul*imMul*dataW/2,-3/mul,'Exclusive/Non-exclusive SVM','FontName',txtFont,'FontSize',titleSize,'VerticalAlignment','bottom','HorizontalAlignment','center');
                end
                px = px+(dataW+dataTermGap)/totalWidth;
            end
            px = px+(gapWidth-dataTermGap)/totalWidth;
        end
        
        %Intial Results
        for tNdx = 1:dataTermPlace
            if(dataTermPlace>1)
                if(mod(tNdx,2) == 1)
                    axes('Units','normalized', ...
                            'Position',[px py imWidth/totalWidth imHeight(sNdx)/totalHeight], ...
                            'XTickLabel','', ...
                            'YTickLabel','');
                else
                    axes('Units','normalized', ...
                            'Position',[px py-(imHeight(sNdx)+secondRowGap)/totalHeight imWidth/totalWidth imHeight(sNdx)/totalHeight], ...
                            'XTickLabel','', ...
                            'YTickLabel','');
                    px = px+(imWidth+gapWidth)/totalWidth;
                end
                resultFile = fullfile(HOMETESTSET,mrfFold,setBase,TestList{tNdx},fold,[base '.mat']);
                load(resultFile); %L Lsp labelList
                [a b] = UniqueAndCounts(L);
                labHist(a+1,tNdx+1) = b;
                [imLabeledFul] = DrawImLabels(im,L+1,[0 0 0; labelColors{1}],{'unlabeled' labelList{:}},[],0,0,2);
                imLabeled = imresize(imLabeledFul,mul*imMul*[round(imHeight(sNdx)) round(imWidth)]);
                figure(1);
                imshow(imLabeled); 
                resultCache = [resultFile '.cache']; 
                load(resultCache,'-mat'); %metaData perLabelStat(#labelsx2) perPixelStat([# pix correct, # pix total]);
                rate = perPixelStat(1)/perPixelStat(2);
                rateTxt = sprintf('%.1f%%',100*rate);
                text(mul*imMul*imWidth/2,3/mul+imHeight(sNdx)*mul*imMul,rateTxt,'FontName',txtFont,'FontSize',txtSize,'VerticalAlignment','top','HorizontalAlignment','center');
                if(sNdx==1&&mod(tNdx,2) == 1)
                    text(size(imLabeled,2)/2,-3/mul,TestName{tNdx},'FontName',txtFont,'FontSize',titleSize,'VerticalAlignment','bottom','HorizontalAlignment','center');
                end
                if(~isempty(outputAssetDir))
                    imwrite(imLabeledFul,fullfile(outputAssetDir,num2str(sI),[base '-' TestName{tNdx} '-' rateTxt(1:end-1) '.png']));
                end
            else
                axes('Units','normalized', ...
                        'Position',[px py-(imHeight(sNdx)+secondRowGap)/totalHeight bigImWidth/totalWidth bigImHeight/totalHeight], ...
                        'XTickLabel','', ...
                        'YTickLabel','');
                px = px+(bigImWidth+gapWidth)/totalWidth;
                resultFile = fullfile(HOMETESTSET,mrfFold,setBase,TestList{tNdx},fold,[base '.mat']);
                load(resultFile); %L Lsp labelList
                [a b] = UniqueAndCounts(L);
                labHist(a+1,tNdx+1) = b;
                [imLabeledFul] = DrawImLabels(im,L+1,[0 0 0; labelColors{1}],{'unlabeled' labelList{:}},[],0,0,2);
                imLabeled = imresize(imLabeledFul,mul*imMul*[round(bigImHeight) round(bigImWidth)]);
                figure(1);
                imshow(imLabeled); 
                resultCache = [resultFile '.cache']; 
                load(resultCache,'-mat'); %metaData perLabelStat(#labelsx2) perPixelStat([# pix correct, # pix total]);
                rate = perPixelStat(1)/perPixelStat(2);
                rateTxt = sprintf('%.1f%%',100*rate);
                text(mul*imMul*bigImWidth/2,3/mul+bigImHeight*mul*imMul,rateTxt,'FontName',txtFont,'FontSize',txtSize,'VerticalAlignment','top','HorizontalAlignment','center');
                if(sNdx==1)
                    text(size(imLabeled,2)/2,-3/mul,TestName{tNdx},'FontName',txtFont,'FontSize',titleSize,'VerticalAlignment','bottom','HorizontalAlignment','center');
                end
                if(~isempty(outputAssetDir))
                    imwrite(imLabeledFul,fullfile(outputAssetDir,num2str(sI),[base '-' TestName{tNdx} '-' rateTxt(1:end-1) '.png']));
                end
            end
        end
        
        for tNdx = 1:length(ObjList)
            axes('Units','normalized', ...
                    'Position',[px py-(imHeight(sNdx)+secondRowGap)/totalHeight bigImWidth/totalWidth bigImHeight/totalHeight], ...
                    'XTickLabel','', ...
                    'YTickLabel','');
            px = px+(bigImWidth+gapWidth)/totalWidth;
            resultFile = fullfile(HOMETESTSET,mrfFold,'ObjectsPicked',ObjList{tNdx},fold,[base '.mat']);
            load(resultFile); %L Lsp labelList
            imLabeledFul = DisplayObjects(imOrg,objs.masks,names(objs.Ls),2,objs.order, labelColors{1}(objs.Ls,:), 0);
            imLabeled = imresize(imLabeledFul,mul*imMul*[round(bigImHeight) round(bigImWidth)]);
            figure(1);
            imshow(imLabeled); 
            resultCache = [resultFile '.cache']; 
            load(resultCache,'-mat'); %metaData perLabelStat(#labelsx2) perPixelStat([# pix correct, # pix total]);
            rateTxt = sprintf('%.2f / %.2f',sum(gtInstP>.5)/length(gtInstP),sum(objP>.5)/length(objP));
            text(mul*imMul*bigImWidth/2,3/mul+bigImHeight*mul*imMul,rateTxt,'FontName',txtFont,'FontSize',txtSize,'VerticalAlignment','top','HorizontalAlignment','center');
            if(sNdx==1)
                text(size(imLabeled,2)/2,-3/mul,ObjName{tNdx},'FontName',txtFont,'FontSize',titleSize,'VerticalAlignment','bottom','HorizontalAlignment','center');
            end
            if(~isempty(outputAssetDir))
                imwrite(imLabeledFul,fullfile(outputAssetDir,num2str(sI),[base '-' ObjName{tNdx} '-' strrep(rateTxt(1:end-1),'/','') '.png']));
            end
        end
        
        for tNdx = dataTermPlace+1:numTests
            axes('Units','normalized', ...
                    'Position',[px py-(imHeight(sNdx)+secondRowGap)/totalHeight bigImWidth/totalWidth bigImHeight/totalHeight], ...
                    'XTickLabel','', ...
                    'YTickLabel','');
            px = px+(bigImWidth+gapWidth)/totalWidth;
            resultFile = fullfile(HOMETESTSET,mrfFold,setBase,TestList{tNdx},fold,[base '.mat']);
            load(resultFile); %L Lsp labelList
            [a b] = UniqueAndCounts(L);
            labHist(a+1,tNdx+1) = b;
            [imLabeledFul] = DrawImLabels(im,L+1,[0 0 0; labelColors{1}],{'unlabeled' labelList{:}},[],0,0,2);
            imLabeled = imresize(imLabeledFul,mul*imMul*[round(bigImHeight) round(bigImWidth)]);
            figure(1);
            imshow(imLabeled); 
            resultCache = [resultFile '.cache']; 
            load(resultCache,'-mat'); %metaData perLabelStat(#labelsx2) perPixelStat([# pix correct, # pix total]);
            rate = perPixelStat(1)/perPixelStat(2);
            rateTxt = sprintf('%.1f%%',100*rate);
            text(mul*imMul*bigImWidth/2,3/mul+bigImHeight*mul*imMul,rateTxt,'FontName',txtFont,'FontSize',txtSize,'VerticalAlignment','top','HorizontalAlignment','center');
            if(sNdx==1)
                text(size(imLabeled,2)/2,-3/mul,TestName{tNdx},'FontName',txtFont,'FontSize',titleSize,'VerticalAlignment','bottom','HorizontalAlignment','center');
            end
            if(~isempty(outputAssetDir))
                imwrite(imLabeledFul,fullfile(outputAssetDir,num2str(sI),[base '-' TestName{tNdx} '-' rateTxt(1:end-1) '.png']));
            end
        end
        py = py-(imHeight(sNdx)+secondRowGap)/totalHeight;
    end
    
    
    topLs = [];
    if(size(selectedLabels,1) >= sNdx)
        topLs = selectedLabels(sNdx,:)';
    end
    if(exist('addLabels','var'))
        topLs = [topLs; addLabels{sNdx}];
    end
    labHist(1,:) = [];
    [val,topLsF] = sort(labHist(:,end),'descend');
    topLsF = topLsF(val>0);
    [~,ind] = setdiff(topLsF,topLs);
    topLsF = topLsF(sort(ind));
    topLs = [topLs; topLsF(1:min(length(topLsF),ceil(maxLegend(sNdx)/2)))];
    [val,topLsC] = sort(sum(labHist(:,1),2),'descend');
    topLsC = topLsC(val>0);
    [~,ind] = setdiff(topLsC,topLs);
    topLsC = topLsC(sort(ind));
    topLs = [topLs; topLsC(1:min(length(topLsC),maxLegend(sNdx)-length(topLs)))];
     
    if(numRowsPerIm==2)
        axes('Units','normalized', ...
                'Position',[px py (legendHight)/totalWidth bigImHeight/totalHeight], ...
                'XTickLabel','', ...
                'YTickLabel','');
        blankIm = ones(round(bigImHeight),legendHight);
    else
        axes('Units','normalized', ...
                'Position',[px py (legendHight)/totalWidth imHeight(sNdx)/totalHeight], ...
                'XTickLabel','', ...
                'YTickLabel','');
        blankIm = ones(imHeight(sNdx),legendHight);
    end
    px = px+(imWidth+gapWidth)/totalWidth;
    imshow(blankIm);
    for lNdx = 1:length(topLs)
        rectangle('Position',[1,(lNdx-1)*(legendHight+legendGap),legendHight,legendHight],'FaceColor',labelColors{1}(topLs(lNdx),:),'EdgeColor','none')
        text(legendHight+legendGap,lNdx*legendHight+(lNdx-1)*legendGap,names{topLs(lNdx)},'FontName',txtFont,'FontSize',legendHight,'VerticalAlignment','baseline','HorizontalAlignment','left');
    end
    
    if(~isempty(outputAssetDir))
        figure(2);
        totalHeightL = marginT+marginB+imHeight(sNdx)*numRowsPerIm;
        totalWidthL = marginLR*2+imWidth;
        clf;
        set(2, 'Position', [0, 0, totalWidthL, totalHeightL]);
        
        pyL = marginT/totalHeightL; 

        pxL = marginLR/totalWidthL;
        if(numRowsPerIm==2)
            axes('Units','normalized', ...
                    'Position',[0 0 (legendHight)/totalWidthL bigImHeight/totalHeightL], ...
                    'XTickLabel','', ...
                    'YTickLabel','');
            blankIm = ones(round(bigImHeight),legendHight);
        else
            axes('Units','normalized', ...
                    'Position',[pxL pyL (legendHight)/totalWidthL imHeight(sNdx)/totalHeightL], ...
                    'XTickLabel','', ...
                    'YTickLabel','');
            blankIm = ones(imHeight(sNdx),legendHight);
        end
        
        imshow(blankIm);
        for lNdx = 1:length(topLs)
            rectangle('Position',[1,(lNdx-1)*(legendHight+legendGap),legendHight,legendHight],'FaceColor',labelColors{1}(topLs(lNdx),:),'EdgeColor','none')
            text(legendHight+legendGap,lNdx*legendHight+(lNdx-1)*legendGap,names{topLs(lNdx)},'FontName',txtFont,'FontSize',legendHight,'VerticalAlignment','baseline','HorizontalAlignment','left');
        end
        export_fig(fullfile(outputAssetDir,num2str(sI),[base '-legend.png']),'-m3','-transparent');%'-nocrop',
    end
    
   
    
    if(sNdx<numIm)
        py = py-(imHeight(sNdx+1)+gapHeight)/totalHeight;
    end
end

figure(1);
export_fig(fullfile(OutDir,[dataSetName fileSuffix]),'-m0','-transparent');%'-nocrop',
%fp = fillpage(gcf,'margins',[0 0 0 0],'papersize',[totalWidth totalHeight]/96);
%print(gcf,'-PPDF Printer','-dpdf', '-r96',fullfile(OutDir,[dataSetName '-examples.pdf']));
%set(gcf, fp);
