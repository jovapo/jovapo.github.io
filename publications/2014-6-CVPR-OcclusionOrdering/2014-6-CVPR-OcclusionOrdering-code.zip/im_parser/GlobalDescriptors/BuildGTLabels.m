function [ desc_all ] = BuildGTLabels( imageFileList, labelBaseDirs )

close all;
desc_all = cell(length(labelBaseDirs),1);
for ls = 1:length(labelBaseDirs)
    labelBaseDir = labelBaseDirs{ls};
    [foo labelSet] = fileparts(labelBaseDir);
    tic
    pfig = ProgressBar('Building Label Histogram');
    for f = 1:length(imageFileList)
        % load image
        imageFName = imageFileList{f};
        [dirN base] = fileparts(imageFName);
        baseFName = [dirN filesep base];
        labelFName = fullfile(labelBaseDir, sprintf('%s.mat', baseFName));
        if(mod(f,100)==0)
            ProgressBar(pfig,f,length(imageFileList));
        end
        try
            clear S;
            load(labelFName);
            if(~exist('S','var')&&exist('L','var'))
                S = L;
            end
            pu = unique(S(:));
            Ss = imresize(S,[128 128],'nearest');
            au = unique(Ss(:));
            
            Ss = Ss(:);
            if(isempty(desc_all{ls}))
                desc_all{ls} = zeros(length(imageFileList),length(Ss));
            end
            desc_all{ls}(f,:) = Ss;
            
            if(length(setdiff(pu,au))>0)
                fprintf('Removed Label: ');
                fprintf('%d ',setdiff(pu,au));
                fprintf('\n');
            end
        catch ME
            ME
        end
    end
    close(pfig);
end
end