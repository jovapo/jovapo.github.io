function [gtInstLabelStat, objLabelStat, instP, objP, pixStats] = EvaluateObjLabeling(objs,S,S_instances,instL,names)
% objs = prediected objects
% S_instances = ground truth objects
[ro co no] = size(S_instances);
si = reshape(S_instances>0,[ro*co no]);
intr=zeros(size(objs.masks,2),no);
unin=zeros(size(objs.masks,2),no);
predL = zeros(size(S));
[a ind] = sort(objs.order);
for i = ind(:)'
    predL(objs.masks(:,i)) = objs.Ls(i);
end

pixStats = [sum(predL(:)==S(:)) sum(predL(:)~=0) numel(predL)];

ls = unique(instL);
ls(ls==0) = [];
for l = ls(:)'
    sndx = find(instL==l);
    ondx = find(objs.Ls==l);
    intr(ondx,sndx) = single(objs.masks(:,ondx))'*single(si(:,sndx));
    for o = ondx(:)'
        for s = sndx(:)'
            unin(o,s) = sum(objs.masks(:,o)|si(:,s));
        end
    end
end

p = intr./unin;
instP = max(p,[],1);
instP(isnan(instP)) = 0;
objP = max(p,[],2);
objP(isnan(objP)) = 0;
gtInstLabelStat = zeros(length(names),2);
objLabelStat = zeros(length(names),2);
for l = ls(:)'
    sndx = find(instL==l);
    gtInstLabelStat(l,:) = [sum(instP(sndx)) length(sndx)];
    ondx = find(objs.Ls==l);
    objLabelStat(l,:) = [sum(objP(ondx)) length(ondx)];
end
