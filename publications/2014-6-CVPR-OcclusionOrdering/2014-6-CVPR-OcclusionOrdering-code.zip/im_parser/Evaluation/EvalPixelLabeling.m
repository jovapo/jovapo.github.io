function [perPixStats perLabelStats conMat] = EvalPixelLabeling(L,labelList,S,names,toSyn)
perLabelStats = zeros(length(names),3);
if(exist('toSyn','var'))
    L = toSyn(L);S=toSyn(S);
end
lS = unique(S);
lS(lS<=0) = [];
if(exist('synPairs','var'))
    synPairs = cell(size(names));
end


for l = lS(:)'
    mask = S==l;
    %perLabelStats(l,1) = sum(L(mask)==l);
    perLabelStats(l,2) = sum(mask(:));
    %perLabelStats(l,3) = sum(L(:)==l);
end
lS = unique(L);
for l = lS(:)'
    mask = L==l;
    perLabelStats(l,1) = sum(S(mask)==l);
    perLabelStats(l,3) = sum(mask(:));
    %for i = 1:length(synPairs{l})
    %    perLabelStats(l,1) = max(perLabelStats(l,1),sum(S(mask)==synPairs{l}(i)));
    %end
end
perPixStats(1) = sum(perLabelStats(:,1));
perPixStats(2) = sum(perLabelStats(:,2));
if(nargout>2)
    %needs to be debugged
    conMat = zeros(length(labelList),length(labelList));
    for l1 = lS(:)'
        Lm = L(S==l1);
        lL = unique(Lm);
        for l2 = lL(:)'
            conMat(l1,l2) = sum(Lm==l2);
        end
    end
end
