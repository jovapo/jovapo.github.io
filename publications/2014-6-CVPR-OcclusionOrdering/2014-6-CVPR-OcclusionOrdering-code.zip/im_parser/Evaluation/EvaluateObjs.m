function [unionIntScores gtInstLabelStats] =  EvaluateObjs(HOMEDATA,HOMELABELSETS,testStrings,suffix,outputFolder,matchMetaData,rangeN)

labels = cell(length(HOMELABELSETS),length(testStrings));
tests = cell(length(HOMELABELSETS),length(testStrings));
gtInstLabelStats = cell(length(HOMELABELSETS),length(testStrings));
objLabelStats = cell(length(HOMELABELSETS),length(testStrings));
unionIntScores = cell(length(HOMELABELSETS),length(testStrings));
if(~exist('matchMetaData','var'));matchMetaData = [];end
if(~exist('conMatTest','var'));conMatTest = [];end
if(~exist('suffix','var'));suffix = '';end
if(~exist('outputFolder','var'));outputFolder = [];end
if(~exist('rangeN','var'));rangeN = [1 1];end
if(isempty(outputFolder));outputFolder = 'MRF';end%'ClusterLabeling';%
for testSet = 1:length(testStrings)
    TestDir = fullfile(HOMEDATA,testStrings{testSet});
    [labels{1,testSet} tests{1,testSet} gtInstLabelStats{1,testSet} objLabelStats{1,testSet} unionIntScores{1,testSet} pixStats] = EvaluateObjTests(HOMELABELSETS{1},fullfile(TestDir,outputFolder,'ObjectsPicked'),matchMetaData,rangeN);
    
    savefile = fullfile(TestDir,sprintf('ObjResults%s.txt',suffix));
    WriteToFile(savefile,labels(:,testSet), tests(:,testSet), gtInstLabelStats(:,testSet), objLabelStats(:,testSet), unionIntScores(:,testSet), pixStats);
end


function [labels tests gtInstLabelStats objLabelStats unionIntScores pixStats] = EvaluateObjTests(HOMELABEL,HOMETESTS,matchMetaData,rangeN)
dirR = dir(fullfile(HOMETESTS,'*'));
tests = cell(0);
for i = 3:length(dirR)
    if(dirR(i).isdir)
        tests{end+1} = dirR(i).name;
    end
end
perPixelRates = zeros(1,length(tests));
[foo labelset] = fileparts(HOMELABEL);
pfig = ProgressBar(sprintf('Evaluating Tests for: %s',labelset));
range = 1:length(tests);
if(~isempty(rangeN))
    range = rangeN(1):rangeN(2):length(tests);
end
unionIntScores = cell(size(tests));
pixStats = zeros(3,length(tests));
for i = range;
    [labels gtInstLabelStat objLabelStat unionIntScore pixStat] = EvaluateObjTest(HOMELABEL,fullfile(HOMETESTS,tests{i}),matchMetaData);
    if(~exist('gtInstLabelStats','var'))
        gtInstLabelStats=zeros([size(gtInstLabelStat) length(tests)]);
        objLabelStats=zeros([size(objLabelStat) length(tests)]);
    end
    pixStats(:,i) = pixStat;
    gtInstLabelStats(:,:,i) = gtInstLabelStat;
    objLabelStats(:,:,i) = objLabelStat;
    unionIntScores{i} = unionIntScore;
    ProgressBar(pfig,i,length(tests));
end
close(pfig);


function [labels gtInstLabelStats objLabelStats unionIntScores pixStats] = EvaluateObjTest(HOMELABEL,HOMETEST,matchMetaData)
files = dir_recurse(fullfile(HOMETEST,'*.mat'),0);
fields = [];
gtInstLabelStats = [];
if(isstruct(matchMetaData))
    fields = fieldnames(matchMetaData);
end
conMat = [];
unionIntScores.gtInstScore = [];
unionIntScores.gtInstL = [];
unionIntScores.objScore = [];
unionIntScores.objL = [];
pixStats = zeros(1,3);
for i = 1:length(files)
    [folder file] = fileparts(files{i});
    saveFile = fullfile(HOMETEST,[files{i} '.cache']);
    clear metaData conM instLabelStat;
    if(exist(saveFile,'file'))
        try
            clear pixStat;
            load(saveFile,'-mat');
            mustRedo = false;
            if(~exist('pixStat','var'))
                mustRedo = true;
            end
            for j = 1:length(fields)
                if(~isfield(metaData,fields{j}))
                    mustRedo = true; 
                end
            end
        catch
            mustRedo = true;
        end
    end
    %{
    %code for finding specific files with classifications of sepcific labels
    if(any(perLabelStat([45 53],:)>0))
        fprintf('%d %d/%d %d/%d\n',i,perLabelStat(45,1),perLabelStat(45,2),perLabelStat(53,1),perLabelStat(53,2));
        fprintf('');
    end
    %}
    if(~exist(saveFile,'file') ||  mustRedo)
        load(fullfile(HOMETEST,files{i})); %objs
        clear S_instances;
        load(fullfile(HOMELABEL,files{i})); %S S_instances names
        if(~exist('S_instances','var'))
            fold = fileparts(HOMELABEL);
            S_instances = AddSInstances(HOMELABEL,fullfile(fold,'Annotations'),files{i});
        end
        gtInstL = max(max(S_instances,[],1),[],2);gtInstL = gtInstL(:);
        metaFile = fullfile(HOMELABEL,'..','Metadata',files{i}); %metaData
        if(exist(metaFile,'file'))
            load(metaFile); % metadata
        end
        [gtInstLabelStat, objLabelStat, gtInstP, objP, pixStat] = EvaluateObjLabeling(objs,S,S_instances,gtInstL,names);
        if(~exist('metaData','var'))
            metaData=[];
        end
        objL = objs.Ls;
        save(saveFile,'gtInstLabelStat', 'objLabelStat', 'gtInstP', 'objP', 'objL','gtInstL','metaData','pixStat','-mat');
    end
    bad = 0;
    for j = 1:length(fields)
        if(~isfield(metaData,fields{j}) || ~strcmp(metaData.(fields{j}),matchMetaData.(fields{j})))
            bad = 1;
        end
    end
    if(bad); continue; end;
    pixStats = pixStats + pixStat;
    gtInstP(gtInstL==0) = [];gtInstL(gtInstL==0) = [];
    unionIntScores.gtInstScore = [unionIntScores.gtInstScore; gtInstP(:)];
    unionIntScores.gtInstL = [unionIntScores.gtInstL; gtInstL(:)];
    unionIntScores.objScore = [unionIntScores.objScore; objP(:)];
    unionIntScores.objL = [unionIntScores.objL; objL(:)];
    if(isempty(gtInstLabelStats))
        gtInstLabelStats = zeros(size(gtInstLabelStat));
        objLabelStats = zeros(size(objLabelStat));
    end
    gtInstLabelStat = (gtInstLabelStat./repmat(gtInstLabelStat(:,2),[1 2]));
    gtInstLabelStat(isnan(gtInstLabelStat)) = 0;
    gtInstLabelStats = gtInstLabelStats+gtInstLabelStat;
    objLabelStat = (objLabelStat./repmat(objLabelStat(:,2),[1 2]));
    objLabelStat(isnan(objLabelStat)) = 0;
    objLabelStats = objLabelStats+objLabelStat;
end
if(~exist('names','var'))
    load(fullfile(HOMELABEL,files{1})); %S names metadata
end
labels = names;


function WriteToFile(outFile,labels, tests, gtInstLabelStats, objLabelStats, unionIntScores, pixStats)
allTests = tests{1};
for i = 2:length(tests)
    allTests = unique([allTests tests{i}]);
end
fid = fopen(outFile,'w');
fprintf(fid,'Class\t# of Ground Truth Poly\t');
for i = 1:length(allTests)
    fprintf(fid,'%s\t',allTests{i});
end
fprintf(fid,'\n');
for i = 1:length(labels)
    
    [l c] = UniqueAndCounts(unionIntScores{i}{1}.gtInstL);
    instCounts = zeros(size(gtInstLabelStats{i},1),1);
    instCounts(l) = c;
    testInds = zeros(size(allTests));
    objCounts = zeros(size(gtInstLabelStats{i},1),length(tests{i}));
    for j = 1:length(tests{i})
        testInds(strcmp(tests{i}{j},allTests))=j;
        [l c] = UniqueAndCounts(unionIntScores{i}{j}.objL);
        objCounts(l,j) = c;
    end
    fprintf(fid,'# of Predicted Objects\t');
    fprintf(fid,'%d\t',fix(sum(instCounts)));
    for j = testInds(:)'
        fprintf(fid,'%d\t',fix(sum(objCounts(:,j))));
    end
    fprintf(fid,'\n');
    
    for thresh = [.5]
        fprintf(fid,'%s%.1f\t%d\t','Recall ',thresh,fix(sum(instCounts)));
        for j = testInds(:)'
            if(j==0); fprintf(fid,'0.00%%\t'); continue;end
            fprintf(fid,'%.3f\t',sum(unionIntScores{i}{j}.gtInstScore>thresh)./length(unionIntScores{i}{j}.gtInstL));
        end
        fprintf(fid,'\n');

        fprintf(fid,'%s%.1f\t%d\t','Precision ',thresh,fix(sum(instCounts)));
        for j = testInds(:)'
            if(j==0); fprintf(fid,'0.00%%\t'); continue;end
            fprintf(fid,'%.3f\t',sum(unionIntScores{i}{j}.objScore>thresh)./length(unionIntScores{i}{j}.objL));
        end
        fprintf(fid,'\n');
    end
        
    fprintf(fid,'%s\t%d\t','Pixel Precision',fix(sum(instCounts)));
    for j = testInds(:)'
        if(j==0); fprintf(fid,'0.00%%\t'); continue;end
        fprintf(fid,'%.3f\t',mean(pixStats(1,j)/pixStats(2,j)));
    end
    fprintf(fid,'\n');
    
    fprintf(fid,'%s\t%d\t','Pixel Recal',fix(sum(instCounts)));
    for j = testInds(:)'
        if(j==0); fprintf(fid,'0.00%%\t'); continue;end
        fprintf(fid,'%.3f\t',mean(pixStats(1,j)/pixStats(3,j)));
    end
    fprintf(fid,'\n');
    
    fprintf(fid,'%s\t%d\t','Average I/U GT Inst',fix(sum(instCounts)));
    for j = testInds(:)'
        if(j==0); fprintf(fid,'0.00%%\t'); continue;end
        fprintf(fid,'%.3f\t',mean(unionIntScores{i}{j}.gtInstScore));
    end
    fprintf(fid,'\n');
    
    fprintf(fid,'%s\t%d\t','Average I/U Pred Objs',fix(sum(instCounts)));
    for j = testInds(:)'
        if(j==0); fprintf(fid,'0.00%%\t'); continue;end
        fprintf(fid,'%.3f\t',mean(unionIntScores{i}{j}.objScore));
    end
    fprintf(fid,'\n');
    
    fprintf(fid,'%s\t%d\t','Average I/U GT Inst Per-Im norm',fix(sum(instCounts)));
    for j = testInds(:)'
        if(j==0); fprintf(fid,'0.00%%\t'); continue;end
        fprintf(fid,'%.3f\t',sum(gtInstLabelStats{i}(:,1,j))/sum(gtInstLabelStats{i}(:,2,j)));
    end
    fprintf(fid,'\n');
    
    fprintf(fid,'%s\t%d\t','Average I/U Pred Objs Per-Im norm',fix(sum(instCounts)));
    for j = testInds(:)'
        if(j==0); fprintf(fid,'0.00%%\t'); continue;end
        fprintf(fid,'%.3f\t',sum(objLabelStats{i}(:,1,j))/sum(objLabelStats{i}(:,2,j)));
    end
    fprintf(fid,'\n');
    fprintf(fid,'\n');
    
    %fprintf(fid,'%s\t','Mean Class');
    %fprintf(fid,'%d\t',fix(sum(instCounts)));
    [foo labelOrder] = sort(instCounts,'descend');
    %for j = testInds(:)'
    %    if(j==0); fprintf(fid,'0.00%%\t'); continue;end
    %    fprintf(fid,'%.3f%%\t',100.*mean((perLabelStats{i}(instCounts~=0,1,j)./perLabelStats{i}(instCounts~=0,2,j))));
    %end
    %fprintf(fid,'\n');
    
    for l = labelOrder(:)'
        if(instCounts(l)==0);continue;end
        
        for thresh = [.5]
            fprintf(fid,'%s Recall %.1f\t%d\t',labels{i}{l},thresh,fix(instCounts(l)));
            for j = testInds(:)'
                if(j==0); fprintf(fid,'0.00%%\t'); continue;end
                fprintf(fid,'%.3f\t',sum(unionIntScores{i}{j}.gtInstScore(unionIntScores{i}{j}.gtInstL==l)>thresh)./sum(unionIntScores{i}{j}.gtInstL==l));
            end
            fprintf(fid,'\n');

            fprintf(fid,'%s Precision %.1f\t%d\t',labels{i}{l},thresh,fix(instCounts(l)));
            for j = testInds(:)'
                if(j==0); fprintf(fid,'0.00%%\t'); continue;end
                fprintf(fid,'%.3f\t',sum(unionIntScores{i}{j}.objScore(unionIntScores{i}{j}.objL==l)>thresh)./sum(unionIntScores{i}{j}.objL==l));
            end
            fprintf(fid,'\n');
        end
        
        fprintf(fid,'%s GT Inst\t%d\t',labels{i}{l},fix(instCounts(l)));
        for j = testInds(:)'
            if(j==0); fprintf(fid,'0.00%%\t'); continue;end
            fprintf(fid,'%.3f\t',mean(unionIntScores{i}{j}.gtInstScore(unionIntScores{i}{j}.gtInstL==l)));
        end
        fprintf(fid,'\n');
        
        fprintf(fid,'%s Pred Objs\t%d\t',labels{i}{l},fix(instCounts(l)));
        for j = testInds(:)'
            if(j==0); fprintf(fid,'0.00%%\t'); continue;end
            fprintf(fid,'%.3f\t',mean(unionIntScores{i}{j}.objScore(unionIntScores{i}{j}.objL==l)));
        end
        fprintf(fid,'\n');
        
        fprintf(fid,'%s GT Inst Per-Im norm\t%d\t',labels{i}{l},fix(instCounts(l)));
        for j = testInds(:)'
            if(j==0); fprintf(fid,'0.00%%\t'); continue;end
            fprintf(fid,'%.3f\t',gtInstLabelStats{i}(l,1,j)./gtInstLabelStats{i}(l,2,j));
        end
        fprintf(fid,'\n');
        
        fprintf(fid,'%s Pred Objs Per-Im norm\t%d\t',labels{i}{l},fix(instCounts(l)));
        for j = testInds(:)'
            if(j==0); fprintf(fid,'0.00%%\t'); continue;end
            fprintf(fid,'%.3f\t',objLabelStats{i}(l,1,j)./objLabelStats{i}(l,2,j));
        end
        fprintf(fid,'\n');
    end
    fprintf(fid,'\n');
end
fclose(fid);


