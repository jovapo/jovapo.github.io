function [S_instances] = AddSInstances(HOMELABEL,HOMEANN,file)

load(fullfile(HOMELABEL,file));
if(~exist('S_instances','var'))
    [fold base] = fileparts(file);
    ann.annotation = LMread(fullfile(HOMEANN,fold,[base '.xml']));
    [ro co] = size(S);
    [S_instances] = LMobjectmask(ann.annotation, [ro co]);
    objL = zeros(size(S_instances,3),1);
    for i = 1:length(objL)
        objL(i) = str2double(ann.annotation.object(i).namendx);
        S_instances(:,:,i) = objL(i)*S_instances(:,:,i);
    end
    if(exist('metaData','var'))
        save(fullfile(HOMELABEL,file),'S','S_instances','names','metaData');
    else
        save(fullfile(HOMELABEL,file),'S','S_instances','names');
    end
    %LM2segments(ann,[],HOMEIMAGES,HOMELABEL);
end
    