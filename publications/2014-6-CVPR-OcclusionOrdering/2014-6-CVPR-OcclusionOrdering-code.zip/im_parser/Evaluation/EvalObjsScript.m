%SetUpConstants;
if(~exist('rangeN','var'))
    rangeN = [];
end
EvaluateObjs(HOMEDATA,HOMELABELSETS(UseLabelSet),{testParams.TestString},testParams.MRFFold,testParams.MRFFold,[],rangeN);
    