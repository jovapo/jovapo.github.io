LoadForDetectors;

dataset_params.datadir = HOMEDATA;
dataset_params.localdir = '';%fullfile(HOMEDATA,testParams.TestString);
dataset_params.display = 0;
detectorParams = esvm_get_default_params;
detectorParams.dataset_params = dataset_params;
detectorParams.preComputeHOG = false;
%detectorParams.init_params.sbin = 4; %for siftflow
detectorParams.init_params.sbin = trainSBin;
detectorParams.init_params.goal_ncells = 100;

train_params = detectorParams;
%train_params.detect_max_scale = 1; %for siftflow
train_params.detect_max_scale = trainMaxScale;
train_params.detect_exemplar_nms_os_threshold = 1.0; 
train_params.detect_max_windows_per_exemplar = 100;
train_params.ordering = 1:length(trainFileList);
%train_params.queue_mode  = 'cycle-violators';

if(~exist('mineImsWithLabel','var'))
    mineImsWithLabel = false;
end
if(mineImsWithLabel || exist('minNegOptions','var'))
    mine_all_gt_labels = cell(size(trainFileList));
    for i= 1:length(trainFileList)
        [fold base] = fileparts(trainFileList{i});
        tmp = load(fullfile(HOMELABELSETS{1},fold,[base '.mat']));
        mine_all_gt_labels{i} = tmp.S;
    end
end

val_params = detectorParams;
val_params.detect_exemplar_nms_os_threshold = 0.5;
val_params.gt_function = @sp_load_gt_function;

myRandomize;
notDone = [];
rp = randperm(length(trainFileList));
%rp = 1:length(trainFileList);
rp = rangeTrain;

%% arun code begins
% check if background stats have already been computed

addpath(genpath(pwd));

bgFile = fullfile(HOMECLASSIFIER,'BG.mat');make_dir(bgFile);
if 0%exist(bgFile, 'file')
  
    fprintf('Background stats have been computed previously.\nLoading them from disk.\n\n');
    load(bgFile)
    
else
    % just get a structure with all file paths 

    fprintf('Computing background stats for the first time.\n\n');
    
    all_image_file_paths = struct('im', {});

    for rpndx = 1:length(rp)
        all_image_file_paths(end + 1).im = trainFileListFull{rpndx};
    end

    % now that we have the paths, run the trainBackground code to get the mean
    % and covariance matrices 

    % covariance matrix is reconstructed from spatial autocorrelation matrix of given order
    % order is max expected windows of HOG feature, here it is fixed to
    % value used below
    order = detectorParams.init_params.MAXDIM; 
    
    % levels per octave (esvm_initialize_goalsize_exemplar uses 10 in its params)
    interval = detectorParams.detect_levels_per_octave;
    
    % borrowed from above
    sbin = trainSBin; 

    % use trainBG from WHOG code
    timerVar = tic;
    BG = trainBGESVM(all_image_file_paths, train_params);
    timerVar=toc(timerVar);

    save(bgFile,'BG'); % save learnt background statistics
    
end
%% arun code ends


lastMaxMined = 0;
pfig = ProgressBar('Learning Detectors');
for rpndx = 1:length(rp)
    i = rp(rpndx);
    [fold base] = fileparts(trainFileList{i});
    LDAFile = fullfile(HOMECLASSIFIER,'LDA',fold,[base '.mat']);make_dir(LDAFile);
    if(exist(LDAFile,'file'))
        try
            load(LDAFile);
        catch
            delete(LDAFile);
        end
    end
    if(~exist(LDAFile,'file'))
        fprintf('Starting\n');
        initFile = fullfile(HOMECLASSIFIER,'InitModel',fold,[base '.mat']);make_dir(initFile);
        if(exist(initFile,'file'))
            try
                load(initFile);
            catch
                delete(initFile);
            end
        end
        if(~exist(initFile,'file'))
            e_stream_set = GetDetectorStreamForSingleLM(HOMEIMAGES, HOMEDATA, fullfile(HOMEANNOTATIONS,fold,[base '.xml']), detectorParams);
            %e_stream_set = e_stream_set(1:2);
            models = esvm_initialize_exemplars(e_stream_set, detectorParams, '');
            save(initFile,'models');
        end

        %% arun code begins

        % find the LDA model for each object in structure
        %m2488 = load(fullfile(HOMECLASSIFIER,'Model2488',fold,[base '.mat']));
        %m360 = load(fullfile(HOMECLASSIFIER,'Model360',fold,[base '.mat']));
        for index = 1 : numel(models)

            HOG = models{index}.model.w;
            HOG = HOG(:);

            feature_size = models{index}.model.hg_size;

            [LDA_w, LDA_bias] = learn_LDA(HOG, feature_size, BG);

            models{index}.model.w = LDA_w;
            models{index}.model.b = LDA_bias;
            %{
            figure(1);showHOG(LDA_w);
            figure(2);showHOG(reshape(HOG,feature_size));
            figure(3);showHOG(m360.models{index}.model.w);
            figure(4);showHOG(m2488.models{index}.model.w);
            %}
        end

        %% arun code ends
        fprintf('Finished\n');
        save(LDAFile,'models');
    end
    ProgressBar(pfig,find(i==rp),length(rp));
    fprintf('%d/%d\n',find(i==rp),length(rp));
end
close(pfig);


