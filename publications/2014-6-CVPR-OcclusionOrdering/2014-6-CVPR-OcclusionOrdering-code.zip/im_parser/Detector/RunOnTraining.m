SetUpConstants;

%{
justDetectors=true;
if(~exist('loadDone','var') || loadDone == false)
    LoadData2;
end
loadDone = true;
testParams.Rs = Rs;
%}

%% compute region and detector dataterms for both test and training sets
temp = testParams.TestString;
placeHolder = cell(size(HOMELABELSETS));
[fo, rotFold] = fileparts(HOMERUNONTRAINING);
testParams.TestString = rotFold;
testParams.range = rangeTrain;
testParams.justSubSample = true;
testParams.detect_keep_threshold = [0 .25 .5 1];
%fullSPDesc{1} = LoadSegmentDesc(trainFileList,trainIndex{1},HOMEDATA,testParams.segmentDescriptors,testParams.K(1),testParams.segSuffix);
timing = ParseTestImagesWDetectors(HOMEDATA,HOMEDATA,HOMELABELSETS,trainFileList,trainGlobalDesc,trainFileList,trainGlobalDesc,[],[],[],Labels,classifiers,placeHolder,testParams);%,fullSPDesc);
    