backOutString = '../';
if(isempty(fold))
    fold = '.';
    backOutString = '';
else
    [f b] = fileparts(fold);
    if(~isempty(f))
        backOutString = '../../';
    end
end
ImageWebFold = fullfile(ObjectWebFold,'ImageWeb');
imageWebPage = fullfile(ImageWebFold,fold,[base '.htm']);make_dir(imageWebPage);
imFID = fopen(imageWebPage,'w');
fprintf(imFID,'<HTML>\n<HEAD>\n<TITLE>%s %s</TITLE>\n</HEAD>\n<BODY>',fold,base);
fprintf(imFID,'<img  width="256" src="%s"><br> ',['../' backOutString 'Images/' fold '/' base ext]);

fprintf(imFID,'\n<table border="0">\n');
fprintf(imFID,'\t<tr>\n');

labelBBS = test_struct.final_boxes;
overlap = .3;

genIm = false;

bbcount = cellfun(@(x) size(x,1),labelBBS);
[~, labelOrder] = sort(bbcount,'descend');

for l = labelOrder%find(strcmp(Labels{1},'car'))% 
    boxes = labelBBS{l};
    if(isempty(boxes))
        continue;
    end
    clusters = cell(0);
    x1 = boxes(:,1);
    y1 = boxes(:,2);
    x2 = boxes(:,3);
    y2 = boxes(:,4);
    s = boxes(:,end);

    area = (x2-x1+1) .* (y2-y1+1);
    [vals, I] = sort(s);

    pick = s*0;
    counter = 1;
    while ~isempty(I)
      last = length(I);
      bbNdx = I(last);  
      pick(counter) = bbNdx;
      counter = counter + 1;

      xx1 = max(x1(bbNdx), x1(I(1:last-1)));
      yy1 = max(y1(bbNdx), y1(I(1:last-1)));
      xx2 = min(x2(bbNdx), x2(I(1:last-1)));
      yy2 = min(y2(bbNdx), y2(I(1:last-1)));

      w = max(0.0, xx2-xx1+1);
      h = max(0.0, yy2-yy1+1);

      o = w.*h ./ area(I(1:last-1));

      clusters{end+1,1} = I([last; find(o>overlap)]);
      I([last; find(o>overlap)]) = [];
    end

    saveFileNameBase = fullfile(fold,base,Labels{1}{l});
    make_dir(fullfile(ImageWebFold,saveFileNameBase));
    saveFileNameWebBase = [ base '/' Labels{1}{l}];
    
    imFileName = fullfile(ImageWebFold,[saveFileNameBase '-all.png']);
    colors = 'grbymcwkgrbymcwkgrbymcwkgrbymcwkgrbymcwkgrbymcwkgrbymcwkgrbymcwkgrbymcwkgrbymcwkgrbymcwkgrbymcwkgrbymcwkgrbymcwkgrbymcwk';
    if(~exist(imFileName,'file') && genIm)
        show(im,1);
        figure(1);hold on;
        for j = 1:size(clusters,1)
            top = boxes(clusters{j},:);
            for k = 1:length(clusters{j})
                if(top(k,3)-top(k,1) <=0 || top(k,4)-top(k,2) <= 0)
                    continue;
                end
                rectangle( 'Position',[top(k,1) top(k,2) top(k,3)-top(k,1) top(k,4)-top(k,2)],'LineWidth',2,'EdgeColor','g');%colors(j));%
            end
        end
        hold off;
        export_fig(imFileName);%'-nocrop',
    end
    fprintf(imFID,'\t\t<td><center>%s<br><img  width="256" src="%s"><br>\n',Labels{1}{l},[saveFileNameWebBase '-all.png']);
    
    numBBs = cellfun(@(x) length(x),clusters);
    score = cellfun(@(x) sum(s(x)+1),clusters);
    fprintf(imFID,'All Boxes <br> Number of BBs: %d</center></td>\n',sum(numBBs));
    
    bbNdx = cellfun(@(x) x(1), clusters);
    baseBB = [boxes(bbNdx,1:4) repmat(i,size(score)) repmat(l,size(score)) score numBBs];
    baseExpanded = [cell2mat(cellfun2(@(x) [min(boxes(x,1:2),[],1) max(boxes(x,3:4),[],1)],clusters)) repmat(i,size(score)) repmat(l,size(score)) score numBBs];
    
    allBB.baseBB = [allBB.baseBB; baseBB];
    allBB.baseExpanded = [allBB.baseExpanded; baseExpanded];
    
    clustersAll = clusters;
    rmInd = (numBBs/max(numBBs))<.1;
    clusters(rmInd) = [];
    baseRm = baseBB;baseRm(rmInd,:) = [];
    baseExpandedRm = baseExpanded;baseExpandedRm(rmInd,:) = [];
    allBB.prunClSize = [allBB.prunClSize; baseRm];
    allBB.prunClSizeExpanded = [allBB.prunClSizeExpanded; baseExpandedRm];
    imFileName = fullfile(ImageWebFold,[saveFileNameBase '-prun-clsz.png']);
    if(~exist(imFileName,'file') && genIm)
        show(im,1);
        figure(1);hold on;
        for j = 1:size(clusters,1)
            for k = 1:length(clusters{j})
                top = boxes(clusters{j},:);
                if(top(k,3)-top(k,1) <=0 || top(k,4)-top(k,2) <= 0)
                    continue;
                end
                rectangle( 'Position',[top(k,1) top(k,2) top(k,3)-top(k,1) top(k,4)-top(k,2)],'LineWidth',2,'EdgeColor',colors(j));%'g');%
            end
        end
        hold off;
        export_fig(imFileName);%'-nocrop',
    end
    fprintf(imFID,'\t\t<td><center>Prune By Cluster Size<br> <img  width="256" src="%s"><br>\n',[saveFileNameWebBase '-prun-clsz.png']);
    numBBsRm=numBBs;
    numBBsRm(rmInd) = [];
    fprintf(imFID,' Number of BBs: %d<br>Max Cluster Size: %d</center></td>\n',sum(numBBsRm),max(numBBsRm));
    
    rmInd = (score/max(score))<.1;
    clusters = clustersAll;
    clusters(rmInd) = [];
    baseRm = baseBB;baseRm(rmInd,:) = [];
    baseExpandedRm = baseExpanded;baseExpandedRm(rmInd,:) = [];
    allBB.prunClScore = [allBB.prunClScore; baseRm];
    allBB.prunClScoreExpanded = [allBB.prunClScoreExpanded; baseExpandedRm];
    
    imFileName = fullfile(ImageWebFold,[saveFileNameBase '-prun-score.png']);
    if(~exist(imFileName,'file') && genIm)
        show(im,1);
        figure(1);hold on;
        for j = 1:size(clusters,1)
            for k = 1:length(clusters{j})
                top = boxes(clusters{j},:);
                if(top(k,3)-top(k,1) <=0 || top(k,4)-top(k,2) <= 0)
                    continue;
                end
                rectangle( 'Position',[top(k,1) top(k,2) top(k,3)-top(k,1) top(k,4)-top(k,2)],'LineWidth',2,'EdgeColor',colors(j));%'g');%
            end
        end
        hold off;
        export_fig(imFileName);%'-nocrop',
    end
    fprintf(imFID,'\t\t<td><center>Prune By Cluster Score<br> <img  width="256" src="%s"><br>\n',[saveFileNameWebBase '-prun-score.png']);
    numBBsRm=numBBs;
    numBBsRm(rmInd) = [];
    fprintf(imFID,' Number of BBs: %d<br>Max Cluster Score: %.3f</center></td>\n',sum(numBBsRm),max(score));
    
    fprintf(imFID,'\t</tr><tr>\n');
end
fprintf(imFID,'\t</tr>\n</table></center>');
fprintf(imFID,'</BODY>\n</HTML>');
fclose(imFID);