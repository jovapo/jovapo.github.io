SetUpConstants;

[foo LabelSetFold] = fileparts(HOMELABELSETS{1});
sampleSize = 1e6;

%{-
testDataFile = fullfile(TestFold,sprintf('PreSVMData-MM%04d.mat',testParams.MaxModelPerCls));
trainDataFile = fullfile(HOMERUNONTRAINING,[svmFold 'Data.mat']);
if(exist(trainDataFile,'file'))
    load(trainDataFile);
else
    %detFiles = dir_recurse(fullfile(HOMERUNONTRAINING,'ExemplarDataTerm',detectorFold,'*'),0);
    detFiles = trainFileList;
    dataFile = fullfile(HOMERUNONTRAINING,'svmTrainingSplitInd.mat');
    load(dataFile);
    
    
    i = 1;evnStart = 1;uniStart=1;
    %{
    pfig = ProgressBar('Loading SVM training Data');
    for f = 1:length(detFiles)
        [fold base] = fileparts(detFiles{f});
        saveIndFile = fullfile(HOMERUNONTRAINING,'SubSample',fold,[base '.mat']);
        load(fullfile(HOMELABELSETS{1},fold,[base '.mat'])); %S (ro x co) names
        label = S(:);
        indImEvn = indEvn(indEvn>=i & indEvn<(i+length(label)))-i+1;
        indImUni = indUni(indUni>=i & indUni<(i+length(label)))-i+1;
        i = i+length(label);
        make_dir(saveIndFile);save(saveIndFile,'indImEvn','indImUni');
        if(mod(f,10)==0)
            ProgressBar(pfig,f,length(detFiles));
        end
    end
    close(pfig);
    %}
    %{-
    deleteCount = 0;
    myRandomize;
    for f = randperm(length(trainFileList))
        [fold base] = fileparts(trainFileList{f});
        saveFeatFile = fullfile(HOMERUNONTRAINING,'SubSampleFeats',fold,[base '.mat']);
        if(~exist(saveFeatFile,'file'))
            fsp = find(~cellfun(@(x) isempty(x),strfind(detFiles,strrep([fullfile(fold,base) '.'],filesep,'\'))));
            if(length(fsp)~=1)
                fprintf('miss match %s %s\n',fold,base);
                continue;
            end
            if(fsp~=f)
                fprintf('miss match %s %s\n',fold,base);
            end
            try
                %{-
                %load(saveIndFile);
                load(fullfile(HOMELABELSETS{1},fold,[base '.mat'])); %S (ro x co) names
                label = S(:);
                try
                load(fullfile(HOMERUNONTRAINING,'ExemplarDataTerm',detectorFold,fold,[base '.mat'])); %dataTerm (ro x co x #l) dataTermMax
                catch ME
                    if(any(strcmp(ME.identifier,{'MATLAB:load:unableToReadMatFile','MATLAB:load:notBinaryFile','MATLAB:load:couldNotReadFile'})))
                        deleteCount = deleteCount +1;
                        fprintf('Deleting %d: %s\n',deleteCount,fullfile(fold,[base '.mat']));
                        %delete(fullfile(HOMERUNONTRAINING,'ExemplarDataTerm',detectorFold,fold,[base '.mat']));
                        continue;
                    else
                        keyboard;
                    end
                end
                a = load(fullfile(HOMERUNONTRAINING,LabelSetFold,parserFold,fold,[base '.mat'])); %probPerLabel (#SP x #l)
                if(isfield(a,'probPerLabel'))
                    probPerLabel = a.probPerLabel;
                elseif(isfield(a,'prob'))
                    probPerLabel = a.prob;
                end
                load(fullfile(HOMEDATA,'Descriptors',spFold,'super_pixels',fold,[base '.mat'])); %superPixels (ro x co)
                %}-
                ann = LMread(fullfile(HOMEANNOTATIONS,fold,[base '.xml']));
            catch ME
                ME
                continue;
            end
            [ro co ch] = size(dataTerm);
            %{-
            uSP = unique(superPixels);
            spMap = zeros(max(uSP),1);
            spMap(uSP) = 1:length(uSP);
            feat = [probPerLabel(spMap(superPixels),:) reshape(dataTerm,[],size(dataTerm,3))];
            %}-

            indImEvn = indEvn(indEvn>=startPoint(fsp) & indEvn<startPoint(fsp+1))-startPoint(fsp)+1;
            indImUni = indUni(indUni>=startPoint(fsp) & indUni<startPoint(fsp+1))-startPoint(fsp)+1;
            
            lEvn = label(indImEvn);
            [Y, X] = ind2sub([ro co],indImEvn);
            lEvnOvLp = PointsToPolyLabels( ann, X, Y, length(names) );
            fEvn = feat(indImEvn,:);

            lUni= label(indImUni);
            [Y, X] = ind2sub([ro co],indImUni);
            lUniOvLp = PointsToPolyLabels( ann, X, Y, length(names) );
            fUni = feat(indImUni,:);

            make_dir(saveFeatFile); save(saveFeatFile,'lEvn','lEvnOvLp','fEvn','indImEvn','lUni','lUniOvLp','fUni','indImUni','-v7.3');
            clear feat;
        end
    end
    %}
    clear feats labels;
end