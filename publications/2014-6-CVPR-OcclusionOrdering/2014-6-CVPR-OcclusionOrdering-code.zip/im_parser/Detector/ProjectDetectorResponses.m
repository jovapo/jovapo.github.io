function [dataTerm dataTermMax] = ProjectDetectorResponses( im, bbs, models, min_val, pb)
%PROJECTDETECTORRESPONSES Summary of this function goes here
%   Detailed explanation goes here

if(~exist('min_val','var'))
    min_val = -1;
end

%polygons = cellfun2(@(x) x.polygon.pt,models);

[ro co ch] = size(im);
dataTerm = zeros(ro,co);
dataTermMax = zeros(ro,co);

projPolys = ProjectDetectorPolygons(bbs, models);

for i = 1:size(bbs,1)
    score = bbs(i,end)-min_val;
    if(score<0)
        continue;
    end
    mask = poly2mask(projPolys(i).x,projPolys(i).y,ro,co);
    dataTerm = dataTerm + mask.*score;
    if(exist('pb','var'))
        b = bwboundaries(mask);
        maskEdge = zeros(size(mask));
        maskEdge(sub2ind(size(mask),b{1}(:,1),b{1}(:,2))) = 1;
        
        alpha = .012;
        ratio = 0.5;
        minWidth = 10;
        nOuterFPIterations = 7;
        nInnerFPIterations = 1;
        nSORIterations = 20;
        para = [alpha,ratio,minWidth,nOuterFPIterations,nInnerFPIterations,nSORIterations];
        [vx,vy,warpI2] = Coarse2FineTwoFrames(double(pb),maskEdge,para);
        dataTermMax = dataTermMax + (warpFL(mask,vx,vy)>0).*score;
        %displayIm = zeros(size(im));displayIm(:,:,1) = pb;
        %show(pb,1);displayIm(:,:,2) = maskEdge;show(displayIm,2);displayIm(:,:,2) = warpI2;show(displayIm,3);flow(:,:,1) = vx;flow(:,:,2) = vy;show(flowToColor(flow),4);
        %displayIm(:,:,1) = mask; displayIm(:,:,2) = warpFL(mask,vx,vy);show(displayIm,5);
    else
        if(nargout > 1)
            dataTermMax = max(dataTermMax,mask.*score);
        end
    end
    %show(dataTerm,1);
    %{
    figure(1);
    hold on;
    axis([0 co 0 ro]);axis equal;
    rectangle('Position',[gtbb(1) gtbb(2) gtbb(3)-gtbb(1) gtbb(4)-gtbb(2)]);
    fill(poly.x,poly.y,'r');
    rectangle('Position',[tbb(1) tbb(2) tbb(3)-tbb(1) tbb(4)-tbb(2)]);
    fill(poly2.x,poly2.y,'r');
    %}
    
end


end

