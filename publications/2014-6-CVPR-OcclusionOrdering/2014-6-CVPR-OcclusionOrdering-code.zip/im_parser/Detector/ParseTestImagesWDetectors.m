function timing = ParseTestImagesWDetectors(HOMEDATA,HOMETESTDATA,HOMELABELSETS,testFileList,testGlobalDesc,trainFileList,trainGlobalDesc,trainIndex,trainCounts,labelPenality,Labels,classifiers,globalSVM,testParams,fullSPDesc)

if(isfield(testParams,'justSubSample') && testParams.justSubSample)
    dataFile = fullfile(HOMEDATA,testParams.TestString,'svmTrainingSplitInd.mat');
    ssData = load(dataFile);
end
TestFold = fullfile(HOMETESTDATA,testParams.TestString);
if(~exist('fullSPDesc','var'))
    fullSPDesc = cell(length(HOMELABELSETS),length(testParams.K));
end
probType = 'ratio';
if(isfield(testParams,'probType'))
    probType = testParams.probType;
end

if(~isfield(testParams,'segSuffix'))
    testParams.segSuffix = '';
end

HOME = fileparts(HOMEDATA);

dataset_params.datadir = HOMEDATA;
dataset_params.localdir = '';%fullfile(HOMEDATA,testParams.TestString);
dataset_params.display = 0;
detectorParams = esvm_get_default_params;
detectorParams.dataset_params = dataset_params;
%if(strcmp(testParams.ModelFold,'LDA'))
%    detectorParams.detect_keep_threshold = testParams.detect_keep_threshold;
%end
%detectorParams.calibration_threshold = testParams.calibration_threshold;
lc = [rand([length(Labels{1}) 3]); [0 0 0]];

display = false;

%close all;
pfig = ProgressBar('Parsing Images');
range = 1:length(testFileList);
if(isfield(testParams,'range'))
    range = testParams.range;
end
timing = zeros(length(testFileList),4);
glSuffix = '';
%range = range(randperm(length(range)));
for i = range(:)'
    fprintf('Starting %s\n',testFileList{i});
    [fold base] = fileparts(testFileList{i});
    load(fullfile(HOMELABELSETS{1},fold,[base '.mat'])); %S (ro x co) names
    busyFile = fullfile(TestFold,'Busy',fold,base);
    if(isfield(testParams,'doneDir'))
        if(exist(fullfile(TestFold,'ML',testParams.doneDir,fold,[base '.mat']),'file'))
            fprintf('Already Done\n');
            continue;
        end
    end
    if(isfield(testParams,'BusyFold'))
        busyFile = fullfile(TestFold,testParams.BusyFold,fold,base);
    end
    if(exist(busyFile,'file'))
        continue;
    end
    %mkdir(busyFile);
    %try
    im = imread(fullfile(HOME,'Images',testFileList{i}));
    [ro co ch] = size(im);
    baseFName = fullfile(fold,base);
    timingFile = fullfile(TestFold,'Timing',fold,[base '.mat']);make_dir(timingFile);
    fileStats = [];
    if(exist(timingFile,'file'))
        try
            load(timingFile);
        catch
            delete(timingFile);
        end
    end
    fileStats.imSize = [ro co];
    
    timeRetSet=tic;  [retInds rank]= FindRetrievalSet(trainGlobalDesc,SelectDesc(testGlobalDesc,i,1),TestFold,baseFName,testParams,glSuffix);  timeRetSet=toc(timeRetSet);
    if(~isfield(fileStats,'timeRetSet') || fileStats.timeRetSet<timeRetSet)
        fileStats.timeRetSet=timeRetSet;
    end
    rmInds = find(strcmp(trainFileList,testFileList{i}));
    if(isfield(testParams,'numFrames2Skip'))
        rmInds = [rmInds-testParams.numFrames2Skip:rmInds+testParams.numFrames2Skip];
    end
    [a keepInds] =setdiff(retInds,rmInds);
    keepInds = sort(keepInds);
    retInds = retInds(keepInds);
    
    svmstr = '';
    %% Short List Comp
    shortListMask = cell(size(Labels));
    for ls=1:length(HOMELABELSETS)
        if(~isempty(globalSVM{ls}))
            svmstr = testParams.SVMType;
            if(isfield(testParams,'SVMSoftMaxCutoff'))
                fs = svmShortListSoftMax(globalSVM(ls,:),SelectDesc(testGlobalDesc,i,1),testParams.SVMDescs);
                shortListInds = fs>=testParams.SVMSoftMaxCutoff{ls};
                if(all(~shortListInds))
                    [foo ind] = max(fs);
                    shortListInds(ind) = 1;
                end
            elseif(strcmp(testParams.SVMType,'SVMPerf'))
                dataFile = fullfile(HOMELABELSETS{ls},fold,[base '.mat']);
                load(dataFile); %S names
                shortListInds = zeros(size(names));
                ind = unique(S(:));
                ind(ind<1) = [];
                shortListInds(ind)=true;
            elseif(strcmp(testParams.SVMType,'SVMTop10'))
                [~, ind] = sort(trainCounts{ls},'descend');
                shortListInds = zeros(size(trainCounts{ls}));
                shortListInds(ind(1:min(end,10)))=true;
            elseif(strcmp(testParams.SVMType,'SVMLPBP'))
                svmstr = [testParams.SVMType num2str(testParams.svmLPBPItt)];
                [shortListInds] = svmShortListLPBPSoftMax(globalSVM{ls}(testParams.svmLPBPItt),SelectDesc(testGlobalDesc,i,1),testParams.SVMDescs);
            elseif(length(globalSVM{ls}) ==2)
                svmOutput = [];
                [shortListInds svmOutput.svm]  = svmShortList(globalSVM{ls}{1},SelectDesc(testGlobalDesc,i,1),testParams.SVMDescs,0);
                [shortListInds fs] = svmShortList(globalSVM{ls}{2},svmOutput,{'svm'},0);
            else
                shortListInds = svmShortList(globalSVM{ls},SelectDesc(testGlobalDesc,i,1),testParams.SVMDescs,0);
            end
        elseif(isfield(testParams,'SVMOutput'))
            shortListInds = testParams.SVMOutput{ls}(i,:)>0;
            minSL = 1;
            if(sum(shortListInds)<minSL)
                [a inds] = sort(testParams.SVMOutput{ls}(i,:),'descend');
                shortListInds(inds(1:minSL)) = true;
            end
            svmstr = [testParams.SVMType 'Min' num2str(minSL)];
            Labels{ls}(shortListInds)
        else
            shortListInds = ones(size(Labels{ls}));
        end
        shortListMask{ls} = shortListInds==1;
    end
    
    if(isfield(testParams,'RetrievalMetaMatch'))
        if(strcmp('GroundTruth',testParams.RetrievalMetaMatch))
            svmstr = [svmstr 'RetGT'];
            metaFields = fieldnames(testParams.TrainMetadata);
            totalMask = ones(size(retInds))==1;
            for f = 1:length(metaFields)
                mask = strcmp(testParams.TrainMetadata.(metaFields{f})(retInds),testParams.TestMetadata.(metaFields{f}){i});
                totalMask = mask&totalMask;
            end
            retInds = retInds(totalMask);
        end
        if(strcmp('SVM',testParams.RetrievalMetaMatch))
            svmstr = [svmstr 'RetSVM'];
            metaFields = fieldnames(testParams.TrainMetadata);
            totalMask = ones(size(retInds))==1;
            for f = 1:length(metaFields)
                mask = strcmp(testParams.TrainMetadata.(metaFields{f})(retInds),testParams.TestMetadataSVM.(metaFields{f}){i});
                totalMask = mask&totalMask;
            end
            retInds = retInds(totalMask);
        end
    end
    
    %% Superpixel dataterm
    if(~isempty(trainIndex))
        FGSet = 0;Kndx = 1;
        classifierStr = repmat('0',[1 length(HOMELABELSETS)]);
        preStr = '';
        probSuffix = sprintf('K%d',testParams.K(Kndx));
        clear imSP testImSPDesc;
        [testImSPDesc imSP] = LoadSegmentDesc(testFileList(i),[],HOMETESTDATA,testParams.segmentDescriptors,testParams.K,testParams.segSuffix);
        probPerLabel = cell(size(HOMELABELSETS));
        dataCost = cell(size(probPerLabel));
        for ls=1:length(HOMELABELSETS)
            [foo labelSet] = fileparts(HOMELABELSETS{ls});
            if(strcmp(labelSet,'LabelsForgroundBK'))
                FGSet = ls;
            end
            if(isempty(classifiers{ls}))
                if(testParams.retSetSize == length(trainFileList) )
                    retSetIndex = trainIndex{ls,Kndx};
                else
                    [retSetIndex descMask] = PruneIndex(trainIndex{ls,Kndx},retInds,testParams.retSetSize,testParams.minSPinRetSet);
                end
                suffix = sprintf('R%dK%dTNN%d',testParams.retSetSize,testParams.K(Kndx),testParams.targetNN);%nn%d  ,testParams.targetNN
                suffix = [suffix testParams.globalDescSuffix];
                suffix = [suffix glSuffix];
                probSuffix = [suffix '-sc' myN2S(testParams.smoothingConst) probType];
                labelNums = 1:length(trainCounts{ls});
                probPerLabel{ls} = GetAllProbPerLabel(fullfile(TestFold,labelSet),baseFName,probSuffix,retSetIndex,[],labelNums,trainCounts{ls,Kndx},probType,testParams.smoothingConst,1); %#ok<AGROW>
                if(~isempty(probPerLabel{ls}) && size(probPerLabel{ls},1)~=size(testImSPDesc.sift_hist_dial,1))
                    suffix = [suffix 'added'];
                    probPerLabel{ls} = [];
                end
                if(isempty(probPerLabel{ls}))
                    rawNNs = DoRNNSearch(testImSPDesc,[],fullfile(TestFold,labelSet),baseFName,suffix,testParams,Kndx);
                    if(isempty(rawNNs))
                        if(testParams.retSetSize >= length(trainFileList) )
                            if(isempty(fullSPDesc{ls,Kndx}))
                                fullSPDesc{ls,Kndx} = LoadSegmentDesc(trainFileList,retSetIndex,HOMEDATA,testParams.segmentDescriptors,testParams.K(Kndx),testParams.segSuffix);
                            end
                        end
                        if(isempty(fullSPDesc{ls,Kndx}))
                            retSetSPDesc = LoadSegmentDesc(trainFileList,retSetIndex,HOMEDATA,testParams.segmentDescriptors,testParams.K(Kndx),testParams.segSuffix);
                        else
                            retSetSPDesc = [];
                            for dNdx = 1:length(testParams.segmentDescriptors)
                                retSetSPDesc.(testParams.segmentDescriptors{dNdx}) = fullSPDesc{ls,Kndx}.(testParams.segmentDescriptors{dNdx})(descMask,:);
                            end
                        end
                        %timing(i,2)=toc;  rawNNs = DoRNNSearch(testImSPDesc,retSetSPDesc,fullfile(DataDir,labelSet),baseFName,suffix,testParams,Kndx);  timing(i,2)=toc-timing(i,2);
                        [rawNNs fileStats.timeNNSearch totalMatches] = DoRNNSearch(testImSPDesc,retSetSPDesc,fullfile(TestFold,labelSet),baseFName,suffix,testParams,Kndx);
                        fprintf('%03d: %d\n',i',totalMatches);
                    end
                    [probPerLabel{ls} fileStats.timeGetProb] = GetAllProbPerLabel(fullfile(TestFold,labelSet),baseFName,probSuffix,retSetIndex,rawNNs,labelNums,trainCounts{ls,Kndx},probType,testParams.smoothingConst,1);
                    save(timingFile,'fileStats');
                end

                %nomalize the datacosts for mrf. This is especiall important when using some classifier or when some labelsets are under represented
                probPerLabel{ls}(:,~shortListMask{ls}) = min(probPerLabel{ls}(:))-1;
                dataCost{ls} = testParams.maxPenality*(1-1./(1+exp(-(testParams.BConst(2)*probPerLabel{ls}+testParams.BConst(1)))));
                dataCost{ls}(:,~shortListMask{ls}) = testParams.maxPenality;
                %for k = 1:size(probPerLabel{ls},2)
                %    temp = mnrval(testParams.BConst,probPerLabel{ls}(:,k));
                %    dataCost{ls}(:,k) = testParams.maxPenality*(1-temp(:,1));
                %end
            else
                probCacheFile = fullfile(TestFold,'ClassifierOutput',[labelSet testParams.CLSuffix],[baseFName  '.mat']);
                classifierStr(ls) = '1';
                if(~exist(probCacheFile,'file'))
                    features = GetFeaturesForClassifier(testImSPDesc);
                    prob = test_boosted_dt_mc(classifiers{ls}, features);
                    make_dir(probCacheFile);save(probCacheFile,'prob');
                else
                    clear prob;
                    load(probCacheFile);
                end
                probPerLabel{ls} = prob;
                if(size(prob,2) == 1 && length(Labels{ls}) ==2)
                    probPerLabel{ls}(:,2) = -prob;
                end
                if(ls == FGSet)
                    probPerLabel{ls}(:,1) = probPerLabel{ls}(:,1);
                    probPerLabel{ls}(:,2) = probPerLabel{ls}(:,2);
                end

                %nomalize the datacosts for mrf. This is especiall important when using some classifier or when some labelsets are under represented
                probPerLabel{ls}(:,~shortListMask{ls}) = min(probPerLabel{ls}(:))-1;
                dataCost{ls} = testParams.maxPenality*(1-1./(1+exp(-(testParams.BConstCla(2)*probPerLabel{ls}+testParams.BConstCla(1)))));
                dataCost{ls}(:,~shortListMask{ls}) = testParams.maxPenality;
                %for k = 1:size(probPerLabel{ls},2)
                %    temp = mnrval(testParams.BConstCla,probPerLabel{ls}(:,k));
                %    dataCost{ls}(:,k) = testParams.maxPenality*(1-temp(:,1));
                %end
            end
        end

        fprintf('Finished SuperParsing\n');
    end
    
    %% Detector Dataterm
    retIndsSm = retInds(1:min(testParams.retSetSize,length(retInds)));
    ls = 1;
    min_val = -1;
    detectorSuffix = [testParams.ModelFold '-MM' myN2S(testParams.MaxModelPerCls,4) '-R' myN2S(testParams.retSetSize)];
    testResultFile = fullfile(TestFold,'ExemplarResult',detectorSuffix,fold,[base '.mat']);
    
    detectorDataSuffix = [detectorSuffix '-NMS' num2str(testParams.NMS)];
    detectionResultFile = fullfile(TestFold,'ExemplarDetectionResults',detectorDataSuffix,fold,[base '.mat']);
    
    detectorLaskTSuffix = sprintf( '%s-kt%.2f',detectorDataSuffix, testParams.detect_keep_threshold(end));
    dataResultFile = fullfile(TestFold,'ExemplarDataTerm',detectorLaskTSuffix,fold,[base '.mat']);
    saveFeatFile = fullfile(TestFold,'SubSampleFeats',detectorLaskTSuffix,fold,[base '.mat']);
    labelFile = fullfile(TestFold,'DetectorParse','LabelsSemantic',detectorLaskTSuffix,fold,[base '.mat']);make_dir(labelFile);
    clear dataTerm;
    if(~exist(dataResultFile,'file')&&~exist(saveFeatFile,'file')) || ~exist(detectionResultFile,'file') || ~exist(labelFile,'file') || ~exist(testResultFile,'file'))
        %load(dataResultFile);
    %end
    %if(~exist('dataTerm','var'))
        clear test_struct polygons;
        if(exist(detectionResultFile,'file'))
            try
                load(detectionResultFile);
            catch
                delete(detectionResultFile);
            end
        end
        if(~exist('test_struct','var'))
            allModels = cell(0);
            fileStats.timeLoadDetectors = tic;
            for rNdx = 1:length(retIndsSm)
                [retFold retBase] = fileparts(trainFileList{retIndsSm(rNdx)});
                modelFile = fullfile(HOMETESTDATA,'Classifier','Exemplar',testParams.ModelFold,retFold,[retBase '.mat']);
                if(exist(modelFile,'file'))
                    load(modelFile);
                    models = AddPolyToModel(fullfile(HOME,'Annotations'),models,modelFile);
                    allModels = [allModels(:); models(:)];
                end
            end
            fileStats.timeLoadDetectors = toc(fileStats.timeLoadDetectors);
            modelCls = cellfun2(@(x)x.cls,allModels);
            [unmodelCls a mNdx] = unique(modelCls);
            fileStats.numDetRaw = length(modelCls);
            if(testParams.MaxModelPerCls>0)
                [a b] = UniqueAndCounts(mNdx);
                rmNdx = [];
                for ovNdx = find(b>testParams.MaxModelPerCls)'
                    ndx = find(mNdx == a(ovNdx));
                    rmNdx = [rmNdx; ndx(testParams.MaxModelPerCls+1:end)];
                end
                allModels(rmNdx) = [];
                modelCls(rmNdx) = [];
                [unmodelCls a mNdx] = unique(modelCls);
            end
            m2lnum = 1:length(unmodelCls);
            fileStats.numDetReduced = length(modelCls);
            for m2lNdx = 1:length(unmodelCls)
                m2lnum(m2lNdx) = find(strcmp(strtrim(unmodelCls{m2lNdx}),Labels{ls}));
            end
            modelLnum = m2lnum(mNdx);

            clear test_grid;
            if(exist(testResultFile,'file'))
                try
                    load(testResultFile);
                catch
                    delete(testResultFile);
                end
            end
            if(~exist('test_grid','var'))
                fileStats.timeDetect = tic;test_grid = esvm_detect_imageset({fullfile(HOME,'Images',testFileList{i})}, allModels, detectorParams); fileStats.timeDetect = toc(fileStats.timeDetect);
                fileStats.numDetect = size(test_grid{1}.coarse_boxes,1);
                save(timingFile,'fileStats');
                make_dir(testResultFile);save(testResultFile,'test_grid');
            end
            cls_test_grid = cell(size(Labels{ls}));
            for l = 1:length(Labels{ls});
                cls_test_grid{l} = test_grid{1};
                if(~isempty(cls_test_grid{l}.coarse_boxes))
                    rmNdx = modelLnum(cls_test_grid{l}.coarse_boxes(:,6))~=l;
                    cls_test_grid{l}.coarse_boxes(rmNdx,:) = [];
                    cls_test_grid{l}.bboxes(rmNdx,:) = [];
                end
            end
            M = [];
            detectorParams.do_nms = testParams.NMS;
            test_struct = esvm_pool_exemplar_dets(cls_test_grid, allModels, M, detectorParams);
            
            if(isfield(allModels{1}.polygon,'pt'))
                polygons = cellfun2(@(x) x.polygon.pt,allModels);
            else
                polygons = cellfun2(@(x) x.polygon,allModels);
            end
            make_dir(detectionResultFile);save(detectionResultFile,'test_struct','polygons');
        end
        %{-
        for dktInd = 1:length(testParams.detect_keep_threshold)
            detectorLaskTSuffix = sprintf( '%s-kt%.2f',detectorDataSuffix, testParams.detect_keep_threshold(dktInd));
            dataResultFile = fullfile(TestFold,'ExemplarDataTerm',detectorLaskTSuffix,fold,[base '.mat']);
            saveFeatFile = fullfile(TestFold,'SubSampleFeats',detectorLaskTSuffix,fold,[base '.mat']);
            clear dataTerm;
            if(exist(dataResultFile,'file'))
                try
                    load(dataResultFile);
                catch
                    delete(dataResultFile);
                end
            end
            if(~exist(dataResultFile,'file')&&~exist(saveFeatFile,'file'))
                dataTerm = zeros([ro co length(Labels{ls})]);
                fileStats.timeProjectDetectors = tic;
                for l = 1:length(test_struct.unclipped_boxes)
                    [dt] = ProjectDetectorResponses(im,test_struct.final_boxes{l},polygons,testParams.detect_keep_threshold(dktInd));
                    dataTerm(:,:,l) = dt;
                end
                fileStats.timeProjectDetectors = toc(fileStats.timeProjectDetectors);
                save(timingFile,'fileStats');
                if(~exist('ssData','var'))
                    make_dir(dataResultFile);save(dataResultFile,'dataTerm','-v7.3');
                else
                    if(~strcmp(testFileList{i},strrep(ssData.detFiles{i},'\',filesep)))
                        fprintf('ERROR WRONG FILE\n');
                    end
                    dataTerm = reshape(dataTerm,[ro*co size(dataTerm,3)]);
                    indImEvn = ssData.indEvn(ssData.indEvn>=ssData.startPoint(i) & ssData.indEvn<ssData.startPoint(i+1))-ssData.startPoint(i)+1;
                    indImUni = ssData.indUni(ssData.indUni>=ssData.startPoint(i) & ssData.indUni<ssData.startPoint(i+1))-ssData.startPoint(i)+1;
                    detEvn = dataTerm(indImEvn,:);
                    detUni = dataTerm(indImUni,:);
                    make_dir(saveFeatFile);save(saveFeatFile,'detUni','detEvn','indImUni','indImEvn','-v7.3');
                    dataTerm = reshape(dataTerm,[ro co size(dataTerm,2)]);
                end
            end
            labelFile = fullfile(TestFold,'DetectorParse','LabelsSemantic',detectorLaskTSuffix,fold,[base '.mat']);make_dir(labelFile);
            if(~exist(labelFile,'file') )
                if(~exist('dataTerm','var'))
                    dataTerm = zeros([ro co length(Labels{ls})]);
                    for l = 1:length(test_struct.unclipped_boxes)
                        [dt] = ProjectDetectorResponses(im,test_struct.final_boxes{l},polygons,testParams.detect_keep_threshold(dktInd));
                        dataTerm(:,:,l) = dt;
                    end
                end
                [f L] = max(dataTerm,[],3);
                OutputLabeling(labelFile,L,Labels{1},S,names);
            end
        end
        %}0
    end
    ProgressBar(pfig,find(i==range),length(range));
    
    %end
    try
        %rmdir(busyFile);
    
    end
    save(timingFile,'fileStats');
end
close(pfig);

end


