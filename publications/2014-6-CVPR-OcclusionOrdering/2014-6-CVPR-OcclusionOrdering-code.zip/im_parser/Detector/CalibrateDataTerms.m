%% Init
DATATEST = fullfile(HOMEDATA,testParams.TestString);
sLabels = Labels{1};

hSize = 100000;
hSize2D = 1000;
load(fullfile(DATATEST,'ScoreRanges.mat'));
fnames = fieldnames(allRanges);
range = [];bins = [];
for n = 1:length(fnames)
    field = fnames{n};
    range.(field) = [min(allRanges.(field)(:,1)) max(allRanges.(field)(:,2))];
    bins.(field) = MakeBins(range.(field),hSize);
end
%{
load(fullfile(DATATEST,'Histogram.mat'));
for n = 1:length(fnames)
    field = fnames{n};
    [bins2d.(field), binEdges2d.(field)] = MakeBinsEven(sum(hists.(field).pos./sum(hists.(field).pos(:))+hists.(field).neg./sum(hists.(field).neg(:)),2), bins.(field), hSize2D);
end
hists = [];
%}

%% Calibrate using the precomputed histogram
%{
%load(fullfile(DATATEST,'Histogram.mat'));
%plBetas = [];
%plBetasNorm = [];
for n = processF%1:length(fnames)
    field = fnames{n};
    for l = 1:length(sLabels)
        fprintf('%s\n',sLabels{l});
        X = bins.(field)';
        Y = [hists.(field).pos(:,l) hists.(field).neg(:,l)];
        rm = sum(Y,2) == 0;
        X(rm) = [];
        Y(rm,:) = [];
        
        if(length(X)>1)
            plBetas.(field)(:,l) = mnrfit(X,Y); 
        else
             plBetas.(field)(:,l) = [-100;.00001];
        end
        y = mnrval(plBetas.(field)(:,l),X);
        %{
        figure(1);clf; plot(X,y(:,1));hold on;
        plot(X(Y(:,1)>0),ones(sum(Y(:,1)>0),1),'.b'); plot(X(Y(:,2)>0),zeros(sum(Y(:,2)>0),1),'.b');hold off;
        %}
        fprintf('%.3f ',plBetas.(field)(:,l));
        
        %%normalize positive and negative to give even weight?
        Y(:,1) = Y(:,1)*sum(Y(:,2))./(length(sLabels)*sum(Y(:,1)));
        Y(isnan(Y(:))) = 0;
        if(length(X)>1)
            plBetasNorm.(field)(:,l) = mnrfit(X,Y); 
        else
        	plBetasNorm.(field)(:,l) = [-100;.00001];
        end
        y = mnrval(plBetasNorm.(field)(:,l),X);
        %{
        figure(2);clf; plot(X,y(:,1));hold on;
        plot(X(Y(:,1)>0),ones(sum(Y(:,1)>0),1),'.b'); plot(X(Y(:,2)>0),zeros(sum(Y(:,2)>0),1),'.b');hold off;
        %}
        fprintf('%.3f ',plBetasNorm.(field)(:,l));
        fprintf('\n');
    end
end
save(fullfile(DATATEST,['Betas' fnames{processF} '.mat']),'plBetas','plBetasNorm');
%}
%% Calibrate using the precomputed 2D histogram
%{-
%load(fullfile(DATATEST,'Histogram2D.mat'));
%pl2DBetas = [];
%pl2DBetasNorm = [];

[X1 X2] = meshgrid(bins2d.detAdd,bins2d.prob);
X = [ X2(:) X1(:)];
Yp = sum(hist2D.pos(:,:,:),3);%hist2D.pos(:,:,l);%
Yn = sum(hist2D.neg(:,:,:),3);%hist2D.neg(:,:,l);%
Y = [Yp(:) Yn(:) ];
rm = sum(Y,2) == 0;
X(rm,:) = [];
Y(rm,:) = [];
glo2DBetas = mnrfit(X,Y,'model','hierarchical','interactions','on');%);%
%glo2DBetas = repmat(glo2DBetas,[1 length(sLabels)]);

[pY pX] = meshgrid(0:.25:10,-100:5:100);
pZ = mnrval(glo2DBetas,[pX(:) pY(:)],'model','hierarchical','interactions','on');%);%
pZ = reshape(pZ(:,1),size(pX))';
figure(2);%clf; 
surf(pX(:,1),pY(1,:)',pZ);

for l = 1:length(sLabels)
    fprintf('%s\n',sLabels{l});
    [X1 X2] = meshgrid(bins2d.detAdd,bins2d.prob);
    X = [ X2(:) X1(:)];
    Yp = sum(hist2D.pos(:,:,:),3);%hist2D.pos(:,:,l);%
    Yn = sum(hist2D.neg(:,:,:),3);%hist2D.neg(:,:,l);%
    Y = [Yp(:) Yn(:) ];
    rm = sum(Y,2) == 0;
    X(rm,:) = [];
    Y(rm,:) = [];

    if(length(X)>1)
        pl2DBetas(:,l) = mnrfit(X,Y,'model','hierarchical','interactions','on');%);%
    else
        pl2DBetas(:,l) = [-100;.00001];
    end
    
    %{-
    [pY pX] = meshgrid(0:.25:10,-100:5:100);
    pZ = mnrval(pl2DBetas(:,l),[pX(:) pY(:)],'model','hierarchical','interactions','on');%);%
    pZ = reshape(pZ(:,1),size(pX))';
    figure(1);%clf; 
    surf(pX(:,1),pY(1,:)',pZ);
    hold on;
    plot3(X(Y(:,1)>0,1),X(Y(:,1)>0,2),ones(sum(Y(:,1)>0),1),'.b'); 
    plot3(X(Y(:,2)>0,1),X(Y(:,2)>0,2),zeros(sum(Y(:,2)>0),1),'.b');
    
    if(length(X)>1 && sum(Y(:,1)>0) > 0)
        tX = bins2d.prob;tY = [sum(hist2D.pos(:,:,l),2) sum(hist2D.neg(:,:,l),2)];
        rm = sum(tY,2) == 0;        tX(rm,:) = [];        tY(rm,:) = [];
        plb1 = mnrfit(tX,tY);
        tZ = mnrval(plb1,tX);
        plot3(tX,zeros(size(tX)),tZ(:,1),'-r');
        tX = bins2d.detAdd;tY = [sum(hist2D.pos(:,:,l),1)' sum(hist2D.neg(:,:,l),1)'];
        rm = sum(tY,2) == 0;        tX(rm,:) = [];        tY(rm,:) = [];
        plb2 = mnrfit(tX,tY);
        tZ = mnrval(plb2,tX);
        plot3(ones(size(tX))*-100,tX,tZ(:,1),'-r');
    end
    hold off;drawnow;
    %}
    fprintf('%.3f ',pl2DBetas(:,l));

    %%normalize positive and negative to give even weight?
    %{
    Y(:,1) = Y(:,1)*sum(Y(:,2))./(length(sLabels)*sum(Y(:,1)));
    Y(isnan(Y(:))) = 0;
    if(length(X)>1)
        plBetasNorm.(field)(:,l) = mnrfit(X,Y); 
    else
        plBetasNorm.(field)(:,l) = [-100;.00001];
    end
    y = mnrval(plBetasNorm.(field)(:,l),X);
    %{
    figure(2);clf; plot(X,y(:,1));hold on;
    plot(X(Y(:,1)>0),ones(sum(Y(:,1)>0),1),'.b'); plot(X(Y(:,2)>0),zeros(sum(Y(:,2)>0),1),'.b');hold off;
    %}
    fprintf('%.3f ',plBetasNorm.(field)(:,l));
    %}
    fprintf('\n');
end
save(fullfile(DATATEST,['Betas2D.mat']),'pl2DBetas','glo2DBetas');
%}
%% Computer 2D Histogram on cluster
%{
probFold = 'probPerLabelR800K200TNN80-SPscGistCoHist-sc01ratio';
detectFold = 'Model1280-MM0100-R800-NMS0-CT0.01';
load(fullfile(DATATEST,'Histogram.mat'));
for n = 1:length(fnames)
    field = fnames{n};
    [bins2d.(field), binEdges2d.(field)] = MakeBinsEven(sum(hists.(field).pos./sum(hists.(field).pos(:))+hists.(field).neg./sum(hists.(field).neg(:)),2), bins.(field), hSize2D);
end
hists = [];
hist2D = [];
hist2D.pos = zeros([hSize2D hSize2D length(Labels{1})]);
hist2D.neg = zeros([hSize2D hSize2D length(Labels{1})]);

tic
for i = rangeN(1):rangeN(2):length(trainFileList)
    fprintf('Starting %d\n',i);
    try
    [fold base] = fileparts(trainFileList{i});
    probFile = fullfile(DATATEST,'LabelsSemantic',probFold,fold,[base '.mat']);
    detectFile = fullfile(DATATEST,'ExemplarDataTerm',detectFold,fold,[base '.mat']);
    gtFile = fullfile(HOME,'LabelsSemantic',fold,[base '.mat']);
    spFile = fullfile(HOMEDESCRIPTOR,'SP_Desc_k200','super_pixels',fold,[base '.mat']);
    
    d = load(detectFile);
    d = rmfield(d,{'dataTermMax','dataTermAvg'});
    
    g = load(gtFile);
    
    imSP = load(spFile);imSP = imSP.superPixels;
    p = load(probFile);
    spDataTerm = p.probPerLabel(imSP(:),:);
    d.dataTerm = reshape( d.dataTerm,size(spDataTerm));
    for l = 1:size(spDataTerm,2)
        h = hist3([spDataTerm(g.S(:)~=l,l) d.dataTerm(g.S(:)~=l,l)],{bins2d.prob,bins2d.detAdd});
        hist2D.neg(:,:,l) = hist2D.neg(:,:,l)+h;
        h = hist3([spDataTerm(g.S(:)==l,l) d.dataTerm(g.S(:)==l,l)],{bins2d.prob,bins2d.detAdd});
        hist2D.pos(:,:,l) = hist2D.pos(:,:,l)+h;
    end
    clear d g spDataTerm;
    fprintf('Finishing %d\n',i);
    end
end
toc
save(fullfile(DATATEST,['Histogram' num2str(rangeN(1)) '.mat']),'hist2D','-v7.3');
%}

%% Combine cluster computed histograms
%{
range = rangeN(1):rangeN(2):250;
load(fullfile(DATATEST,['Histogram' num2str(rangeN(1)) '.mat']));
for i = range(2:end)
    a = load(fullfile(DATATEST,['Histogram' num2str(i) '.mat']));
    hist2D.neg = hist2D.neg + a.hist2D.neg;
    hist2D.pos = hist2D.pos + a.hist2D.pos;
    fprintf('%d\n',i);
end
save(fullfile(DATATEST,['HistogramCombo' num2str(rangeN(1)) '.mat']),'hist2D','-v7.3');
%}
%{
range = 1:rangeN(2);
load(fullfile(DATATEST,['HistogramCombo' num2str(1) '.mat']));
for i = range(2:end)
    a = load(fullfile(DATATEST,['HistogramCombo' num2str(i) '.mat']));
    hist2D.neg = hist2D.neg + a.hist2D.neg;
    hist2D.pos = hist2D.pos + a.hist2D.pos;
    fprintf('%d\n',i);
end
save(fullfile(DATATEST,['Histogram2D.mat']),'hist2D','-v7.3');
%}

%% Compute Histograms on the cluster
%{
probFold = 'probPerLabelR800K200TNN80-SPscGistCoHist-sc01ratio';
detectFold = 'Model1280-MM0100-R800-NMS0-CT0.01';
hists = [];
for n = 1:length(fnames)
    field = fnames{n};
    hists.(field).pos = zeros(hSize,length(Labels{1}));
    hists.(field).neg = zeros(hSize,length(Labels{1}));
end
tic
for i = rangeN(1):rangeN(2):length(trainFileList)
    fprintf('Starting %d\n',i);
    try
    [fold base] = fileparts(trainFileList{i});
    probFile = fullfile(DATATEST,'LabelsSemantic',probFold,fold,[base '.mat']);
    detectFile = fullfile(DATATEST,'ExemplarDataTerm',detectFold,fold,[base '.mat']);
    gtFile = fullfile(HOME,'LabelsSemantic',fold,[base '.mat']);
    spFile = fullfile(HOMEDESCRIPTOR,'SP_Desc_k200','super_pixels',fold,[base '.mat']);
    
    g = load(gtFile);
    
    imSP = load(spFile);imSP = imSP.superPixels;
    p = load(probFile);
    spDataTerm = p.probPerLabel(imSP(:),:);
    for l = 1:size(spDataTerm,2)
        h = hist(spDataTerm(g.S(:)==l,l),bins.prob);
        hists.prob.pos(:,l) = hists.prob.pos(:,l)+h(:);
        h = hist(spDataTerm(g.S(:)~=l,l),bins.prob);
        hists.prob.neg(:,l) = hists.prob.neg(:,l)+h(:);
    end
    clear p;
    
    d = load(detectFile);
    d.dataTerm = reshape( d.dataTerm,size(spDataTerm));
    d.dataTermMax = reshape( d.dataTermMax,size(spDataTerm));
    d.dataTermAvg = reshape( d.dataTermAvg,size(spDataTerm));
    
    
    for l = 1:size(d.dataTerm,2)
        h = hist(d.dataTerm(g.S(:)==l,l),bins.detAdd);
        hists.detAdd.pos(:,l) = hists.detAdd.pos(:,l)+h(:);
        h = hist(d.dataTerm(g.S(:)~=l,l),bins.detAdd);
        hists.detAdd.neg(:,l) = hists.detAdd.neg(:,l)+h(:);
        
        h = hist(d.dataTermMax(g.S(:)==l,l),bins.detMax);
        hists.detMax.pos(:,l) = hists.detMax.pos(:,l)+h(:);
        h = hist(d.dataTermMax(g.S(:)~=l,l),bins.detMax);
        hists.detMax.neg(:,l) = hists.detMax.neg(:,l)+h(:);
        
        h = hist(d.dataTermMax(g.S(:)==l,l),bins.detAvg);
        hists.detAvg.pos(:,l) = hists.detAvg.pos(:,l)+h(:);
        h = hist(d.dataTermMax(g.S(:)~=l,l),bins.detAvg);
        hists.detAvg.neg(:,l) = hists.detAvg.neg(:,l)+h(:);
    end
    clear d;
    fprintf('Finishing %d\n',i);
    end
end
toc
save(fullfile(DATATEST,['Histogram' num2str(rangeN(1)) '.mat']),'hists');
%}

%% Combine cluster computed histograms
%{
load(fullfile(DATATEST,['Histogram' num2str(1) '.mat']));
fs = fieldnames(hists);
for i = 2:1000
    a = load(fullfile(DATATEST,['Histogram' num2str(i) '.mat']));
    for n = 1:length(fs)
        hists.(fs{n}).pos = hists.(fs{n}).pos + a.hists.(fs{n}).pos;
        hists.(fs{n}).neg = hists.(fs{n}).neg + a.hists.(fs{n}).neg;
    end
    fprintf('%d\n',i);
end
save(fullfile(DATATEST,['Histogram.mat']),'hists');
%}