SetUpConstants;

close all;
[foo LabelSetFold] = fileparts(HOMELABELSETS{1});
sampleSize = 1e6;

%detFiles = dir_recurse(fullfile(HOMERUNONTRAINING,'ExemplarDataTermTmp',detectorFold,'*'),0);
allTrainingLabels = cell(size(trainFileList));
featMean = zeros(1,length(names)*2);
featCov = zeros(length(names)*2);
numPoints = 0;
featLabelMeans = zeros(length(names),length(names)*2);
featLabelCounts = zeros(length(names),1);
showL = [find(strcmp(names,'car')) find(strcmp(names,'taxi')) find(strcmp(names,'fire hydrant'))];
showL = [showL; length(names)+showL];
pfig = ProgressBar('Computing Mean for LDA');
for f = 1:length(trainFileList)
    [fold base] = fileparts(trainFileList{f});
    outFile = fullfile(HOMERUNONTRAINING,'MeanAndCov',fold,[base '.mat']);
    if(exist(outFile,'file'))
        load(outFile);
    else
        try
            %{-
            load(fullfile(HOMERUNONTRAINING,'ExemplarDataTermTmp',detectorFold,fold,[base '.mat'])); %dataTerm (ro x co x #l) dataTermMax
            a = load(fullfile(HOMERUNONTRAINING,LabelSetFold,parserFold,fold,[base '.mat'])); %probPerLabel (#SP x #l)
            if(isfield(a,'probPerLabel'))
                probPerLabel = a.probPerLabel;
            elseif(isfield(a,'prob'))
                probPerLabel = a.prob;
            end
            load(fullfile(HOMEDATA,'Descriptors',spFold,'super_pixels',fold,[base '.mat'])); %superPixels (ro x co)
            %}-
            load(fullfile(HOMELABELSETS{1},fold,[base '.mat'])); %S (ro x co) names
            %ann = LMread(fullfile(HOMEANNOTATIONS,fold,[base '.xml']));
        catch
            continue;
        end
        uSP = unique(superPixels);
        spMap = zeros(max(uSP),1);
        spMap(uSP) = 1:length(uSP);
        feat = [probPerLabel(spMap(superPixels),:) reshape(dataTerm,[],size(dataTerm,3))];
        labels = S(:);
        imCov = feat'*feat;
        imMean = sum(feat);
        imPoints = size(feat,1);
        [lsUsed countUsed] = UniqueAndCounts(labels);
        countUsed(lsUsed<1) = [];lsUsed(lsUsed<1) = [];
        imLabelCounts = zeros(length(names),1);
        imLabelCounts(lsUsed) = countUsed;
        imLabelMeans = zeros(length(names),length(names)*2);
        for l = lsUsed(:)'
            imLabelMeans(l,:) = sum(feat(labels==l,:));
        end
        make_dir(outFile);save(outFile,'imCount','imCov','imLabelCounts','imMean','imPoints');
    end
    featCov = featCov + imCov;
    featMean = featMean+imMean;
    numPoints = numPoints + imPoints;
    featLabelMeans = featLabelMeans + imLabelMeans;
    featLabelCounts = featLabelCounts + imLabelCounts;
    %allTrainingLabels{f} = S(:);
    if(mod(f,10)==0)
        ProgressBar(pfig,f,length(detFiles));
        fprintf('%.03f\t',featMean(showL(:))./numPoints);fprintf('\n');
        fprintf('%.03f\t',(featCov(showL(1),showL(:))./numPoints-(featMean(showL(:)).*featMean(showL(1)))./numPoints^2)./((featMean(showL(:)).*featMean(showL(1)))./numPoints^2));fprintf('\n');
    end
end
close(pfig);

%{
testDataFile = fullfile(TestFold,sprintf('PreSVMData-MM%04d.mat',testParams.MaxModelPerCls));
trainDataFile = fullfile(HOMERUNONTRAINING,[svmFold 'Data.mat']);
if(exist(trainDataFile,'file'))
    load(trainDataFile);
else
    detFiles = dir_recurse(fullfile(HOMERUNONTRAINING,'ExemplarDataTerm',detectorFold,'*'),0);
    dataFile = fullfile(HOMERUNONTRAINING,'svmTrainingSplitInd.mat');
    %{
    if(~exist(dataFile,'file'))
        labelFile = fullfile(HOMERUNONTRAINING,'svmTrainingLabels.mat');
        if(~exist(labelFile,'file'))
            allTrainingLabels = cell(size(detFiles));
            for f = 1:length(detFiles)
                [fold base] = fileparts(detFiles{f});
                load(fullfile(HOMELABELSETS{1},fold,[base '.mat'])); %S (ro x co) names
                allTrainingLabels{f} = S(:);
            end
            allTrainingLabels = vertcat(allTrainingLabels{:});
            save(labelFile,'allTrainingLabels','names');
        else
            load(labelFile);
        end
        
        
        [~, ~, evnMask] = MySubSample(allTrainingLabels,allTrainingLabels,sampleSize,1,[],1:max(allTrainingLabels));
        indEvn = find(evnMask);
        useMask = ~evnMask&(allTrainingLabels~=0);
        clear evnMask allTrainingLabels;
        numEl = sum(useMask);
        ss = numEl/sampleSize;
        ndxs = floor(1:ss:numEl);
        indUni = zeros(size(ndxs));
        adder = 0;
        indUniNdx = 1;
        range = [floor(1:ss:length(useMask)) length(useMask)+1];
        for i = 1:length(range)-1;
            start = range(i);
            endN = range(i+1)-1;
            a = cumsum(useMask(start:endN))+adder;
            ndx = find(a>=ndxs(indUniNdx),1);
            if(~isempty(ndx))
                indUni(indUniNdx) = ndx+start-1;
                indUniNdx = indUniNdx+1;
                if(indUniNdx>length(indUni))
                    break;
                end
            end
            adder = a(end);
        end
        clear useMask;
        save(dataFile,'indUni','indEvn','names');
    else
        load(dataFile);
    end
    %}
    
    labelsEvnOvLp = zeros(length(indEvn),length(names),'int16')==1;
    labelsUniOvLp = zeros(length(indUni),length(names),'int16')==1;
    labelsEvn2 = zeros(length(indEvn),1,'int16');
    labelsUni2 = zeros(length(indUni),1,'int16');
    featsEvn = zeros(length(indEvn),length(names)*2);
    featsUni = zeros(length(indUni),length(names)*2);
    
    i = 1;evnStart = 1;uniStart=1;
    pfig = ProgressBar('Loading SVM training Data');
    for f = 1:length(detFiles)
        [fold base] = fileparts(detFiles{f});
        try
            %{-
            load(fullfile(HOMERUNONTRAINING,'ExemplarDataTerm',detectorFold,fold,[base '.mat'])); %dataTerm (ro x co x #l) dataTermMax
            a = load(fullfile(HOMERUNONTRAINING,LabelSetFold,parserFold,fold,[base '.mat'])); %probPerLabel (#SP x #l)
            if(isfield(a,'probPerLabel'))
                probPerLabel = a.probPerLabel;
            elseif(isfield(a,'prob'))
                probPerLabel = a.prob;
            end
            load(fullfile(HOMEDATA,'Descriptors',spFold,'super_pixels',fold,[base '.mat'])); %superPixels (ro x co)
            %}-
            load(fullfile(HOMELABELSETS{1},fold,[base '.mat'])); %S (ro x co) names
            ann = LMread(fullfile(HOMEANNOTATIONS,fold,[base '.xml']));
        catch
            continue;
        end
        %{-
        uSP = unique(superPixels);
        spMap = zeros(max(uSP),1);
        spMap(uSP) = 1:length(uSP);
        feat = probPerLabel(spMap(superPixels),:);
        feat = [feat reshape(dataTerm,[],size(dataTerm,3))];
        %}-
        label = S(:);
        
        indImEvn = indEvn(indEvn>=i & indEvn<(i+length(label)))-i+1;
        labelsEvn(evnStart:evnStart+length(indImEvn)-1) = label(indImEvn);
        [Y, X] = ind2sub(size(S),indImEvn);
        labelsEvnOvLp(evnStart:evnStart+length(indImEvn)-1,:) = PointsToPolyLabels( ann, X, Y, length(names) );
        featsEvn(evnStart:evnStart+length(indImEvn)-1,:) = feat(indImEvn,:);
        %{
        if(any(labelsEvn2(evnStart:evnStart+length(indImEvn)-1)~=labelsEvn(evnStart:evnStart+length(indImEvn)-1)))
            keyboard;
            continue;
        end
        if(any(labelsEvnOvLp(sub2ind(size(labelsEvnOvLp),evnStart:evnStart+length(indImEvn)-1,double(labelsEvn(evnStart:evnStart+length(indImEvn)-1)')))==0))
            ind = find(labelsEvnOvLp(sub2ind(size(labelsEvnOvLp),evnStart:evnStart+length(indImEvn)-1,double(labelsEvn(evnStart:evnStart+length(indImEvn)-1)')))==0);
            [a b] = find(labelsEvnOvLp(evnStart:evnStart+length(indImEvn)-1,:)');c=labelsEvn2(evnStart:evnStart+length(indImEvn)-1);
            [a(b==ind) b(b==ind) X(b(b==ind)) Y(b(b==ind))]
            [c(ind) X(ind) Y(ind)]
            keyboard;
        end
        %}
        evnStart = evnStart+length(indImEvn);
        
        indImUni = indUni(indUni>=i & indUni<(i+length(label)))-i+1;
        labelsUni(uniStart:uniStart+length(indImUni)-1) = label(indImUni);
        [Y, X] = ind2sub(size(S),indImUni);
        labelsUniOvLp(uniStart:uniStart+length(indImUni)-1,:) = PointsToPolyLabels( ann, X, Y, length(names) );
        featsUni(uniStart:uniStart+length(indImUni)-1,:) = feat(indImUni,:);
        %{
        if(any(labelsUni2(uniStart:uniStart+length(indImUni)-1)~=labelsUni(uniStart:uniStart+length(indImUni)-1)))
            keyboard;
        end
        if(any(labelsUniOvLp(sub2ind(size(labelsUniOvLp),uniStart:uniStart+length(indImUni)-1,double(labelsUni(uniStart:uniStart+length(indImUni)-1)')))==0))
            ind = find(labelsUniOvLp(sub2ind(size(labelsUniOvLp),uniStart:uniStart+length(indImUni)-1,double(labelsUni(uniStart:uniStart+length(indImUni)-1)')))==0);
            [a b] = find(labelsUniOvLp(uniStart:uniStart+length(indImUni)-1,:)');c=labelsUni(uniStart:uniStart+length(indImUni)-1);
            [a(b==ind) b(b==ind) X(b(b==ind)) Y(b(b==ind))]
            [c(ind) X(ind) Y(ind)]
            keyboard;
        end
        %}
        uniStart = uniStart+length(indImUni);
        
        i = i+length(label);
        if(mod(f,10)==0)
            ProgressBar(pfig,f,length(detFiles));
        end
    end
    close(pfig);
    save(trainDataFile,'labelsEvn','labelsEvnOvLp','featsEvn','indEvn','labelsUni','labelsUniOvLp','featsUni','indUni','names','-v7.3');
    clear feats labels;
end
fprintf('Num Evn Different: %d\n',sum(labelsEvnOvLp(sub2ind(size(labelsEvnOvLp),find(labelsEvn~=0),double(labelsEvn(labelsEvn~=0))))==0));
fprintf('Num Evn Not 0: %d\n',sum(sum(labelsEvnOvLp(labelsEvn==0,:),2)~=0));
fprintf('Num Uni Different: %d\n',sum(labelsUniOvLp(sub2ind(size(labelsUniOvLp),find(labelsUni~=0),double(labelsUni(labelsUni~=0))))==0));
fprintf('Num Evn Not 0: %d\n',sum(sum(labelsUniOvLp(labelsUni==0,:),2)~=0));
featsUni(labelsUni==0,:) = [];
labelsUniOvLp(labelsUni==0,:) = [];
indUni(labelsUni==0) = [];
labelsUni(labelsUni==0) = [];
indUni = indUni(:);
labelsUni = labelsUni(:);
indEvn = indEvn(:);
labelsEvn = labelsEvn(:);
%}-

if(exist(testDataFile,'file') )
    load(testDataFile);
else
    detFiles = dir_recurse(fullfile(TestFold,'ExemplarDataTerm',detectorFold,'*'),0);

    allTrainingLabels = cell(size(detFiles));
    for f = 1:length(detFiles)
        [fold base] = fileparts(detFiles{f});
        load(fullfile(HOMELABELSETS{1},fold,[base '.mat'])); %S (ro x co) names
        allTrainingLabels{f} = S(:);
    end
    allTrainingLabels = vertcat(allTrainingLabels{:});
    
    labelsZero = allTrainingLabels==0;
    testMask = zeros(size(allTrainingLabels))==1;
    [~, ~, mask] = MySubSample(allTrainingLabels(~labelsZero),allTrainingLabels(~labelsZero),10*length(names),1);
    testMask(~labelsZero)= mask;
    [~, ~, mask] = MySubSample(allTrainingLabels(~testMask&~labelsZero),allTrainingLabels(~testMask&~labelsZero),sampleSize,0);
    testMask(~testMask&~labelsZero)= mask;
    
    testLabels = zeros(sum(testMask),1,'int16');
    testFeats = zeros(sum(testMask),length(names)*2);
    
    i = 1;testStart = 1;uniStart=1;
    pfig = ProgressBar('Loading SVM training Data');
    for f = 1:length(detFiles)
        [fold base] = fileparts(detFiles{f});
        try
            load(fullfile(TestFold,'ExemplarDataTerm',detectorFold,fold,[base '.mat'])); %dataTerm (ro x co x #l) dataTermMax
            a = load(fullfile(TestFold,LabelSetFold,parserFold,fold,[base '.mat'])); %probPerLabel (#SP x #l)
            if(isfield(a,'probPerLabel'))
                probPerLabel = a.probPerLabel;
            elseif(isfield(a,'prob'))
                probPerLabel = a.prob;
            end
            load(fullfile(HOMEDATA,'Descriptors',spFold,'super_pixels',fold,[base '.mat'])); %superPixels (ro x co)
            load(fullfile(HOMELABELSETS{1},fold,[base '.mat'])); %S (ro x co) names
        catch
            continue;
        end
        uSP = unique(superPixels);
        spMap = zeros(max(uSP),1);
        spMap(uSP) = 1:length(uSP);
        feat = probPerLabel(spMap(superPixels),:);
        feat = [feat reshape(dataTerm,[],size(dataTerm,3))];
        label = S(:);
        
        testImMask = testMask(i:i+length(label)-1);
        testLabels(testStart:testStart+sum(testImMask)-1) = label(testImMask);
        testFeats(testStart:testStart+sum(testImMask)-1,:) = feat(testImMask,:);
        testStart = testStart+sum(testImMask);
        
        i = i+length(label);
        if(mod(f,10)==0)
            ProgressBar(pfig,f,length(detFiles));
        end
    end
    close(pfig);
    save(testDataFile,'testFeats','testLabels','names','-v7.3');
end
%Linear SVM


params.trainFun = @libwsvmtrain;
params.testFun = @libwsvmpredict;
params.kernel = 0;
params.gamma = [];
params.svmName = 'Training Set SP Rate';
params.normType = 'std';
params.cvTarget = 'avgPerClass';
params.C = 1;
svm = cell(0);
params.cvSize = 1;
params.options = ' -h 0';
params.rmDim = [];
params.names = names;
numLs = length(names);

if(exist(fullfile(HOME,'StuffLabels.txt'),'file'))
    sl = importdata(fullfile(HOME,'StuffLabels.txt'));
    [~, stuffLs] = intersect(names,sl);
end

close all;
MyCleanUp;
make_dir(fullfile(TestFold,svmFold,'resultsFullTest.txt'));
fid = fopen(fullfile(TestFold,svmFold,'resultsFullTest.txt'),'w');
fprintf(fid,'SVM Name\tC param\tHard Ratio\tEven Ratio\tSub-sampled Ratio\tPer-pix + Per-class\tPer-pixel\tPer-class\t');
fprintf(fid,'%s\t',names{:});
fprintf(fid,'\n');
[a b] = UniqueAndCounts(labelsUni);
fprintf(fid,'Training Set Counts\t\t\t\t\t\t\t\t');
fprintf(fid,'%d\t',b);
fprintf(fid,'\n');

[maxFeats MaxL] = max(featsUni(:,1:numLs),[],2);
rates = MySVMRates(MaxL,labelsUni);
fprintf(fid,'%s\t',params.svmName);fprintf(fid,'\t\t\t\t\t');fprintf(fid,'%.3f\t',rates(:,1)./rates(:,2));fprintf(fid,'\n');

correctFeatsInd = sub2ind(size(featsUni),1:size(featsUni,1),double(labelsUni'));
cdFeatsDiff = maxFeats-featsUni(correctFeatsInd');
hardFeatsInd = cdFeatsDiff>0;

[maxFeatsD MaxLD] = max(featsUni(:,numLs+1:end),[],2);
rates = MySVMRates(MaxLD,labelsUni);
params.svmName = 'Training Set Detector Rate';
fprintf(fid,'%s\t',params.svmName);fprintf(fid,'\t\t\t\t\t');fprintf(fid,'%.3f\t',rates(:,1)./rates(:,2));fprintf(fid,'\n');

correctFeatsIndD = sub2ind(size(featsUni),1:size(featsUni,1),double(labelsUni')+numLs);
cdFeatsDiffD = maxFeatsD-featsUni(correctFeatsIndD');
hardFeatsIndD = cdFeatsDiffD>0;

%{
params.svmName = 'Test Set SP Rate';
[maxFeats MaxL] = max(testFeats(:,1:numLs),[],2);
rates = MySVMRates(MaxL,testLabels);
fprintf(fid,'%s\t',params.svmName);fprintf(fid,'\t\t\t\t\t');fprintf(fid,'%.3f\t',rates(:,1)./rates(:,2));fprintf(fid,'\n');

params.svmName = 'Test Set Detector Rate';
[maxFeatsD MaxLD] = max(testFeats(:,numLs+1:end),[],2);
rates = MySVMRates(MaxLD,testLabels);
fprintf(fid,'%s\t',params.svmName);fprintf(fid,'\t\t\t\t\t');fprintf(fid,'%.3f\t',rates(:,1)./rates(:,2));fprintf(fid,'\n');
%}

myRandomize;
%pfig = ProgressBar('Try sub-sample rate of');
configs = [ 0 0 .33];
            %.125 .125 .25];
ssrange = 2.5e5%1e4*2.^5%(3:2:7);%[1e4 1e5];%
for ss = ssrange
    %{
    for c = 1:size(configs,1);
        ratioH = configs(c,1);
        ratioHD = configs(c,2);
        ratioE = configs(c,3);
        
        if(sum([ratioH ratioHD ratioE])>1)
            continue;
        end
                
        %{
        %load(trainDataFile);
        [leh, feh, mask] = MySubSample(labelsUni, featsUni, ss*ratioH,0,hardFeatsInd);
        indh = indUni(mask);
        leho = labelsUniOvLp(mask,:);
        [lehd, fehd, mask] = MySubSample(labelsUni, featsUni, ss*ratioHD,0,hardFeatsIndD);
        indhd = indUni(mask);
        lehdo = labelsUniOvLp(mask,:);
        [lee, fee, mask] = MySubSample(labelsEvn, featsEvn, ss*ratioE,1);
        inde = indEvn(mask);
        leeo = labelsEvnOvLp(mask,:);
        [les, fes, mask] = MySubSample(labelsUni,featsUni,ss*(1-ratioH-ratioHD-ratioE),0);
        inds = indUni(mask);
        leso = labelsUniOvLp(mask,:);
        le = [leh; lehd; lee; les];fe = [feh; fehd; fee; fes];ind = [indh; indhd; inde; inds];
        leo = [leho; lehdo; leeo; leso];
        [ind, a] = sort(ind);
        le = le(a);
        fe = fe(a,:);
        leo = leo(a,:);
        clear leh lehd lee les feh fehd fee fes;
        %clear feats;
        %}
        

        %{
        for dim = [4000]
            for vs = [3 4]
            clear params;
            params.trainFun = @liblineardensetrain;
            params.testFun = @liblineardensepredict;
            params.kernel = [];
            params.gamma = [];
            params.normType = 'std';
            params.cvSize = 1;
            params.cvTarget = 'avgPlusClass';%'avgPerClass';%
            params.C = 1;
            if(vs == 1)
                params.rmDim = 1:numLs;
            elseif(vs ==2)
                params.rmDim = (numLs+1):(2*numLs);
            elseif(vs==3)
                params.rmDim = numLs+stuffLs;
            else
                params.rmDim = [];%1:33;
            end
            params.names = names;
            params.svmName = sprintf('LinearF-SS%dk-RH%.2f-RHD%.2f-RE%.2f',ss/1000,ratioH,ratioHD,ratioE);
            params.RFPdim = dim;
            svmNameBase = sprintf('SS%dk-RH%.2f-RE%.2f-RFD%d-%s',ss/1000,ratioH,ratioE,params.RFPdim,params.normType);
            if(vs == 1)
                svmNameBase = ['Det-' svmNameBase];
            elseif(vs ==2)
                svmNameBase = ['SP-' svmNameBase];
            elseif(vs ==3)
                svmNameBase = ['NoStuff-' svmNameBase];
            end
            gammaFile = fullfile(TestFold,svmFold,['GammaRFPSave-' svmNameBase '.mat']);
            svmNameBase = ['RBF-' svmNameBase];
            if(~exist(gammaFile,'file'))
                params.autogamma = 1;
                [~, params] = MySVMNormalize(fe,params);
                save(gammaFile,'params');
                gamma = params.gamma;
                RFP = params.RFP;
                fprintf('Gamma: %.4f %s\n',gamma, svmNameBase);
                clear feN d;
            else
                a = load(gammaFile);
                gamma = a.params.gamma;
                RFP = a.params.RFP;
                params.norm = a.params.norm;
            end
            if(size(RFP,2)~=dim/2)
                fprintf('ERRRORRROROR!!!!!\n');
                keyboard;
            end
            params = rmfield(params,'RFPdim');
            params.RFP = RFP;
            for autogamma = [0]
                for C = 10.^[-5:0];
                    for op = [3 2]% 3
                        params.trainFun = @liblineardensetrain;
                        params.testFun = @liblineardensepredict;
                        params.kernel = [];
                        params.autogamma = 0;
                        params.gamma = [];
                        params.options = ['-s ' num2str(op)];
                        params.C = C;
                        params.cThresh = .005;
                        params.maxCItt = 3;
                        params.svmName = sprintf('LF-%s-G%.4f%s',svmNameBase,autogamma*gamma,strrep(params.options,' ','_'));
                        if(autogamma == 0)
                            if(isfield(params,'RFP'))
                                params = rmfield(params,'RFP');
                            end
                            params.svmName = sprintf('LF-%s-G%.4f%s',[svmNameBase(1:end-12) '-' params.normType],autogamma*gamma,strrep(params.options,' ','_'));
                        else
                            params.RFP = RFP/autogamma;
                        end

                        params.svmName = [params.svmName '-C' num2str(params.C)];
                        busyFile = fullfile(TestFold,svmFold,['busy2-' params.svmName '.mat']);
                        if(exist(busyFile,'file'))
                            continue;
                        end
                        try
                            save(busyFile,'busyFile');

                            %{-
                            %with doing validation on test set
                            if(true || rangeN(2)==8)
                                saveFile = fullfile(TestFold,svmFold,[params.svmName '.mat']);
                                clear rates;
                                if(~exist(saveFile,'file'))
                                    svm = MySVMTrain(fe,le,params);%,testFeats,testLabels);
                                    save(saveFile,'svm');
                                else
                                    load(saveFile);
                                end
                                fprintf('Testing %s\n',params.svmName);
                                if(~exist('rates','var'))
                                    [rates] = MySVMTest(testFeats,testLabels,svm);
                                    save(saveFile,'svm','rates');
                                end
                                prates = rates(:,1)./rates(:,2);
                                fprintf(fid,'%s\t',params.svmName);fprintf(fid,'%f\t',[svm.params.C ratioH ratioE 1-ratioH-ratioHD-ratioE sum(prates(1:2))]);fprintf(fid,'%.3f\t',prates);fprintf(fid,'\n');
                            %}
                            
                            %cross validation
                            %{
                            params.svmName = [params.svmName 'c3'];
                            params.cvSize = 5;
                            saveFile = fullfile(TestFold,svmFold,[params.svmName '.mat']);
                            make_dir(saveFile);
                            clear rates;
                            if(~exist(saveFile,'file'))
                                svm = MySVMTrain(fe,le,params);
                                save(saveFile,'svm');
                            else
                                load(saveFile);
                            end
                            fprintf('Testing %s\n',params.svmName);
                            if(~exist('rates','var'))
                                [rates] = MySVMTest(testFeats,testLabels,svm);
                                save(saveFile,'svm','rates');
                            end
                            prates = rates(:,1)./rates(:,2);
                            fprintf(fid,'%s\t',params.svmName);fprintf(fid,'%f\t',[svm.params.C ratioH ratioE 1-ratioH-ratioHD-ratioE sum(prates(1:2))]);fprintf(fid,'%.3f\t',prates);fprintf(fid,'\n');
                            %}
                            else
                            %{
                                %with doing validation on test set
                                if(autogamma == 0) 
                                    fprintf('Autogamma = 0 \n');
                                    continue;
                                end
                                params.trainFun = @libsvmtrain;
                                params.testFun = @libsvmpredict;
                                params.kernel = 2;
                                params.gamma = 1/(2*((autogamma*gamma)^2));
                                params.options = [];
                                if(isfield(params,'RFP'))
                                    params = rmfield(params,'RFP');
                                end
                                params.svmName = sprintf('%s-G%.4f-ac',[svmNameBase(1:end-12) '-' params.normType],autogamma*gamma);
                                saveFile = fullfile(TestFold,svmFold,[params.svmName '.mat']);
                                clear rates;
                                if(~exist(saveFile,'file'))
                                    svm = MySVMTrain(fe,le,params,testFeats,testLabels);
                                    save(saveFile,'svm');
                                else
                                    load(saveFile);
                                end
                                fprintf('Testing %s\n',params.svmName);
                                if(~exist('rates','var'))
                                    [rates] = MySVMTest(testFeats,testLabels,svm);
                                    save(saveFile,'svm','rates');
                                end
                                prates = rates(:,1)./rates(:,2);
                                fprintf(fid,'%s\t',params.svmName);fprintf(fid,'%f\t',[svm.params.C ratioH ratioE 1-ratioH-ratioHD-ratioE sum(prates(1:2))]);fprintf(fid,'%.3f\t',prates);fprintf(fid,'\n');
                            %}
                            end
                            delete(busyFile);
                        catch err
                            delete(busyFile);
                            throw(err);
                        end
                    end
                end
            end
            end
        end
        %}
        
        %{
        for gamma = [1./(66*2.^(0:2)) 2.^(0:5)]
            for C = 1
            clear params;
            params.trainFun = @svmtrain;
            params.testFun = @svmpredict;
            params.kernel = 3;
            params.gamma = gamma;
            params.options = '-h 0';
            params.normType = 'std';
            params.cvSize = 1;
            params.cvTarget = 'avgPerClass';
            params.C = C;
            params.rmDim = [];%1:33;
            params.names = names;
            params.svmName = sprintf('RBF-SS%dk-RH%.2f-RE%.2f-G%.3f-C%.3f-%s',ss/1000,ratioH,ratioE,gamma,params.C,params.normType);

            saveFile = fullfile(TestFold,svmFold,[params.svmName '.mat']);
            make_dir(saveFile);
            clear rates;

            fprintf('Training %s\n',params.svmName);
            if(~exist(saveFile,'file'))
                svm = MySVMTrain(fe,le, params);
                save(saveFile,'svm');
            else
                load(saveFile);
            end
            fprintf('Testing %s\n',params.svmName);
            %{-
            if(~exist('rates','var'))
                [rates] = MySVMTest(testFeats,testLabels,svm);
                save(saveFile,'svm','rates');
            end
            prates = rates(:,1)./rates(:,2);
            fprintf(fid,'%s\t',params.svmName);fprintf(fid,'%.2f\t',[ratioH ratioHD ratioE 1-ratioH-ratioHD-ratioE sum(prates(1:2))]);fprintf(fid,'%.3f\t',prates);fprintf(fid,'\n');
            end
        end
        %}
        
        
        
    end
    %ProgressBar(pfig,find(ss == ssrange),length(ssrange));
end
%close(pfig);

%}
