LoadForDetectors;

testParams.globalDescriptors = {'spatialPryScaled','colorGist','coHist'};

myRandomize;
rp = randperm(length(trainFileList));
%rp = 1:length(trainFileList);
lastMaxMined = 0;
pfig = ProgressBar('Adding Calibration');
for max_mined = [20.*4.^(3)]%0:-1:0
for i = rp(:)'
    [fold base] = fileparts(trainFileList{i});
    modelCalibratedFile = fullfile(HOMECLASSIFIER,'Calibrated',['Model' num2str(max_mined)],fold,[base '.mat']);
    if(exist(modelCalibratedFile,'file'))
        continue;
    end
    modelMMFile = fullfile(HOMECLASSIFIER,['Model' num2str(max_mined)],fold,[base '.mat']);make_dir(modelMMFile);
    if(exist(modelMMFile,'file'))
        load(modelMMFile);
    else
        continue;
    end
    models = AddPolyToModel(HOMEANNOTATIONS,models,modelMMFile);
    clsNums = cellfun(@(x)x.clsNum,models);
    betas = zeros(length(models),2);
    keepModel = false(length(models),1);
    for l = unique(clsNums(:)');
        caliFile = fullfile(HOMECLASSIFIER,'Calibration',['Model' num2str(max_mined)],labels{l},fold,[base '.mat']);make_dir(caliFile);
        cal = [];
        if(exist(caliFile,'file'))
            cal = load(caliFile);
        else
            if(labelPresenceMap(i,l))
                fprintf('Calibration file is missing for: %s\n',labels{l});
            else
                fprintf('Label presence map wrong for: %s\n',labels{l});
            end
            continue;
            %keyboard;
        end
        modelNdx = find(clsNums==l);
        if(length(modelNdx) == length(cal.modelNdx) && all(modelNdx == cal.modelNdx))
            for j = 1:length(modelNdx)
                models{modelNdx(j)}.betas = cal.betas(j,:);
            end
            betas(modelNdx,:) = cal.betas;
            keepModel(modelNdx) = true;
        else
            fprintf('Calibration file is not matched with the model file\n');
            keyboard;
        end
    end
    models(~keepModel) = [];
    if(sum(~keepModel)>0)
        %fprintf('%d missing betas for: %s/%s\n',sum(~keepModel),fold, base);
    end
    make_dir(modelCalibratedFile);save(modelCalibratedFile,'models');
    ProgressBar(pfig,find(rp==i),length(rp));
end
end
close(pfig);