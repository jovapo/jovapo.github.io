LoadForDetectors;

dataset_params.datadir = HOMEDATA;
dataset_params.localdir = '';%fullfile(HOMEDATA,testParams.TestString);
dataset_params.display = 0;
detectorParams = esvm_get_default_params;
detectorParams.dataset_params = dataset_params;
detectorParams.preComputeHOG = false;
%detectorParams.init_params.sbin = 4; %for siftflow
detectorParams.init_params.sbin = trainSBin;
detectorParams.init_params.goal_ncells = 100;

train_params = detectorParams;
%train_params.detect_max_scale = 1; %for siftflow
train_params.detect_max_scale = trainMaxScale;
train_params.detect_exemplar_nms_os_threshold = 1.0; 
train_params.detect_max_windows_per_exemplar = 100;
train_params.ordering = 1:length(trainFileList);
%train_params.queue_mode  = 'cycle-violators';

if(~exist('mineImsWithLabel','var'))
    mineImsWithLabel = false;
end
if(mineImsWithLabel || exist('minNegOptions','var'))
    mine_all_gt_labels = cell(size(trainFileList));
    for i= 1:length(trainFileList)
        [fold base] = fileparts(trainFileList{i});
        tmp = load(fullfile(HOMELABELSETS{1},fold,[base '.mat']));
        mine_all_gt_labels{i} = tmp.S;
    end
end

val_params = detectorParams;
val_params.detect_exemplar_nms_os_threshold = 0.5;
val_params.gt_function = @sp_load_gt_function;

myRandomize;
notDone = [];
%rp = randperm(length(trainFileList));
rp = 1:length(trainFileList);
lastMaxMined = 0;
for max_mined = [max_mined_range]%[length(trainFileList)]%[20.*4.^(3)]%00:
train_params.train_max_mined_images = max_mined;
for rpndx = 1:length(rp)
    i = rp(rpndx);
    [fold base] = fileparts(trainFileList{i});
    modelMMFile = fullfile(HOMECLASSIFIER,['Model' num2str(max_mined)],fold,[base '.mat']);make_dir(modelMMFile);
    if(exist(modelMMFile,'file'))
        try
            %load(modelMMFile);
            continue;
        catch
            fprintf('deleting %s/%s\n',fold,base);
            delete(modelMMFile);
        end
    end
    fprintf('starting %s/%s\n',fold,base);
    notDone = [notDone i];
    busyFold = fullfile(HOMEBUSY,fold,base);
    if(exist(busyFold,'file'))
        continue;
    end
    mkdir(busyFold);
    
    timingFile = fullfile(HOMECLASSIFIER,'Timing',fold,[base '.mat']);make_dir(timingFile);
    if(exist(timingFile,'file'))
        load(timingFile);
    else
        fileStats = [];
    end
    %try
    modelFile = fullfile(HOMECLASSIFIER,'FullModel',fold,[base '.mat']);%make_dir(modelFile);
    if(exist(modelFile,'file'))
        load(modelFile);
    else
        initFile = fullfile(HOMECLASSIFIER,'InitModel',fold,[base '.mat']);make_dir(initFile);
        if(exist(initFile,'file'))
            load(initFile);
        else
            e_stream_set = GetDetectorStreamForSingleLM(HOMEIMAGES, HOMEDATA, fullfile(HOMEANNOTATIONS,fold,[base '.xml']), detectorParams);
            %e_stream_set = e_stream_set(1:2);
            timerVar=tic;
            models = esvm_initialize_exemplars(e_stream_set, detectorParams, '');
            fileStats.timeInitModel = toc(timerVar);
            save(timingFile,'fileStats');
            save(initFile,'models');
        end
    end
    retInds = [];
    try
        [retInds rank] = FindRetrievalSet([],[],fullfile(HOMECLASSIFIER),fullfile(fold,base),testParams,'');
    end
    if(length(retInds)~=length(trainFileList))
        delete(fullfile(fullfile(HOMECLASSIFIER),'RetrievalSet',fold,[base '.mat']));
        [retInds rank] = FindRetrievalSet(trainGlobalDesc,SelectDesc(trainGlobalDesc,i,1),fullfile(HOMECLASSIFIER),fullfile(fold,base),testParams,'');
    end
    retInds(retInds==i)=[];

    timing = zeros(size(models));
    for mNdx = 1:length(models)
        m = models{mNdx};
        statMiningNdx = 1;
        if(isfield(m,'total_mines'))
            statMiningNdx = m.total_mines+1;
        end
        if(isfield(train_params,'mine_all_gt_labels'))
            train_params=rmfield(train_params,'mine_all_gt_labels');
        end
        negOptions = retInds(~labelPresenceMap(retInds,m.clsNum));
        if(mineImsWithLabel || (exist('minNegOptions','var') && length(negOptions) < minNegOptions))
            negOptions = retInds;%(~labelPresenceMap(retInds,m.clsNum));
            train_params.mine_all_gt_labels = mine_all_gt_labels(negOptions(statMiningNdx:min(length(negOptions),max_mined)));
        end
        negSet = trainFileListFull(negOptions(statMiningNdx:min(length(negOptions),max_mined)));
        timerVar=tic;
        [models(mNdx),models_name] = esvm_train_exemplars({m}, negSet, train_params);
        timing(mNdx) = toc(timerVar);
    end
    fileStats.(['timeTrainModel' num2str(max_mined)]) = timing;
    fileStats.NumModels = length(models);
    save(timingFile,'fileStats');
    %fprintf('Timing:\n');
    %fprintf('%.2f\n',timing);
    
    %save(modelFile,'models','-v7.3');
    models = esvm_strip_models(models);
    save(modelMMFile,'models','-v7.3');
    clear models;
    fprintf('Finished\n');
    %catch err
    %    keyboard;
    %end
    try
    rmdir(busyFold);
    end
end
lastMaxMined = max_mined;
end



