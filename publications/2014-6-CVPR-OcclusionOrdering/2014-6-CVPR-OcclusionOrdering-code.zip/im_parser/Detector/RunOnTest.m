SetUpConstants;

placeHolder = cell(size(HOMELABELSETS));
testParams.range = rangeTest;
testParams.justSubSample = false;
%for dkt = [0 .1 .2 .3 .4 .5]
    testParams.detect_keep_threshold = .25;
    timing = ParseTestImagesWDetectors(HOMEDATA,HOMEDATA,HOMELABELSETS,testFileList,testGlobalDesc,trainFileList,trainGlobalDesc,[],[],[],Labels,classifiers,placeHolder,testParams);%,fullSPDesc);
%end
