
testName = 'trial';
baseFName = fullfile(fold,base);
Labels{1} = labelList;
imSP = superPixels;
MAX_COST = 10000;
MAX_EXPECTED = 10;
smoothOver = [0 2 4 8 16 32 64 128 256];%[2.^(-2:5)];
clear params;
params.edgeParam = 11;
params.connected=8;
params.S{1} = S;
params.names{1} = names;

saveInfo.HOMEDATA = fullfile(TestFold,testParams.MRFFold);
saveInfo.HOMELABELSET = HOMELABELSETS{1};
saveInfo.baseFName = fullfile(fold,base);
saveInfo.Labels = Labels{1};
saveInfo.names = names;
saveInfo.S = S;

[ro, co, ch] = size(im);
sp = imresize(-log(spatialPrior),[ro co],'nearest');
sp = reshape(sp,size(predictors));

%{
pn = 1./(1+exp(-predictors));
ps = sum(pn,2);
pn = -log(bsxfun(@rdivide,pn,ps));
dataCost{1} = pn./max(pn(:));
dataCost{1} = int32(dataCost{1}*MAX_COST);
timerVar = 0;
for smoothing = smoothOver
    testName = sprintf('SigRowNorm-%s-SS%03d',testSVMList{i},smoothing);
    smoothingMatrix = smoothing*(ones(length(labelList))-eye(length(labelList)));
    timerVarTic = tic;
    [LabelPixels] = MultiLevelPixMRF(fullfile(TestFold,testParams.MRFFold),HOMELABELSETS,testName,baseFName,Labels,imSP,im,dataCost,smoothingMatrix,[],params);
    timerVar=timerVar+toc(timerVarTic);
    %show(LabelPixels{1},1);
end
fieldName= ['timeMRFSigNorm' num2str(i)];
avgTime = timerVar/length(smoothOver);
if(~isfield(fileStats,fieldName) || fileStats.(fieldName)<avgTime)
    fileStats.(fieldName) = avgTime;
end
save(timingFile,'fileStats');
dataCost{1} = pn/10;
dataCost{1} = int32(dataCost{1}*MAX_COST);
timerVar = 0;
for smoothing = smoothOver
    testName = sprintf('SigRow-%s-SS%03d',testSVMList{i},smoothing);
    smoothingMatrix = smoothing*(ones(length(labelList))-eye(length(labelList)));
    timerVarTic = tic;
    [LabelPixels] = MultiLevelPixMRF(fullfile(TestFold,testParams.MRFFold),HOMELABELSETS,testName,baseFName,Labels,imSP,im,dataCost,smoothingMatrix,[],params);
    timerVar=timerVar+toc(timerVarTic);
    %show(LabelPixels{1},1);
end


unary = pn;
for smoothing = smoothOver
    saveInfo.testName = sprintf('DCRF-SigRow-%s-SS%03d',testSVMList{i},smoothing);
    [L0 timerVar] = SmoothCRF(im,unary,[],smoothing,saveInfo);
    %show(L0,1);
end
unary = pn./max(pn(:));
for smoothing = smoothOver
    saveInfo.testName = sprintf('DCRF-SigRowNorm-%s-SS%03d',testSVMList{i},smoothing);
    [L0 timerVar] = SmoothCRF(im,unary,[],smoothing,saveInfo);
    %show(L0,1);
end

%}
predictors(predictors<-50) = -50;
pn = -log(1./(1+exp(-predictors)));
%{
dataCost{1} = pn./max(pn(:));
dataCost{1} = int32(dataCost{1}*MAX_COST);
timerVar = 0;
for smoothing = smoothOver
    testName = sprintf('SigNorm-%s-SS%03d',testSVMList{i},smoothing);
    smoothingMatrix = smoothing*(ones(length(labelList))-eye(length(labelList)));
    timerVarTic = tic;
    [LabelPixels] = MultiLevelPixMRF(fullfile(TestFold,testParams.MRFFold),HOMELABELSETS,testName,baseFName,Labels,imSP,im,dataCost,smoothingMatrix,[],params);
    timerVar=timerVar+toc(timerVarTic);
    %show(LabelPixels{1},1);
end
%}
%dataCost{1} = pn+sp.*sw;
%dataCost{1} = int32(dataCost{1}*MAX_COST);
timerVar = 0;

smoothOver = [0 2.^(0:8)];%[2.^(-2:5)];
for smoothing = smoothOver
    for sw = [0 .05 .1 .2]
    dataCost{1} = pn+sp.*sw;
    dataCost{1} = int32(dataCost{1}*MAX_COST);
    testName = sprintf('Sig-%s-SS%03d-sw%.2f',testSVMList{i},smoothing,sw);
    smoothingMatrix = smoothing*(ones(length(labelList))-eye(length(labelList)));
    timerVarTic = tic;
    [LabelPixels] = MultiLevelPixMRF(fullfile(TestFold,testParams.MRFFold),HOMELABELSETS,testName,baseFName,Labels,imSP,im,dataCost,smoothingMatrix,[],params);
    timerVar=timerVar+toc(timerVarTic);
    %show(LabelPixels{1},1);
    end
end

smoothOver = [0 2.^(0:8)];%[2.^(-2:5)];
unary = pn;
for smoothing = smoothOver
    for sw = [0 .05 .1 .2]
        saveInfo.testName = sprintf('DCRF-Sig-%s-SS%03d-sw%.2f',testSVMList{i},smoothing,sw);
        [L0 timerVar] = SmoothCRF(im,unary+sp.*sw,[],smoothing,saveInfo);
    end
    %show(L0,1);
end
%{
unary = pn./max(pn(:));
for smoothing = smoothOver
    saveInfo.testName = sprintf('DCRF-SigNorm-%s-SS%03d',testSVMList{i},smoothing);
    [L0 timerVar] = SmoothCRF(im,unary,[],smoothing,saveInfo);
    %show(L0,1);
end
%}
%{
smoothOver = [2.^(-2:7)];
dataCost{1} = (max(MAX_EXPECTED,max(predictors(:)))-predictors)./(MAX_EXPECTED*2);%-log(bsxfun(@rdivide,p,ps));%
unary = dataCost{1};
for smoothing = smoothOver
    saveInfo.testName = sprintf('DCRF-LinNorm-%s-SS%03d',testSVMList{i},smoothing);
    [L0 timerVar] = SmoothCRF(im,unary,[],smoothing,saveInfo);
    %show(L0,1);
end

%}

dataCost{1} = (max(MAX_EXPECTED,max(predictors(:)))-predictors)./(MAX_EXPECTED*2);%-log(bsxfun(@rdivide,p,ps));%
dataCost{1} = int32(dataCost{1}*MAX_COST);
timerVar = 0;
for smoothing = smoothOver
    testName = sprintf('LinNorm-%s-SS%03d',testSVMList{i},smoothing);
    smoothingMatrix = smoothing*(ones(length(labelList))-eye(length(labelList)));
    timerVarTic = tic;
    [LabelPixels] = MultiLevelPixMRF(fullfile(TestFold,testParams.MRFFold),HOMELABELSETS,testName,baseFName,Labels,imSP,im,dataCost,smoothingMatrix,[],params);
    timerVar=timerVar+toc(timerVarTic);
    %show(LabelPixels{1},1);
end
fieldName= ['timeMRF' num2str(i)];
avgTime = timerVar/length(smoothOver);
if(~isfield(fileStats,fieldName) || fileStats.(fieldName)<avgTime)
    fileStats.(fieldName) = avgTime;
end
save(timingFile,'fileStats');

clear pn dataConst;


