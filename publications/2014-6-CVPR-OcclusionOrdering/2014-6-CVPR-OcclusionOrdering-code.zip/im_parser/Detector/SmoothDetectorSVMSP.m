
testName = 'trial';
baseFName = fullfile(fold,base);
Labels{1} = labelList;
imSP = superPixels;
MAX_COST = 10000;
MAX_EXPECTED = 10;
dataCost{1} = (max(MAX_EXPECTED,-min(predictorsSP(:)))-predictorsSP)./(MAX_EXPECTED*2);
dataCost{1} = int32(dataCost{1}*MAX_COST);
params.S{1} = S;
params.names{1} = names;
for smoothing = [2.^(1:9)]
    testName = sprintf('%s-SS%03d-SP',testSVMList{i},smoothing);
    smoothingMatrix = smoothing*(ones(length(labelList))-eye(length(labelList)));
    [LabelPixels] = MultiLevelSegMRF(fullfile(TestFold,'MRF'),HOMELABELSETS,testName,baseFName,Labels,imSP,adjPairs,dataCost,smoothingMatrix,[],params);
    %show(LabelPixels{1},1);
end