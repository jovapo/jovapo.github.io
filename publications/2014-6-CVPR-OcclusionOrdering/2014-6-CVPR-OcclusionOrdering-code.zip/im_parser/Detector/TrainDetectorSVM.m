SetUpConstants;

[foo LabelSetFold] = fileparts(HOMELABELSETS{1});
sampleSize = 1e6;

testDataFile = fullfile(TestFold,sprintf('PreSVMData-MM%04d.mat',testParams.MaxModelPerCls));
trainDataFile = fullfile(HOMERUNONTRAINING,[svmFold 'Data.mat']);
%{-
if(exist(trainDataFile,'file'))
    load(trainDataFile);
else
    %detFiles = dir_recurse(fullfile(HOMERUNONTRAINING,'ExemplarDataTerm',detectorFold,'*'),0);
    detFiles = trainFileList;
    dataFile = fullfile(HOMERUNONTRAINING,'svmTrainingSplitInd.mat');
    %{-
    if(~exist(dataFile,'file'))
        labelFile = fullfile(HOMERUNONTRAINING,'svmTrainingLabels.mat');
        %{-
        if(~exist(labelFile,'file'))
            allTrainingLabels = cell(size(detFiles));
            startPoint = zeros(length(detFiles),1);
            startPoint(1) = 1;
            for f = 1:length(detFiles)
                [fold base] = fileparts(detFiles{f});
                load(fullfile(HOMELABELSETS{1},fold,[base '.mat'])); %S (ro x co) names
                allTrainingLabels{f} = uint8(S(:));
                startPoint(f+1) = startPoint(f)+numel(S);
            end
            allTrainingLabels = vertcat(allTrainingLabels{:});
            save(labelFile,'allTrainingLabels','startPoint','detFiles','names','-v7.3');
        else
            load(labelFile);
        end
        %}-
        
        
        [~, ~, evnMask] = MySubSample(allTrainingLabels,allTrainingLabels,sampleSize,1,[],1:max(allTrainingLabels));
        useMask = ~evnMask&(allTrainingLabels~=0);
        clear allTrainingLabels;
        indEvn = find(evnMask);
        clear evnMask;
        numEl = sum(useMask);
        ss = numEl/sampleSize;
        ndxs = floor(1:ss:numEl);
        indUni = zeros(size(ndxs));
        adder = 0;
        indUniNdx = 1;
        range = [floor(1:ss:length(useMask)) length(useMask)+1];
        for i = 1:length(range)-1;
            start = range(i);
            endN = range(i+1)-1;
            a = cumsum(useMask(start:endN))+adder;
            ndx = find(a>=ndxs(indUniNdx),1);
            if(~isempty(ndx))
                indUni(indUniNdx) = ndx+start-1;
                indUniNdx = indUniNdx+1;
                if(indUniNdx>length(indUni))
                    break;
                end
            end
            adder = a(end);
        end
        clear useMask;
        save(dataFile,'indUni','indEvn','startPoint','detFiles','names');
    else
        load(dataFile);
    end
    %}-
    
    labelsEvnOvLp = zeros(length(indEvn),length(names),'int16')==1;
    labelsUniOvLp = zeros(length(indUni),length(names),'int16')==1;
    labelsEvn = zeros(length(indEvn),1,'int16');
    labelsUni = zeros(length(indUni),1,'int16');
    if(exist('secondDataterm','var') && ~isempty(secondDataterm))
        featsEvn = zeros(length(indEvn),length(names)*3);
        featsUni = zeros(length(indUni),length(names)*3);
    else
        featsEvn = zeros(length(indEvn),length(names)*2);
        featsUni = zeros(length(indUni),length(names)*2);
    end
    
    i = 1;evnStart = 1;uniStart=1;
    pfig = ProgressBar('Loading SVM training Data');
    
    for f = 1:length(detFiles)
        [fold base] = fileparts(detFiles{f});
        if(isempty(strfind(detFiles{f},base)))
            keyboard;
        end
        saveFeatFile = fullfile(HOMERUNONTRAINING,'SubSampleFeats',fold,[base '.mat']);
        saveDetFile = fullfile(HOMERUNONTRAINING,'SubSampleFeats',detectorFold,fold,[base '.mat']);
        load(fullfile(HOMELABELSETS{1},fold,[base '.mat'])); %S (ro x co) names
        label = S(:);
        indImEvn = indEvn(indEvn>=startPoint(f) & indEvn<startPoint(f+1))-startPoint(f)+1;
        indImUni = indUni(indUni>=startPoint(f) & indUni<startPoint(f+1))-startPoint(f)+1;
        i = i+length(label);
        if(exist(saveFeatFile,'file'))
            %{
            fsp = find(~cellfun(@(x) isempty(x),strfind(detFiles,strrep(fullfile(fold,base),filesep,'\'))));
            if(length(fsp)~=1)
                continue;
            end
            if(fsp~=f)
                fprintf('miss match %s %s\n',fold,base);
            end
            %}
            
            sf = load(saveFeatFile);
            if(any(sf.indImEvn~=indImEvn) || any(sf.indImUni~=indImUni))
                keyboard;
            end
            
            labelsEvn(evnStart:evnStart+length(sf.indImEvn)-1) = sf.lEvn;
            labelsEvnOvLp(evnStart:evnStart+length(sf.indImEvn)-1,:) = sf.lEvnOvLp;
            featsEvn(evnStart:evnStart+length(sf.indImEvn)-1,:) = sf.fEvn;
            evnStart = evnStart+length(sf.indImEvn);

            labelsUni(uniStart:uniStart+length(sf.indImUni)-1) = sf.lUni;
            labelsUniOvLp(uniStart:uniStart+length(sf.indImUni)-1,:) = sf.lUniOvLp;
            featsUni(uniStart:uniStart+length(sf.indImUni)-1,:) = sf.fUni;
            uniStart = uniStart+length(sf.indImUni);
        else
            try
                %{-
                clear dataTerm imDet;
                if(exist(saveDetFile,'file'))
                    imDet = load(saveDetFile);
                    if(any(imDet.indImEvn ~= indImEvn) || any(imDet.indImUni ~= indImUni))
                        fprintf('ERROR MISSMATCH\n');
                        keyboard;
                    end
                else
                    load(fullfile(HOMERUNONTRAINING,'ExemplarDataTerm',detectorFold,fold,[base '.mat'])); %dataTerm (ro x co x #l) dataTermMax
                end
                if(exist('secondDataterm','var') && ~isempty(secondDataterm))
                    a = load(fullfile(HOMERUNONTRAINING,secondDataterm,detectorFold,fold,[base '.mat']));
                    dataTerm2 = a.dataTerm;
                end
                a = load(fullfile(HOMERUNONTRAINING,LabelSetFold,parserFold,fold,[base '.mat'])); %probPerLabel (#SP x #l)
                if(isfield(a,'probPerLabel'))
                    probPerLabel = a.probPerLabel;
                elseif(isfield(a,'prob'))
                    probPerLabel = a.prob;
                end
                load(fullfile(HOMEDATA,'Descriptors',spFold,'super_pixels',fold,[base '.mat'])); %superPixels (ro x co)
                %}-
                ann = LMread(fullfile(HOMEANNOTATIONS,fold,[base '.xml']));
            catch
                continue;
            end
            %{-
            uSP = unique(superPixels);
            spMap = zeros(max(uSP),1);
            spMap(uSP) = 1:length(uSP);
            
            if(exist('secondDataterm','var') && ~isempty(secondDataterm))
                feat = [probPerLabel(spMap(superPixels),:) reshape(dataTerm,[],size(dataTerm,3)) reshape(dataTerm2,[],size(dataTerm2,3))];
            elseif(~exist(saveDetFile,'file'))
                feat = [probPerLabel(spMap(superPixels),:) reshape(dataTerm,[],size(dataTerm,3))];
            else
                feat = [probPerLabel(spMap(superPixels),:)];
            end
                    
            %}-

            labelsEvn(evnStart:evnStart+length(indImEvn)-1) = label(indImEvn);
            [Y, X] = ind2sub(size(S),indImEvn);
            labelsEvnOvLp(evnStart:evnStart+length(indImEvn)-1,:) = PointsToPolyLabels( ann, X, Y, length(names) );
            if(~exist(saveDetFile,'file'))
                featsEvn(evnStart:evnStart+length(indImEvn)-1,:) = feat(indImEvn,:);
            else
                featsEvn(evnStart:evnStart+length(indImEvn)-1,:) = [feat(indImEvn,:) imDet.detEvn];
            end
            %{
            if(any(labelsEvn2(evnStart:evnStart+length(indImEvn)-1)~=labelsEvn(evnStart:evnStart+length(indImEvn)-1)))
                keyboard;
                continue;
            end
            if(any(labelsEvnOvLp(sub2ind(size(labelsEvnOvLp),evnStart:evnStart+length(indImEvn)-1,double(labelsEvn(evnStart:evnStart+length(indImEvn)-1)')))==0))
                ind = find(labelsEvnOvLp(sub2ind(size(labelsEvnOvLp),evnStart:evnStart+length(indImEvn)-1,double(labelsEvn(evnStart:evnStart+length(indImEvn)-1)')))==0);
                [a b] = find(labelsEvnOvLp(evnStart:evnStart+length(indImEvn)-1,:)');c=labelsEvn2(evnStart:evnStart+length(indImEvn)-1);
                [a(b==ind) b(b==ind) X(b(b==ind)) Y(b(b==ind))]
                [c(ind) X(ind) Y(ind)]
                keyboard;
            end
            %}
            evnStart = evnStart+length(indImEvn);

            labelsUni(uniStart:uniStart+length(indImUni)-1) = label(indImUni);
            [Y, X] = ind2sub(size(S),indImUni);
            labelsUniOvLp(uniStart:uniStart+length(indImUni)-1,:) = PointsToPolyLabels( ann, X, Y, length(names) );
            if(~exist(saveDetFile,'file'))
                featsUni(uniStart:uniStart+length(indImUni)-1,:) = feat(indImUni,:);
            else
                featsUni(uniStart:uniStart+length(indImUni)-1,:) = [feat(indImUni,:) imDet.detUni];
            end
            %{
            if(any(labelsUni2(uniStart:uniStart+length(indImUni)-1)~=labelsUni(uniStart:uniStart+length(indImUni)-1)))
                keyboard;
            end
            if(any(labelsUniOvLp(sub2ind(size(labelsUniOvLp),uniStart:uniStart+length(indImUni)-1,double(labelsUni(uniStart:uniStart+length(indImUni)-1)')))==0))
                ind = find(labelsUniOvLp(sub2ind(size(labelsUniOvLp),uniStart:uniStart+length(indImUni)-1,double(labelsUni(uniStart:uniStart+length(indImUni)-1)')))==0);
                [a b] = find(labelsUniOvLp(uniStart:uniStart+length(indImUni)-1,:)');c=labelsUni(uniStart:uniStart+length(indImUni)-1);
                [a(b==ind) b(b==ind) X(b(b==ind)) Y(b(b==ind))]
                [c(ind) X(ind) Y(ind)]
                keyboard;
            end
            %}
            uniStart = uniStart+length(indImUni);
        end
        if(mod(f,10)==0)
            ProgressBar(pfig,f,length(detFiles));
        end
    end
    close(pfig);
    save(trainDataFile,'labelsEvn','labelsEvnOvLp','featsEvn','indEvn','labelsUni','labelsUniOvLp','featsUni','indUni','names','-v7.3');
    clear feats labels;
end
fprintf('Num Evn Different: %d\n',sum(labelsEvnOvLp(sub2ind(size(labelsEvnOvLp),find(labelsEvn~=0),double(labelsEvn(labelsEvn~=0))))==0));
fprintf('Num Evn Not 0: %d\n',sum(sum(labelsEvnOvLp(labelsEvn==0,:),2)~=0));
fprintf('Num Uni Different: %d\n',sum(labelsUniOvLp(sub2ind(size(labelsUniOvLp),find(labelsUni~=0),double(labelsUni(labelsUni~=0))))==0));
fprintf('Num Evn Not 0: %d\n',sum(sum(labelsUniOvLp(labelsUni==0,:),2)~=0));
featsUni(labelsUni==0,:) = [];
labelsUniOvLp(labelsUni==0,:) = [];
indUni(labelsUni==0) = [];
labelsUni(labelsUni==0) = [];
indUni = indUni(:);
labelsUni = labelsUni(:);

featsEvn(labelsEvn==0,:) = [];
labelsEvnOvLp(labelsEvn==0,:) = [];
indEvn(labelsEvn==0) = [];
labelsEvn(labelsEvn==0) = [];
indEvn = indEvn(:);
labelsEvn = labelsEvn(:);
%}

if(exist(testDataFile,'file') )
    load(testDataFile);
else
    detFiles = testFileList;% dir_recurse(fullfile(TestFold,'ExemplarDataTerm',detectorFold,'*'),0);

    allTrainingLabels = cell(size(detFiles));
    for f = 1:length(detFiles)
        [fold base] = fileparts(detFiles{f});
        load(fullfile(HOMELABELSETS{1},fold,[base '.mat'])); %S (ro x co) names
        allTrainingLabels{f} = S(:);
    end
    allTrainingLabels = vertcat(allTrainingLabels{:});
    
    labelsZero = allTrainingLabels==0;
    testMask = zeros(size(allTrainingLabels))==1;
    [~, ~, mask] = MySubSample(allTrainingLabels(~labelsZero),allTrainingLabels(~labelsZero),10*length(names),1);
    testMask(~labelsZero)= mask;
    [~, ~, mask] = MySubSample(allTrainingLabels(~testMask&~labelsZero),allTrainingLabels(~testMask&~labelsZero),sampleSize,0);
    testMask(~testMask&~labelsZero)= mask;
    
    testLabels = zeros(sum(testMask),1,'int16');
    if(exist('secondDataterm','var') && ~isempty(secondDataterm))
        testFeats = zeros(sum(testMask),length(names)*3);
    else
        testFeats = zeros(sum(testMask),length(names)*2);
    end
    testlabelsOvLp = false(sum(testMask),length(names));
    
    i = 1;testStart = 1;uniStart=1;
    pfig = ProgressBar('Loading SVM training Data');
    for f = 1:length(detFiles)
        [fold base] = fileparts(detFiles{f});
        try
            load(fullfile(TestFold,'ExemplarDataTerm',detectorFold,fold,[base '.mat'])); %dataTerm (ro x co x #l) dataTermMax
            if(exist('secondDataterm','var') && ~isempty(secondDataterm))
                a = load(fullfile(TestFold,secondDataterm,detectorFold,fold,[base '.mat'])); %dataTerm (ro x co x #l) dataTermMax
                dataTerm2 = a.dataTerm;
            end
            a = load(fullfile(TestFold,LabelSetFold,parserFold,fold,[base '.mat'])); %probPerLabel (#SP x #l)
            if(isfield(a,'probPerLabel'))
                probPerLabel = a.probPerLabel;
            elseif(isfield(a,'prob'))
                probPerLabel = a.prob;
            end
            load(fullfile(HOMEDATA,'Descriptors',spFold,'super_pixels',fold,[base '.mat'])); %superPixels (ro x co)
            load(fullfile(HOMELABELSETS{1},fold,[base '.mat'])); %S (ro x co) names
            ann = LMread(fullfile(HOMEANNOTATIONS,fold,[base '.xml']));
        catch
            continue;
        end
        if(all(max(dataTerm,[],3)==0))
            keyboard;
        end
        uSP = unique(superPixels);
        spMap = zeros(max(uSP),1);
        spMap(uSP) = 1:length(uSP);
        if(exist('secondDataterm','var') && ~isempty(secondDataterm))
            feat = [probPerLabel(spMap(superPixels),:) reshape(dataTerm,[],size(dataTerm,3)) reshape(dataTerm2,[],size(dataTerm2,3))];
        else
            feat = [probPerLabel(spMap(superPixels),:) reshape(dataTerm,[],size(dataTerm,3))];
        end
        label = S(:);
        
        testImMask = testMask(i:i+length(label)-1);
        testLabels(testStart:testStart+sum(testImMask)-1) = label(testImMask);
        testFeats(testStart:testStart+sum(testImMask)-1,:) = feat(testImMask,:);
        [Y, X] = ind2sub(size(S),find(testImMask));
        testlabelsOvLp(testStart:testStart+sum(testImMask)-1,:) = PointsToPolyLabels( ann, X, Y, length(names) );
        testStart = testStart+sum(testImMask);
        
        i = i+length(label);
        if(mod(f,10)==0)
            ProgressBar(pfig,f,length(detFiles));
        end
    end
    close(pfig);
    save(testDataFile,'testFeats','testLabels','testlabelsOvLp','names','-v7.3');
end
%}
fprintf('Num test Different: %d\n',sum(testlabelsOvLp(sub2ind(size(testlabelsOvLp),find(testLabels~=0),double(testLabels(testLabels~=0))))==0));
fprintf('Num test Not 0: %d\n',sum(sum(testlabelsOvLp(testLabels==0,:),2)~=0));


%Linear SVM


params.trainFun = @libwsvmtrain;
params.testFun = @libwsvmpredict;
params.kernel = 0;
params.gamma = [];
params.svmName = 'Training Set SP Rate';
params.normType = 'std';
params.cvTarget = 'avgPerClass';
params.C = 1;
svm = cell(0);
params.cvSize = 1;
params.options = ' -h 0';
params.rmDim = [];
params.names = names;
numLs = length(names);

if(exist(fullfile(HOME,'StuffLabels.txt'),'file'))
    sl = importdata(fullfile(HOME,'StuffLabels.txt'));
    [~, stuffLs] = intersect(names,sl);
end

close all;
MyCleanUp;
make_dir(fullfile(TestFold,svmFold,'resultsFullTest.txt'));
fid = fopen(fullfile(TestFold,svmFold,'resultsFullTest.txt'),'w');
fprintf(fid,'SVM Name\tC param\tHard Ratio\tEven Ratio\tSub-sampled Ratio\tMulti\tClass\tPer-pix + Per-class\tPer-pixel\tPer-class\t');
fprintf(fid,'%s\t',names{:});
fprintf(fid,'\n');
[a b] = UniqueAndCounts(labelsUni);
fprintf(fid,'Training Set Counts\t\t\t\t\t\t\t\t\t\t');
fprintf(fid,'%d\t',b);
fprintf(fid,'\n');

[maxFeats MaxL] = max(featsUni(:,1:numLs),[],2);
rates = MySVMRates(MaxL,labelsUni);
fprintf(fid,'%s\t',params.svmName);fprintf(fid,'\t\t\t\t\t\t\t');fprintf(fid,'%.3f\t',rates(:,1)./rates(:,2));fprintf(fid,'\n');

correctFeatsInd = sub2ind(size(featsUni),1:size(featsUni,1),double(labelsUni'));
cdFeatsDiff = maxFeats-featsUni(correctFeatsInd');
hardFeatsInd = cdFeatsDiff>0;

if(exist('secondDataterm','var') && ~isempty(secondDataterm))
    [maxFeatsD MaxLD] = max(featsUni(:,numLs+1:numLs*2),[],2);
    rates = MySVMRates(MaxLD,labelsUni);
    params.svmName = 'Training Set Detector Rate';
    fprintf(fid,'%s\t',params.svmName);fprintf(fid,'\t\t\t\t\t\t\t');fprintf(fid,'%.3f\t',rates(:,1)./rates(:,2));fprintf(fid,'\n');
    
    [maxFeatsD MaxLD] = max(featsUni(:,numLs*2+1:end),[],2);
    rates = MySVMRates(MaxLD,labelsUni);
    params.svmName = 'Training Set Detector Rate 2';
    fprintf(fid,'%s\t',params.svmName);fprintf(fid,'\t\t\t\t\t\t\t');fprintf(fid,'%.3f\t',rates(:,1)./rates(:,2));fprintf(fid,'\n');
else
    [maxFeatsD MaxLD] = max(featsUni(:,numLs+1:end),[],2);
    rates = MySVMRates(MaxLD,labelsUni);
    params.svmName = 'Training Set Detector Rate';
    fprintf(fid,'%s\t',params.svmName);fprintf(fid,'\t\t\t\t\t\t\t');fprintf(fid,'%.3f\t',rates(:,1)./rates(:,2));fprintf(fid,'\n');
end

correctFeatsIndD = sub2ind(size(featsUni),1:size(featsUni,1),double(labelsUni')+numLs);
cdFeatsDiffD = maxFeatsD-featsUni(correctFeatsIndD');
hardFeatsIndD = cdFeatsDiffD>0;

%{-
params.svmName = 'Test Set SP Rate';
[maxFeats MaxL] = max(testFeats(:,1:numLs),[],2);
rates = MySVMRates(MaxL,testLabels);
fprintf(fid,'%s\t',params.svmName);fprintf(fid,'\t\t\t\t\t\t\t');fprintf(fid,'%.3f\t',rates(:,1)./rates(:,2));fprintf(fid,'\n');

if(exist('secondDataterm','var') && ~isempty(secondDataterm))
    params.svmName = 'Test Set Detector Rate';
    [maxFeatsD MaxLD] = max(testFeats(:,numLs+1:numLs*2),[],2);
    rates = MySVMRates(MaxLD,testLabels);
    fprintf(fid,'%s\t',params.svmName);fprintf(fid,'\t\t\t\t\t\t\t');fprintf(fid,'%.3f\t',rates(:,1)./rates(:,2));fprintf(fid,'\n');
    
    params.svmName = 'Test Set Detector Rate2';
    [maxFeatsD MaxLD] = max(testFeats(:,numLs*2+1:end),[],2);
    rates = MySVMRates(MaxLD,testLabels);
    fprintf(fid,'%s\t',params.svmName);fprintf(fid,'\t\t\t\t\t\t\t');fprintf(fid,'%.3f\t',rates(:,1)./rates(:,2));fprintf(fid,'\n');
else
    params.svmName = 'Test Set Detector Rate';
    [maxFeatsD MaxLD] = max(testFeats(:,numLs+1:end),[],2);
    rates = MySVMRates(MaxLD,testLabels);
    fprintf(fid,'%s\t',params.svmName);fprintf(fid,'\t\t\t\t\t\t\t');fprintf(fid,'%.3f\t',rates(:,1)./rates(:,2));fprintf(fid,'\n');
end
%}

myRandomize;
%pfig = ProgressBar('Try sub-sample rate of');
configs = [ 0 0 .33];
            %.125 .125 .25];
ssrange = 2.5e5%1e4*2.^5%(3:2:7);%[1e4 1e5];%
for ss = ssrange
    %{-
    for c = 1:size(configs,1);
        ratioH = configs(c,1);
        ratioHD = configs(c,2);
        ratioE = configs(c,3);
        
        if(sum([ratioH ratioHD ratioE])>1)
            continue;
        end
                
        %{-
        %load(trainDataFile);
        [leh, feh, mask] = MySubSample(labelsUni, featsUni, ss*ratioH,0,hardFeatsInd);
        indh = indUni(mask);
        leho = labelsUniOvLp(mask,:);
        [lehd, fehd, mask] = MySubSample(labelsUni, featsUni, ss*ratioHD,0,hardFeatsIndD);
        indhd = indUni(mask);
        lehdo = labelsUniOvLp(mask,:);
        [lee, fee, mask] = MySubSample(labelsEvn, featsEvn, ss*ratioE,1);
        inde = indEvn(mask);
        leeo = labelsEvnOvLp(mask,:);
        [les, fes, mask] = MySubSample(labelsUni,featsUni,ss*(1-ratioH-ratioHD-ratioE),0);
        inds = indUni(mask);
        leso = labelsUniOvLp(mask,:);
        le = [leh; lehd; lee; les];fe = [feh; fehd; fee; fes];ind = [indh; indhd; inde; inds];
        leo = [leho; lehdo; leeo; leso];
        [ind, a] = sort(ind);
        le = le(a);
        fe = fe(a,:);
        leo = leo(a,:);
        clear leh lehd lee les feh fehd fee fes;
        %clear feats;
        %}
        

        %{-
        for dim = [4000]
            for vs = [4]
            clear params;
            params.trainFun = @liblineardensetrain;
            params.testFun = @liblineardensepredict;
            params.kernel = [];
            params.gamma = [];
            params.normType = 'std';
            params.cvSize = 1;
            params.cvTarget = 'avgPlusClass';%'avgPerClass';%
            params.C = 1;
            if(vs == 1)
                params.rmDim = 1:numLs;
            elseif(vs ==2)
                params.rmDim = (numLs+1):(2*numLs);
            elseif(vs==3)
                params.rmDim = numLs+stuffLs;
            else
                params.rmDim = [];%1:33;
            end
            params.names = names;
            params.svmName = sprintf('LinearF-SS%dk-RH%.2f-RHD%.2f-RE%.2f',ss/1000,ratioH,ratioHD,ratioE);
            params.RFPdim = dim;
            svmNameBase = sprintf('SS%dk-RH%.2f-RE%.2f-RFD%d-%s',ss/1000,ratioH,ratioE,params.RFPdim,params.normType);
            if(vs == 1)
                svmNameBase = ['Det-' svmNameBase];
            elseif(vs ==2)
                svmNameBase = ['SP-' svmNameBase];
            elseif(vs ==3)
                svmNameBase = ['NoStuff-' svmNameBase];
            end
            gammaFile = fullfile(TestFold,svmFold,['GammaRFPSave-' svmNameBase '.mat']);
            svmNameBase = ['RBF-' svmNameBase];
            if(~exist(gammaFile,'file'))
                params.autogamma = 1;
                [~, params] = MySVMNormalize(fe,params);
                save(gammaFile,'params');
                gamma = params.gamma;
                RFP = params.RFP;
                fprintf('Gamma: %.4f %s\n',gamma, svmNameBase);
                clear feN d;
            else
                a = load(gammaFile);
                gamma = a.params.gamma;
                RFP = a.params.RFP;
                params.norm = a.params.norm;
            end
            if(size(RFP,2)~=dim/2)
                fprintf('ERRRORRROROR!!!!!\n');
                keyboard;
            end
            params = rmfield(params,'RFPdim');
            params.RFP = RFP;
            for C = 10.^[3 2 1 0  -1  -2  -3 -4 -5];
            for autogamma = [0]
                for op = [2]% 3
                        if(C>10 && op == 3)
                            continue;
                        end
                        for mtcls = [false]
                            params.trainFun = @liblineardensetrain;
                            params.testFun = @liblineardensepredict;
                            params.kernel = [];
                            params.autogamma = 0;
                            params.gamma = [];
                            params.options = ['-s ' num2str(op)];
                            params.C = C;
                            params.cThresh = .005;
                            params.maxCItt = 3;
                            params.svmName = sprintf('LF-%s-G%.4f%s',svmNameBase,autogamma*gamma,strrep(params.options,' ','_'));
                            if(autogamma == 0)
                                if(isfield(params,'RFP'))
                                    params = rmfield(params,'RFP');
                                end
                                params.svmName = sprintf('LF-%s-G%.4f%s',[svmNameBase(1:end-12) '-' params.normType],autogamma*gamma,strrep(params.options,' ','_'));
                            else
                                params.RFP = RFP/autogamma;
                            end

                            params.svmName = [params.svmName '-C' num2str(params.C)];
                            if(mtcls) 
                                params.svmName = [params.svmName '-multicls'];
                            end
                            busyFile = fullfile(TestFold,svmFold,['busy2-' params.svmName '.mat']);
                            if(exist(busyFile,'file'))
                                continue;
                            end
                            try
                                save(busyFile,'busyFile');

                                %{-
                                %with doing validation on test set
                                saveFile = fullfile(TestFold,svmFold,[params.svmName '.mat']);
                                clear rates;
                                if(~exist(saveFile,'file'))
                                    %continue;
                                    if(mtcls)
                                            svm = MySVMTrain(fe,leo,params);%,testFeats,testLabels);
                                    else
                                            svm = MySVMTrain(fe,le,params);%,testFeats,testLabels);
                                    end
                                    save(saveFile,'svm');
                                else
                                    load(saveFile);
                                end
                                fprintf('Testing %s\n',params.svmName);
                                if(true)%~exist('rates','var'))
                                    [rates, pl, predictor] = MySVMTestInMem(testFeats,testLabels,svm,1024^3);
                                    multiRates = [0 0];
                                    if(mtcls)
                                        pml = predictor>0;
                                        multiRates(1) = sum(testlabelsOvLp(:)==pml(:))./numel(pml);
                                        multiRates(2) = (sum(testlabelsOvLp(~testlabelsOvLp(:))==pml(~testlabelsOvLp(:)))./sum(~testlabelsOvLp(:))+sum(testlabelsOvLp(testlabelsOvLp(:))==pml(testlabelsOvLp(:)))./sum(testlabelsOvLp(:)))/2;
                                    end
                                    save(saveFile,'svm','rates','multiRates');
                                end
                                prates = rates(:,1)./rates(:,2);
                                fprintf(fid,'%s\t',params.svmName);fprintf(fid,'%f\t',[svm.params.C ratioH ratioE 1-ratioH-ratioHD-ratioE multiRates sum(prates(1:2))]);fprintf(fid,'%.3f\t',prates);fprintf(fid,'\n');
                                %}

                                %cross validation
                                %{
                                params.svmName = [params.svmName 'c3'];
                                params.cvSize = 5;
                                saveFile = fullfile(TestFold,svmFold,[params.svmName '.mat']);
                                make_dir(saveFile);
                                clear rates;
                                if(~exist(saveFile,'file'))
                                    svm = MySVMTrain(fe,le,params);
                                    save(saveFile,'svm');
                                else
                                    load(saveFile);
                                end
                                fprintf('Testing %s\n',params.svmName);
                                if(~exist('rates','var'))
                                    [rates] = MySVMTest(testFeats,testLabels,svm);
                                    save(saveFile,'svm','rates');
                                end
                                prates = rates(:,1)./rates(:,2);
                                fprintf(fid,'%s\t',params.svmName);fprintf(fid,'%f\t',[svm.params.C ratioH ratioE 1-ratioH-ratioHD-ratioE sum(prates(1:2))]);fprintf(fid,'%.3f\t',prates);fprintf(fid,'\n');
                                %}
                                delete(busyFile);
                            catch err
                                delete(busyFile);
                                throw(err);
                            end
                        end
                    end
                end
            end
            end
        end
        %}
        
        %{
        for gamma = [1./(66*2.^(0:2)) 2.^(0:5)]
            for C = 1
            clear params;
            params.trainFun = @svmtrain;
            params.testFun = @svmpredict;
            params.kernel = 3;
            params.gamma = gamma;
            params.options = '-h 0';
            params.normType = 'std';
            params.cvSize = 1;
            params.cvTarget = 'avgPerClass';
            params.C = C;
            params.rmDim = [];%1:33;
            params.names = names;
            params.svmName = sprintf('RBF-SS%dk-RH%.2f-RE%.2f-G%.3f-C%.3f-%s',ss/1000,ratioH,ratioE,gamma,params.C,params.normType);

            saveFile = fullfile(TestFold,svmFold,[params.svmName '.mat']);
            make_dir(saveFile);
            clear rates;

            fprintf('Training %s\n',params.svmName);
            if(~exist(saveFile,'file'))
                svm = MySVMTrain(fe,le, params);
                save(saveFile,'svm');
            else
                load(saveFile);
            end
            fprintf('Testing %s\n',params.svmName);
            %{-
            if(~exist('rates','var'))
                [rates] = MySVMTest(testFeats,testLabels,svm);
                save(saveFile,'svm','rates');
            end
            prates = rates(:,1)./rates(:,2);
            fprintf(fid,'%s\t',params.svmName);fprintf(fid,'%.2f\t',[ratioH ratioHD ratioE 1-ratioH-ratioHD-ratioE sum(prates(1:2))]);fprintf(fid,'%.3f\t',prates);fprintf(fid,'\n');
            end
        end
        %}
        
        
        
    end
    %ProgressBar(pfig,find(ss == ssrange),length(ssrange));
end
%close(pfig);
