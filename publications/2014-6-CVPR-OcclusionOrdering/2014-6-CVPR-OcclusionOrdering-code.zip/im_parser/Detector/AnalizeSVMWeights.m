HOME = '~/CS/im_parser/LMSun';
HOME = 'D:\im_parser\LMSun';
HOME = '~/CS/im_parser/siftFlowDetector';
HOME = 'D:\im_parser\siftFlowDetector';

HOMEIMAGES = fullfile(HOME,'Images');
HOMEANNOTATIONS = fullfile(HOME,'Annotations');
HOMELABELSETS = {fullfile(HOME,'LabelsSemantic')};
HOMEDATA = fullfile(HOME,'Data');
HOMEDESCRIPTOR = fullfile(HOMEDATA,'Descriptors');


DataFold = fullfile(HOMEDATA,'RunOnTraining');
TestFold = fullfile(HOMEDATA,'Detector4Bin');
%TestFold = fullfile(HOMEDATA,'DetectorCalibrated');
%TestFold = fullfile(HOMEDATA,'DetectorPreTrained');

detectorFold = 'Model360-MM0100-R200-NMS0';
parserFold = 'probPerLabelR200K200TNN80-SPscGistCoHist-sc01ratio';
%detectorFold = 'Model1280-MM0100-R800-NMS0';
%parserFold = 'probPerLabelR800K200TNN80-SPscGistCoHist-sc01ratio';
spFold = 'SP_Desc_k200';
[foo LabelSetFold] = fileparts(HOMELABELSETS{1});
testSVMList = {'LinearF-SS80k-RH0.13-RHD0.13-RE0.25'};%{'LinearF-SS1280k-RH0.13-RHD0.13-RE0.25','LinearF-SS1280k-RH0.00-RHD0.00-RE0.33'};
svms = cell(size(testSVMList));

detFiles = dir_recurse(fullfile(TestFold,LabelSetFold,parserFold,'*'),0);
[fold base] = fileparts(detFiles{1});
load(fullfile(HOMELABELSETS{1},fold,[base '.mat'])); %S (ro x co) names
close all;
MyCleanUp;
for i = 1:length(svms)
    saveFile = fullfile(TestFold,'SVMs',[testSVMList{i} '.mat']);
    load(saveFile);
    fid = fopen(fullfile(TestFold,'SVMs',['SVMWeights-' testSVMList{i} '.txt']),'w');
    fprintf(fid,'\t');
    for j = 1:length(names);fprintf(fid,'%s\t',names{j});end
    for j = 1:length(names);fprintf(fid,'%s\t',names{j});end
    fprintf(fid,'\n');
    for j = 1:length(svm.model)
        fprintf(fid,'%s\t',names{svm.params.labelList(j)});
        fprintf(fid,'%f\t',svm.model{j}.w.*svm.model{j}.Label(1));
        fprintf(fid,'\n');
    end
    fclose(fid);
end
