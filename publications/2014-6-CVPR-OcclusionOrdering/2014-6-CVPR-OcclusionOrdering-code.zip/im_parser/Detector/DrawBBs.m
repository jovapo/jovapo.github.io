function DrawBBs(bbs,color)

for k = 1:size(bbs,1)
    if(bbs(k,3)-bbs(k,1) <=0 || bbs(k,4)-bbs(k,2) <= 0)
        continue;
    end
    rectangle( 'Position',[bbs(k,1) bbs(k,2) bbs(k,3)-bbs(k,1) bbs(k,4)-bbs(k,2)],'LineWidth',2,'EdgeColor',color);%colors(j));%
end