SetUpConstants;
if(false)%isempty(testSVMList))
    foldList = dir(fullfile(TestFold,svmFold,'*.mat'));
    for i = 1:length(foldList)
        if(~foldList(i).isdir)
            [a testSVMList{end+1}] = fileparts(foldList(i).name);
        end
    end
end

[foo LabelSetFold] = fileparts(HOMELABELSETS{1});

dataFile = fullfile(TestFold,'parsingData.mat');

[fold base] = fileparts(testFileList{1});
load(fullfile(HOMELABELSETS{1},fold,[base '.mat'])); %S (ro x co) names
Labels = cell(1);Labels{1} = names;

%{-
predictedLabels = cell(size(testSVMList));
gtLabels = cell(size(testFileList));
close all;
pfig = ProgressBar('Loading SVM test data');
for f = rangeTest(:)';
    [fold base] = fileparts(testFileList{f});
    %{
    busyFile = fullfile(TestFold,testParams.MRFFold,'BusyFiles',fold,[base '.mat']);make_dir(busyFile);
    if(exist(busyFile,'file'))
        fprintf('Busy %d: %s/%s\n',f,fold,base);
        continue;
    end
    a = 1; save(busyFile,'a');
    %}
    timingFile = fullfile(TestFold,'Timing',fold,[base '.mat']);make_dir(timingFile);
    if(exist(timingFile,'file'))
        load(timingFile);
    else
        fileStats = [];
    end
    
    fprintf('Working on %d: %s/%s\n',f,fold,base);
    try
        load(fullfile(TestFold,'ExemplarDataTerm',detectorFold,fold,[base '.mat'])); %dataTerm (ro x co x #l) dataTermMax
        if(exist('secondDataterm','var') && ~isempty(secondDataterm))
            a = load(fullfile(TestFold,secondDataterm,detectorFold,fold,[base '.mat']));
            dataTerm2 = a.dataTerm;
        end
        a = load(fullfile(TestFold,LabelSetFold,parserFold,fold,[base '.mat'])); %probPerLabel (#SP x #l)
        if(isfield(a,'probPerLabel'))
            probPerLabel = a.probPerLabel;
        elseif(isfield(a,'prob'))
            probPerLabel = a.prob;
        end
        load(fullfile(HOMEDATA,'Descriptors',spFold,'super_pixels',fold,[base '.mat'])); %superPixels (ro x co)
        %load(fullfile(HOMEDATA,'Descriptors',spFold,'sp_adjacency',fold,[base '.mat'])); %adjPairs (pairs x 2)
        load(fullfile(HOMELABELSETS{1},fold,[base '.mat'])); %S (ro x co) names
        clear im;
        try
            im = imread(fullfile(HOMEIMAGES,testFileList{f}));
        catch
            im = imread(fullfile(HOMEIMAGES,fold,[base '.jpg']));
        end
    catch
        continue;
    end
    uSP = unique(superPixels);
    spMap = zeros(max(uSP),1);
    spMap(uSP) = 1:length(uSP);
    if(exist('secondDataterm','var') && ~isempty(secondDataterm))
        feat = [probPerLabel(spMap(superPixels),:) reshape(dataTerm,[],size(dataTerm,3)) reshape(dataTerm2,[],size(dataTerm2,3))];
    else
        feat = [probPerLabel(spMap(superPixels),:) reshape(dataTerm,[],size(dataTerm,3))];
    end
                    
    clear dataTerm;
    featSP = zeros(length(uSP),size(feat,2));
    for i = 1:length(uSP)
        featSP(i,:) = mean(feat(superPixels==uSP(i),:));
    end
    label = S(:);
    %feat(label==0,:) = [];
    labelAll = label;
    label(label==0) = [];
    gtLabels{f} = label;
    labelList = names;
    numLs = length(names);    
    saveFile = fullfile(TestFold,testParams.MRFFold,LabelSetFold,'SuperParsing',fold,[base '.mat']);make_dir(saveFile);
    if(~exist(saveFile,'file'))
        [maxFeats pl] = max(feat(:,1:numLs),[],2);
        L = reshape(pl,size(superPixels));
        OutputLabeling(saveFile,L,labelList,S,names);
    end

    if(exist('secondDataterm','var') && ~isempty(secondDataterm))
        saveFile = fullfile(TestFold,testParams.MRFFold,LabelSetFold,['Detector' detectorFold],fold,[base '.mat']);make_dir(saveFile);
        if(1)%~exist(saveFile,'file'))
            [maxFeats pl] = max(feat(:,1+numLs:numLs*2),[],2);
            L = reshape(pl,size(superPixels));
            OutputLabeling(saveFile,L,labelList,S,names);
        end
        saveFile = fullfile(TestFold,testParams.MRFFold,LabelSetFold,['Detector2' detectorFold],fold,[base '.mat']);make_dir(saveFile);
        if(1)%~exist(saveFile,'file'))
            [maxFeats pl] = max(feat(:,1+numLs*2:end),[],2);
            L = reshape(pl,size(superPixels));
            OutputLabeling(saveFile,L,labelList,S,names);
        end
    else
        saveFile = fullfile(TestFold,testParams.MRFFold,LabelSetFold,['Detector' detectorFold],fold,[base '.mat']);make_dir(saveFile);
        if(~exist(saveFile,'file'))
            [maxFeats pl] = max(feat(:,1+numLs:end),[],2);
            L = reshape(pl,size(superPixels));
            OutputLabeling(saveFile,L,labelList,S,names);
        end
    end
    
    
    
    
    %{-
    for i = 1:length(testSVMList)
        
        saveFile = fullfile(TestFold,testParams.MRFFold,LabelSetFold,testSVMList{i},fold,[base '.mat']);make_dir(saveFile);
        %saveFileSP = fullfile(TestFold,testParams.MRFFold,LabelSetFold,[testSVMList{i} '-SP'],fold,[base '.mat']);make_dir(saveFileSP);
        pFile = fullfile(TestFold,svmFold,testSVMList{i},'Predictors',fold,[base '.mat']);
        loaded = false;
        %{
        if(exist(pFile,'file'))
            try
                load(pFile);
                loaded=true;
            catch
                delete(pFile);
            end
        end
        %}
        if(~loaded)
            svmFile = fullfile(TestFold,svmFold,[testSVMList{i} '.mat']);
            if(exist(svmFile,'file'))
                s = load(svmFile);
                timerVar=tic;[rates, pl, predictors] = MySVMTestInMem(feat,labelAll,s.svm,1024^3);timerVar=toc(timerVar);
                fileStats.(['timeSVM' num2str(i)]) = timerVar;
                save(timingFile,'fileStats');
                %[ratesSP, plSP, predictorsSP] = MySVMTestInMem(featSP,labelAll(1:size(featSP,1)),s.svm,1024^3);
            else
                svmFiles = dir_recurse(fullfile(TestFold,svmFold,testSVMList{i},'*.mat'));
                if(length(svmFiles)<length(names))
                    continue;
                end
                s = load(svmFiles{1});
                predictors = -10000*ones(size(feat,1),length(names));
                for sf = 1:length(svmFiles)
                    s = load(svmFiles{sf});
                    [rates, pl, p] = MySVMTestInMem(feat,labelAll,s.svm,(1024^3)/4);
                    predictors(:,s.svm.params.labelList) = p(:,s.svm.params.labelList);
                end
                [a pl] = max(predictor,[],2);
            end
            L = reshape(pl,size(superPixels));
            OutputLabeling(saveFile,L,labelList,S,names);
            %L = plSP(superPixels);
            %OutputLabeling(saveFileSP,L,labelList,S,names);
            %make_dir(pFile);save(pFile,'predictors');
        end
        %clear feat;
        SmoothDetectorSVM;
        %InferWithFBandColor;
        %InferWithSingleSkeletalLabels;
        %EvaluateFGfromDCRF;
        clear predictors;
        %{
        [~, predIndex] = intersect(s.svm.params.labelList,gtLs);
        predMask = ones(size(predictors,2),1)==1;
        predMask(predIndex) = false;
        predictors(:,predMask) = min(predictors(:));
        [a pl] = max(predictors,[],2);
        pl = s.svm.params.labelList(pl);
        L = reshape(pl,size(superPixels));
        tmp = testSVMList{i};
        testSVMList{i} = ['shortlist-' testSVMList{i}];
        saveFile = fullfile(TestFold,testParams.MRFFold,LabelSetFold,testSVMList{i},fold,[base '.mat']);make_dir(saveFile);
        OutputLabeling(saveFile,L,labelList,S,names);
        SmoothDetectorSVM;
        testSVMList{i} = tmp;
        %}
        %SmoothDetectorSVMSP;
        %predictedLabels{i}{f} = pl;
    end
    %}
    ProgressBar(pfig,f,length(testFileList));
end
close(pfig);
%}

