DataFold = fullfile(HOMEDATA,'RunOnTraining');
%TestFold = fullfile(HOMEDATA,'Detector4Bin');
TestFold = fullfile(HOMEDATA,'DetectorPreTrained');

parserFold = {'probPerLabelR200K0TNN80-SPscGistCoHist-sc01ratio','probPerLabelR800K0TNN80-SPscGistCoHist-sc01ratio',    'probPerLabelR200K200TNN80-SPscGistCoHist-sc01ratio','probPerLabelR800K200TNN80-SPscGistCoHist-sc01ratio'};
spFold = {'SP_Desc_k0_vidSeg','SP_Desc_k0_vidSeg','SP_Desc_k200','SP_Desc_k200'};
[foo LabelSetFold] = fileparts(HOMELABELSETS{1});
%{
detFiles = dir_recurse(fullfile(DataFold,LabelSetFold,parserFold{1},'*'),0);
dataFile = fullfile(DataFold,'parsingData.mat');
if(exist(dataFile,'file'))
    load(dataFile);
else
    subSample = 11;
    clear allAllData;
    for i = 1:length(parserFold)
        clear allData;
        pfig = ProgressBar('Loading SVM training Data');
        for f = 1:length(detFiles)
            [fold base] = fileparts(detFiles{f});
            try
                load(fullfile(DataFold,LabelSetFold,parserFold{i},fold,[base '.mat'])); %probPerLabel (#SP x #l)
                load(fullfile(HOMEDATA,'Descriptors',spFold{i},'super_pixels',fold,[base '.mat'])); %superPixels (ro x co)
                load(fullfile(HOMELABELSETS{1},fold,[base '.mat'])); %S (ro x co) names
            catch
                continue;
            end
            uSP = unique(superPixels);
            spMap = zeros(max(uSP),1);
            spMap(uSP) = 1:length(uSP);
            feat = probPerLabel(spMap(superPixels),:);
            label = S(:);
            feat(label==0,:) = [];
            label(label==0) = [];
            feat = feat(1:subSample:end,:);
            label = label(1:subSample:end);
            allData(f).feats = feat;
            allData(f).labels = uint8(label);
            if(mod(f,10)==0)
                ProgressBar(pfig,f,length(detFiles));
            end
        end
        close(pfig);
        allAllData{i} = allData;
    end
    save(dataFile,'allAllData','-v7.3');
end
clear feats labels;
for i = 1:length(parserFold)
    allData = allAllData{i};
    feats{i} = vertcat(allData.feats);
    labels{i} = vertcat(allData.labels);
end
clear allData;
clear allAllData;
%}

%{
detFiles = dir_recurse(fullfile(TestFold,LabelSetFold,parserFold{1},'*'),0);
dataFile = fullfile(TestFold,'parsingData.mat');
if(exist(dataFile,'file'))
    load(dataFile);
else
    subSample = 5;
    clear allAllData;
    for i = 1:length(parserFold)
        clear allData;
        pfig = ProgressBar('Loading SVM training Data');
        for f = 1:length(detFiles)
            [fold base] = fileparts(detFiles{f});
            try
                load(fullfile(TestFold,LabelSetFold,parserFold{i},fold,[base '.mat'])); %probPerLabel (#SP x #l)
                load(fullfile(HOMEDATA,'Descriptors',spFold{i},'super_pixels',fold,[base '.mat'])); %superPixels (ro x co)
                load(fullfile(HOMELABELSETS{1},fold,[base '.mat'])); %S (ro x co) names
            catch
                continue;
            end
            uSP = unique(superPixels);
            spMap = zeros(max(uSP),1);
            spMap(uSP) = 1:length(uSP);
            feat = probPerLabel(spMap(superPixels),:);
            label = S(:);
            feat(label==0,:) = [];
            label(label==0) = [];
            feat = feat(1:subSample:end,:);
            label = label(1:subSample:end);
            allData(f).feats = feat;
            allData(f).labels = uint8(label);
            if(mod(f,10)==0)
                ProgressBar(pfig,f,length(detFiles));
            end
        end
        close(pfig);
        allAllData{i} = allData;
    end
    save(dataFile,'allAllData','-v7.3');
end
clear testFeats testLabels;
for i = 1:length(parserFold)
    allData = allAllData{i};
    testFeats{i} = vertcat(allData.feats);
    testLabels{i} = vertcat(allData.labels);
end
clear allData;
clear allAllData;
%}

numLs = length(names);

close all;
MyCleanUp;
fid = fopen(fullfile(DataFold,'resultsParsing.txt'),'w');
fprintf(fid,'SVM Name\tPer-pixel\tPer-class\t');
fprintf(fid,'%s\t',names{:});
fprintf(fid,'\n');
[a b] = UniqueAndCounts(labels{1});
fprintf(fid,'Training Set Counts\t\t\t');
fprintf(fid,'%d\t',b);
fprintf(fid,'\n');

%{0
for i = 1:length(parserFold)
    [maxFeats MaxL] = max(feats{i},[],2);
    rates = MySVMRates(MaxL,labels{i});
    fprintf(fid,'Training %s\t',parserFold{i});fprintf(fid,'%.3f\t',rates(:,1)./rates(:,2));fprintf(fid,'\n');
    
    [maxFeats MaxL] = max(testFeats{i},[],2);
    rates = MySVMRates(MaxL,testLabels{i});
    fprintf(fid,'Testing %s\t',parserFold{i});fprintf(fid,'%.3f\t',rates(:,1)./rates(:,2));fprintf(fid,'\n');
end
fclose(fid);