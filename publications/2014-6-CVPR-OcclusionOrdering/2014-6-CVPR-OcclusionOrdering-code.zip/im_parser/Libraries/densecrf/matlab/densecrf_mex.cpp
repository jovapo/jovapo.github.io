#include <mex.h>
#include "densecrf.h"
#include "permutohedral.h"
#include "utilal.h"
#include <cstdio>
#include <cmath>
#include <stdio.h>
#include <map>
#include <string>


#if !defined(MX_API_VER) || MX_API_VER < 0x07030000
typedef int mwSize;
typedef int mwIndex;
#endif

extern "C" mxArray *mxCreateReference(const mxArray*); // undocumented mex function

#define DCRF_EXPORT(func) \
	extern "C" void func(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]); \
	FuncRegistry::Entry regentry_##func(#func,func); \
	extern "C" void func(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])

#define MATLAB_ASSERT(expr,msg) if (!(expr)) { throw MatlabError(msg); }
#define MATLAB_ASSERT_ARGCOUNT(nout, nin) \
	MATLAB_ASSERT(nlhs >= nout, "Not enough output arguments, expected " #nout); \
	MATLAB_ASSERT(nlhs <= nout, "Too many output arguments, expected " #nout); \
	MATLAB_ASSERT(nrhs >= nin,  "Not enough input arguments, expected " #nin); \
	MATLAB_ASSERT(nrhs <= nin,  "Too many input arguments, expected " #nin);
#define MATLAB_ASSERT_INTYPE(arg, type) \
	MATLAB_ASSERT(mxGetClassID(prhs[arg]) == type, "Expected " #type " for input argument " #arg);
#define MATLAB_ASSERT_HANDLE(arg) \
	MATLAB_ASSERT(mxGetClassID(prhs[arg]) == mxINT32_CLASS, "Expected valid handle for argument " #arg);

struct MatlabError {
	MatlabError(const char* msg): msg(msg) { }
	const char* msg;
};

class PottsPotential: public PairwisePotential{
protected:
	Permutohedral lattice_;
	PottsPotential( const PottsPotential &o ){}
	int N_;
	float w_;
	float *norm_;
public:
	~PottsPotential(){
		deallocate( norm_ );
	}
	PottsPotential(const float* features, int D, int N, float w, bool per_pixel_normalization=true) :N_(N), w_(w) {
		lattice_.init( features, D, N );
		norm_ = allocate( N );
		for ( int i=0; i<N; i++ )
			norm_[i] = 1;
		// Compute the normalization factor
		lattice_.compute( norm_, norm_, 1 );
		if ( per_pixel_normalization ) {
			// use a per pixel normalization
			for ( int i=0; i<N; i++ )
				norm_[i] = 1.0 / (norm_[i]+1e-20);;
		}
		else {
			float mean_norm = 0;
			for ( int i=0; i<N; i++ )
				mean_norm += norm_[i];
			mean_norm = N / mean_norm;
			// use a per pixel normalization
			for ( int i=0; i<N; i++ )
				norm_[i] = mean_norm;
		}
	}
	void apply(float* out_values, const float* in_values, float* tmp, int value_size) const {
		lattice_.compute( tmp, in_values, value_size );
		for ( int i=0,k=0; i<N_; i++ )
			for ( int j=0; j<value_size; j++, k++ )
				out_values[k] += w_*norm_[i]*tmp[k];
	}
};


struct FuncRegistry {
	typedef void (*Func)(int, mxArray*[], int, const mxArray*[]);
	typedef std::map<std::string,Func> LookupTable;
	static LookupTable sLookup;
	struct Entry {
		Entry(const char* name, Func ptr) { sLookup[name] = ptr; }
	};
};
FuncRegistry::LookupTable FuncRegistry::sLookup;


struct GCInstanceInfo {
	GCInstanceInfo(): crf(0){ }
	~GCInstanceInfo() {
		if (crf) delete crf;
	}
	DenseCRF* crf;
private:
};

typedef int LabelID;
typedef int SiteID;
typedef float EnergyTermType;
mxClassID cLabelClassID      = sizeof(LabelID)        == 8 ? mxINT64_CLASS : mxINT32_CLASS;
mxClassID cSiteClassID       = sizeof(SiteID)         == 8 ? mxINT64_CLASS : mxINT32_CLASS;
mxClassID cEnergyTermClassID = sizeof(EnergyTermType) == 8 ? mxDOUBLE_CLASS : mxSINGLE_CLASS;

typedef std::map<int,GCInstanceInfo> GCInstanceMap;

static int gNextInstanceID = 10001; // some start id for the first GC object
static GCInstanceMap gInstanceMap;

GCInstanceMap::mapped_type& sGetGCInstance(int id) {
	GCInstanceMap::iterator it = gInstanceMap.find(id);
	MATLAB_ASSERT(it != gInstanceMap.end(), "Invalid handle; no such GCoptimization object");
	return it->second;
}

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
	if (nrhs == 0 || !mxIsChar(prhs[0]))
		mexErrMsgTxt("Do not use dcrf_matlab() directly, instead use the GCO functions such as DCRF_Create"); 
	mwSize nameLen = mxGetN(prhs[0])*sizeof(mxChar)+1;
	char funcName[512];
	mxGetString(prhs[0], funcName, nameLen); 
	FuncRegistry::LookupTable::const_iterator it = FuncRegistry::sLookup.find(funcName);
	if (it == FuncRegistry::sLookup.end())
		mexErrMsgTxt("Specified function does not exist within dcrf_matlab module"); 
	try {
		it->second(nlhs, plhs, nrhs-1, prhs+1);
	} catch (MatlabError err) {
		mexErrMsgTxt(err.msg);
	}
}


DCRF_EXPORT(dcrf_create_general)
{
	int instanceID = 0;
	try {
		MATLAB_ASSERT_ARGCOUNT(1,2);
		MATLAB_ASSERT_INTYPE(0,cSiteClassID);
		MATLAB_ASSERT_INTYPE(1,cLabelClassID);
		SiteID  numSites  = *(SiteID* )mxGetData(prhs[0]); MATLAB_ASSERT(numSites  >= 1, "Number of sites must be positive");
		LabelID numLabels = *(LabelID*)mxGetData(prhs[1]); MATLAB_ASSERT(numLabels >= 2, "Number of labels must be positive");
		instanceID = gNextInstanceID++;
		GCInstanceInfo& gcinstance = gInstanceMap[instanceID];
		gcinstance.crf = new DenseCRF(numSites, numLabels);
		mwSize outSize = 1;
		plhs[0] = mxCreateNumericArray(1, &outSize, mxINT32_CLASS, mxREAL);
		*(int*)mxGetData(plhs[0]) = instanceID;
	} catch (MatlabError) {
		if (instanceID) 
			gInstanceMap.erase(instanceID);
		throw;
	}
}

DCRF_EXPORT(dcrf_delete)
{
	MATLAB_ASSERT_HANDLE(0);
	const int* instanceIDs = (int*)mxGetData(prhs[0]);
	MATLAB_ASSERT(mxGetN(prhs[0]) == 1 || mxGetM(prhs[0]) == 1, "Input must be a scalar or a vector");
	mwIndex count = mxGetNumberOfElements(prhs[0]);
	for (mwIndex i = 0; i < count; ++i) {
		MATLAB_ASSERT(gInstanceMap.find(instanceIDs[i]) != gInstanceMap.end(), "Invalid handle (no such GCoptimization object)");
		gInstanceMap.erase(instanceIDs[i]);
	}
}

DCRF_EXPORT(dcrf_listhandles)
{
	MATLAB_ASSERT_ARGCOUNT(1,0);
	mwSize outSize = (mwSize)gInstanceMap.size();
	plhs[0] = mxCreateNumericArray(1, &outSize, mxINT32_CLASS, mxREAL);
	int* instanceIDs = (int*)mxGetData(plhs[0]);
	for (GCInstanceMap::const_iterator i = gInstanceMap.begin(); i != gInstanceMap.end(); ++i)
		*(instanceIDs++) = i->first;
}


DCRF_EXPORT(dcrf_setunary)
{
	MATLAB_ASSERT_ARGCOUNT(0,2);
	MATLAB_ASSERT_HANDLE(0);
	MATLAB_ASSERT_INTYPE(1,cEnergyTermClassID);
	GCInstanceInfo& gcinstance = sGetGCInstance(*(int*)mxGetData(prhs[0]));
	const mxArray* dc = prhs[1];
	// Dense data costs
	MATLAB_ASSERT(mxGetN(dc) == gcinstance.crf->numSites() && mxGetM(dc) == gcinstance.crf->numLabels(), "Numeric data cost must be NumLabels x NumSites in size");
	gcinstance.crf->setUnaryEnergy( (EnergyTermType*)mxGetData(dc) );
}

DCRF_EXPORT(dcrf_addpairwiseenergy)
{
	MATLAB_ASSERT_ARGCOUNT(0,4);
	MATLAB_ASSERT_HANDLE(0);
	MATLAB_ASSERT_INTYPE(1,cEnergyTermClassID);
	GCInstanceInfo& gcinstance = sGetGCInstance(*(int*)mxGetData(prhs[0]));
	const mxArray* feats = prhs[1];
	// Smooth costs provided as numeric array, and is applied to all neighbouring variables.
	MATLAB_ASSERT(mxGetN(feats) == gcinstance.crf->numSites(),"Features must be DxN where N is number of sites");
	bool pixelNorm = *(bool*)mxGetData(prhs[3]);
	gcinstance.crf->addPairwiseEnergy( new PottsPotential( (EnergyTermType*)mxGetData(feats), mxGetM(feats), gcinstance.crf->numSites(), *(EnergyTermType*)mxGetData(prhs[2]), pixelNorm ) );
}


DCRF_EXPORT(dcrf_map)
{
	MATLAB_ASSERT_ARGCOUNT(1,2);
	MATLAB_ASSERT_HANDLE(0);
	MATLAB_ASSERT_INTYPE(1,mxINT32_CLASS);
	GCInstanceInfo& gcinstance = sGetGCInstance(*(int*)mxGetData(prhs[0]));
	int maxIter = *(int*)mxGetData(prhs[1]);
	mwSize outdim = gcinstance.crf->numSites();
	plhs[0] = mxCreateNumericArray(1, &outdim, mxINT16_CLASS, mxREAL);
	gcinstance.crf->map(maxIter, (short*)mxGetData(plhs[0]) );
}

DCRF_EXPORT(dcrf_inference)
{
	MATLAB_ASSERT_ARGCOUNT(1,2);
	MATLAB_ASSERT_HANDLE(0);
	MATLAB_ASSERT_INTYPE(1,mxINT32_CLASS);
	GCInstanceInfo& gcinstance = sGetGCInstance(*(int*)mxGetData(prhs[0]));
	int maxIter = *(int*)mxGetData(prhs[1]);
	mwSize outdim = gcinstance.crf->numSites()*gcinstance.crf->numLabels();
	plhs[0] = mxCreateNumericArray(1, &outdim, mxSINGLE_CLASS, mxREAL);
	gcinstance.crf->inference(maxIter, (float*)mxGetData(plhs[0]) );
}