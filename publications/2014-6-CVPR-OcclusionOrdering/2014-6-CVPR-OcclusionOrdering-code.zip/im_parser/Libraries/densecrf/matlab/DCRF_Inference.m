function [ result ] = DCRF_Inference(handle, itterations )
%DCRF_MAP Summary of this function goes here
%   Detailed explanation goes here

result = densecrf_mex('dcrf_inference',handle,int32(itterations));

end

