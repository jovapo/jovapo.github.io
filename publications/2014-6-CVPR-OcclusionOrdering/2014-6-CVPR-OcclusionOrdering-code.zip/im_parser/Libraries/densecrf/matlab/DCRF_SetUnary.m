function DCRF_SetUnary( handle, unary )
%DCRF_SETUNARY Summary of this function goes here
%   Detailed explanation goes here
densecrf_mex('dcrf_setunary',handle,single(unary));
end

