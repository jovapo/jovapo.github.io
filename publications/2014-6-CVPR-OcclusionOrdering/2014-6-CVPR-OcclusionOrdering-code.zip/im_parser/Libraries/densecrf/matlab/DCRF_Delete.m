function DCRF_Delete( handle )
%DCRV_DELETE Summary of this function goes here
%   Detailed explanation goes here

densecrf_mex('dcrf_delete',int32(handle));
end

