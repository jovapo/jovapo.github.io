function DCRF_AddPairwiseBilateral( handle, im, dist_std, co_std, weight,pixelNorm, mask )
%DCRF_ADDPAIRWISEBILATERAL Summary of this function goes here
%   Detailed explanation goes here
imSize = size(im);
[X,Y] = meshgrid(1:imSize(2),1:imSize(1));
X = X-1;
Y = Y-1;

feat = [X(:)./dist_std Y(:)./dist_std reshape(double(im),[imSize(1)*imSize(2) imSize(3)])./co_std]';
if(exist('mask','var'))
    feat = feat(:,mask);
end

DCRF_AddPairwiseEnergy(handle,feat,weight,pixelNorm)
end

