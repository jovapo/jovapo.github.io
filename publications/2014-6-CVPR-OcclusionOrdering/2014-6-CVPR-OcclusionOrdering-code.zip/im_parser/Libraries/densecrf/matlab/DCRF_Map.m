function [ map ] = DCRF_Map(handle, itterations )
%DCRF_MAP Summary of this function goes here
%   Detailed explanation goes here

map = densecrf_mex('dcrf_map',handle,int32(itterations));

end

