function [ handle ] = DCRF_CreateCRF( numSites, numLabels )
%CREATECRF Summary of this function goes here
%   Detailed explanation goes here
handle = densecrf_mex('dcrf_create_general',int32(numSites),int32(numLabels));
end

