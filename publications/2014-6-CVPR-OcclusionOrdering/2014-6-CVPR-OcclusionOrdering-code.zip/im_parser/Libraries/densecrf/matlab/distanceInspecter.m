function varargout = distanceInspecter(varargin)
% DISTANCEINSPECTER MATLAB code for distanceInspecter.fig
%      DISTANCEINSPECTER, by itself, creates a new DISTANCEINSPECTER or raises the existing
%      singleton*.
%
%      H = DISTANCEINSPECTER returns the handle to a new DISTANCEINSPECTER or the handle to
%      the existing singleton*.
%
%      DISTANCEINSPECTER('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in DISTANCEINSPECTER.M with the given input arguments.
%
%      DISTANCEINSPECTER('Property','Value',...) creates a new DISTANCEINSPECTER or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before distanceInspecter_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to distanceInspecter_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help distanceInspecter

% Last Modified by GUIDE v2.5 06-Jun-2013 16:51:50

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @distanceInspecter_OpeningFcn, ...
                   'gui_OutputFcn',  @distanceInspecter_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before distanceInspecter is made visible.
function distanceInspecter_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to distanceInspecter (see VARARGIN)

% Choose default command line output for distanceInspecter
handles.output = hObject;
handles.s1 = 0;
handles.s2 = 0;
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes distanceInspecter wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = distanceInspecter_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on slider movement.
function slider1_Callback(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.s1 = get(hObject,'Value');
set(handles.text1,'String',num2str(handles.s1));
handles.feat = UpdateFeature(handles);
guidata(hObject, handles);
UpdateAxes(handles)
% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function slider2_Callback(hObject, eventdata, handles)
% hObject    handle to slider2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.s2 = get(hObject,'Value');
set(handles.text2,'String',num2str(handles.s2));
handles.feat = UpdateFeature(handles);
guidata(hObject, handles);
UpdateAxes(handles)
% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on button press in pushbuttonprocess.
function pushbuttonprocess_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonprocess (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.feat = UpdateFeature(handles);
guidata(hObject, handles);
UpdateAxes(handles)

function feat = UpdateFeature(handles) 
    imSize = size(handles.im);
    [X,Y] = meshgrid(1:imSize(2),1:imSize(1));
    X = X-1;
    Y = Y-1;
    feat = [X(:)./handles.s1 Y(:)./handles.s1];% reshape(double(handles.im),[imSize(1)*imSize(2) imSize(3)])./handles.s2];
    borderSize = 0;
    impad = padarray(double(handles.im),[borderSize borderSize],'symmetric');
    for b1 = 1:(borderSize*2+1)
        for b2 = 1:(borderSize*2+1)
            feat = [feat reshape(impad(b1:b1-1+imSize(1),b2:b2-1+imSize(2),:),[imSize(1)*imSize(2) imSize(3)])./handles.s2];
        end
    end

function UpdateAxes(handles)
    imSize = size(handles.im);
    ind = sub2ind(imSize(1:2),handles.pt(1),handles.pt(2));
    dist = reshape(exp(-dist2(handles.feat,handles.feat(ind,:))/2),imSize(1:2));
    axes(handles.axes1);
    imagesc(dist);







% --- Executes on button press in pushbuttonopenfile.
function pushbuttonopenfile_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonopenfile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[filename, path] = uigetfile({'*.jpg;*.tif;*.png;*.gif;*.ppm','All Image Files';...
          '*.*','All Files' });
handles.im = imread(fullfile(path,filename));
handles.pt = round([size(handles.im,1)/2 size(handles.im,2)/2]);
axes(handles.axes1);
imshow(handles.im);
guidata(hObject, handles);


% --- Executes on button press in pushbuttonselectpoint.
function pushbuttonselectpoint_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonselectpoint (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of pushbuttonselectpoint
[x,y] = ginput(1);
handles.pt = round([y x]);
UpdateAxes(handles);
guidata(hObject, handles);
