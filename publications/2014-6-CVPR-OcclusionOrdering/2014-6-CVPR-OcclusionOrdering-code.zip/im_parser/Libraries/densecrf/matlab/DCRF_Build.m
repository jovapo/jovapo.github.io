MEXFLAGS = '-largeArrayDims -DA64BITS ';%-g ';%
CRFDMATDIR = fileparts(mfilename('fullpath'));
CRFDDIR = fileparts(CRFDMATDIR);
CRFDSRCDIR = fullfile(CRFDDIR,'src');
CRFDINCDIR = fullfile(CRFDDIR,'include');

mexcmd = ['mex ' MEXFLAGS ' -outdir ''' CRFDMATDIR ''' ' ];
SRCCPP = { 
    [CRFDMATDIR filesep 'densecrf_mex.cpp'],
    [CRFDSRCDIR filesep 'bipartitedensecrf.cpp'],
    [CRFDSRCDIR filesep 'densecrf.cpp'],
    [CRFDSRCDIR filesep 'filter.cpp'],
    [CRFDSRCDIR filesep 'permutohedral.cpp'],
    [CRFDSRCDIR filesep 'utilal.cpp']
    };
for f=1:length(SRCCPP)
    mexcmd = [mexcmd ' ''' SRCCPP{f} ''' '];
end
mexcmd = [mexcmd ' -I' CRFDINCDIR ' -I' CRFDSRCDIR ];
eval(mexcmd);  % compile and link in one step