function DCRF_Sample()

annIm = imread('examples/anno2.ppm');
im = imread('examples/im2.ppm');

%imshow(im);

L = GetLabels(annIm);
L(L>0) = L(L>0)+5;
unary = MakeUnary(L,21);
unary = reshape(unary,[size(unary,1)*size(unary,2) size(unary,3)]);

hs = densecrf_mex('dcrf_listhandles');
for i = 1:length(hs)
    DCRF_Delete(hs(i));
end
close all;
for w = 3
    for w2 = 10
        h = DCRF_CreateCRF(size(unary,1),size(unary,2));
        DCRF_SetUnary(h,unary');
        DCRF_AddPairwiseGaussian(h,size(L),3,3,w);
        DCRF_AddPairwiseBilateral(h,im,60,20,w2);
        map = DCRF_Map(h,20);
        figure;imagesc(reshape(map,size(L)));
        DCRF_Delete(h);
    end
end
end

function unary = MakeUnary(L,numL)
    ls = unique(L(L~=0));
    u_energy = -log( 1.0 / (numL) );
    n_energy = -log( (1.0 - .5) / (numL-1) );
    p_energy = -log( .5 );
    
    unary = zeros([size(L) max(ls)]);
    for l = 1:numL
        temp = ones(size(L))*n_energy;
        temp(L==l) = p_energy;
        temp(L==0) = u_energy;
        unary(:,:,l) = temp;
    end
end

function L = GetLabels(annIm)
annIm = uint32(annIm);
ann = annIm(:,:,1)+(annIm(:,:,2)*2^8)+(annIm(:,:,3)*2^16);
[val, ~, L] = unique(ann);
L = reshape(L,size(ann));
if(val(1) == 0)
    L = L -1;
end
end
