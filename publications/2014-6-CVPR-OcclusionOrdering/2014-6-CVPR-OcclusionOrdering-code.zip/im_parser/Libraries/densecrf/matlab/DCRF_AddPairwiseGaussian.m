function DCRF_AddPairwiseGaussian(handle, imSize, x_std, y_std, weight,pixelNorm, mask )
%DCRF_ADDPAIRWISEGAUSSIAN Summary of this function goes here
%   Detailed explanation goes here

[X,Y] = meshgrid(1:imSize(2),1:imSize(1));
X = X-1;
Y = Y-1;

feat = [X(:)./x_std Y(:)./y_std]';
if(exist('mask','var'))
    feat = feat(:,mask);
end

DCRF_AddPairwiseEnergy(handle,feat,weight,pixelNorm)
end

