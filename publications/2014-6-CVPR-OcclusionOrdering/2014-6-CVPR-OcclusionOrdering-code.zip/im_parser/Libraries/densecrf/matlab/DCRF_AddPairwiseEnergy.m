function DCRF_AddPairwiseEnergy(handle,feat,weight,pixelNorm)


densecrf_mex('dcrf_addpairwiseenergy',handle,single(feat),single(weight),pixelNorm>0);

end