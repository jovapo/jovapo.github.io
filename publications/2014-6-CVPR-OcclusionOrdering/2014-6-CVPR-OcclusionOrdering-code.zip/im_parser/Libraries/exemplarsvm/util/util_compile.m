% Compile partial sort function
mex -O psort.cpp
