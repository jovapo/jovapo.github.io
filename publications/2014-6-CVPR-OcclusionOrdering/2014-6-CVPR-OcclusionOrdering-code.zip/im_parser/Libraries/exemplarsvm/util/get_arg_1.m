function [a] = get_arg_1(fun)
[a] = fun();