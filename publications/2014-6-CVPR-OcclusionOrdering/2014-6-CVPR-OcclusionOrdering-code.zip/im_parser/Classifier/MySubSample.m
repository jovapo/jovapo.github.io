function [labels feats mask] = MySubSample(labels,feats,numPts2Sample,evenLabelDist,subsetinds,ll)

%if(nargout>=3)
    mask = zeros(size(labels),'uint8')==1;
%end

if(numPts2Sample == 0)
    labels = zeros(0,1);
    feats = zeros(0,size(feats,2));
    return;
end

numPts = length(labels);
if(evenLabelDist)
    if(~exist('ll','var'))
        ll = unique(labels);
    end
    ppl = ceil(numPts2Sample/length(ll));
    sampleNdx = cell(length(ll),1);
    if(length(labels)/numPts2Sample/100>1)
        subLabels1000 = labels(1000:1000:end);
        subLabels100 = labels(100:100:end);
        subLabels10 = labels(10:10:end);
    end 
    pfig = ProgressBar('Finding Inds');
    for i = 1:length(ll)
        if(length(labels)/numPts2Sample/100>1)
            posibleNdx = 1000*find(subLabels1000==ll(i));
            if(length(posibleNdx)<ppl)
                posibleNdx = 100*find(subLabels100==ll(i));
                if(length(posibleNdx)<ppl)
                    posibleNdx = 10*find(subLabels10==ll(i));
                    if(length(posibleNdx)<ppl)
                        posibleNdx = cell(10,1);
                        blocks = BlockRange( length(labels), 10 );
                        for j = 1:10
                            posibleNdx{j} = find(labels(blocks(j,1):blocks(j,2))==ll(i))+blocks(j,1)-1;
                        end
                        posibleNdx = cell2mat(posibleNdx);
                    end
                end
            end
        else
            posibleNdx = find(labels==ll(i));
        end
        ss = length(posibleNdx)/ppl;
        if(ss<1)
            ss = 1;
        end
        sampleNdx{i} = posibleNdx(floor(1:ss:end));
        ProgressBar(pfig,i,length(ll));
    end
    close(pfig);
    sampleNdx = sort(cell2mat(sampleNdx(:)));
    labels = labels(sampleNdx);
    feats = feats(sampleNdx,:);
    if(nargout>=3)
        mask(sampleNdx) = true;
    end
else
    if(exist('subsetinds','var') && ~isempty(subsetinds))
            numPts = length(subsetinds);
            ss = numPts/numPts2Sample;
            labels = labels(subsetinds(floor(1:ss:end)));
            feats = feats(subsetinds(floor(1:ss:end)),:);
            mask(subsetinds(floor(1:ss:end))) = true;
    else
        ss = numPts/numPts2Sample;
        if(ss>1)
            labels = labels(floor(1:ss:end));
            feats = feats(floor(1:ss:end),:);
            mask(floor(1:ss:end)) = true;
        else
            mask(:) = true;
        end
    end
end