function [feats params] = MySVMNormalize(feats,params,dimToNorm)

if(~exist('dimToNorm','var'))
    dimToNorm = 1:size(feats,2);
end

if(isfield(params,'rmDim'))
    [a b] = intersect(dimToNorm,params.rmDim);
    feats(:, b) = [];
    normMask = zeros(max(dimToNorm),1)==1;
    normMask(dimToNorm) = true;
    normMask(b) = [];
    dimToNorm = find(normMask);
end

if(~isfield(params,'norm'))
    if(strcmp(params.normType,'std'))
        try
             params.norm = std(feats);
        catch
        params.norm = zeros(1,size(feats,2));
        for i = 1:size(feats,2)
            params.norm(1,i) = std(feats(:,i));
        end
        end
        %params.norm = params.norm + max(min(params.norm(params.norm~=0))/100,.0001);
        params.norm(1:end/2) = mean(params.norm(1:end/2));
        params.norm((1+end/2):end) = mean(params.norm((1+end/2):end));
    else
        params.norm = ones([1 size(feats,2)]);
    end
end

feats = bsxfun(@rdivide,feats,params.norm(dimToNorm));

if(~isfield(params,'gamma') || isempty(params.gamma))
    if(isfield(params,'autogamma') && params.autogamma > 0)
        rp = randperm(size(feats,1));
        d = dist2(feats,feats(rp(1:100),:));
        d = sort(d);
        params.gamma = mean(sqrt(d(50,d(50,:)>0)))*params.autogamma;
    end
end

if(~isfield(params,'RFP'))
    if(isfield(params,'RFPdim'))
        params.RFP = randn(size(feats,2), params.RFPdim/2);
        params.RFP = params.RFP/params.gamma;
    end
end

% the following is equievelent as cos(XW+b)
% using the auhtor's implementation

if(isfield(params,'RFP'))
    feats = feats*params.RFP(dimToNorm,:);
    feats = (1/sqrt(size(feats,2)*2))*[cos(feats) sin(feats)];
end

