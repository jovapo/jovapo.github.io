function options = MySVMOptions( C, kernel, gamma )
%MYSVMOPTIONS Summary of this function goes here
%   Detailed explanation goes here

options = sprintf(' -c %g',C);
if(exist('kernel','var') && ~isempty(kernel))
    options = sprintf('%s -t %d',options,kernel);
end
if(exist('gamma','var')&& ~isempty(gamma))
    options = sprintf('%s -g %g',options,gamma);
end

end

