function svm = MySVMTrain( feats, labels, params, testFeats, testLabels)
%MYSVMTRAIN Summary of this function goes here
%   Detailed explanation goes here
if(~exist('params','var'))
    %default params
    params.trainFun = @liblineardensetrain;
    params.testFun = @liblineardensepredict;
    params.kernel = [];
    params.svmName = 'libLinearDenseSTD';
    params.normType = 'std';
    params.cvSize = 5;
    params.cvTarget = 'classification';
    params.C = 1;
    params.options = '';
    params.gamma = [];
    params.gamma = [];
    params.maxCItt = 3;
    params.cThresh = .005;
    if(min(size(labels))==1)
        params.labelList = unique(labels);
    else
        params.labelList = (1:size(labels,2))';
    end
end

if(~isfield(params,'trainFun'))
    params.trainFun = @liblineardensetrain;
end
if(~isfield(params,'testFun'))
    params.testFun = @liblineardensepredict;
end
if(~isfield(params,'kernel'))
    params.kernel = [];
end
if(~isfield(params,'svmName'))
    params.svmName = 'libLinearDenseSTD';
end
if(~isfield(params,'normType'))
    params.normType = 'std';
end
if(~isfield(params,'cvSize'))
    params.cvSize = 5;
end
if(~isfield(params,'cvTarget'))
    params.cvTarget = 'classification';
end
if(~isfield(params,'C'))
    params.C = 1;
end
if(~isfield(params,'options'))
    params.options = '';
end
if(~isfield(params,'gamma'))
    params.gamma = [];
end
if(~isfield(params,'maxCItt'))
    params.maxCItt = 3;
end
if(~isfield(params,'cThresh'))
    params.cThresh = .005;
end
if(~isfield(params,'labelList'))
    if(min(size(labels))==1)
        params.labelList = unique(labels);
    else
        params.labelList = (1:size(labels,2))';
    end
end
    
if(~isfield(params,'names')||length(params.names)<max(params.labelList))
    params.names = cell(length(params.labelList),1);
    for i = 1:length(params.names)
        params.names{i} = num2str(params.labelList(i));
    end
end

options = params.options;

[feats params] = MySVMNormalize(feats,params);


if(exist('testLabels','var'));
    C = params.C;
    cvCriteria = [];
    [testFeats] = MySVMNormalize(testFeats,params);
    predictor = zeros(length(testLabels),length(params.labelList));
    phase = 1;
    best = 1;
    numDiv = 0;
    while(numDiv< params.maxCItt);
        newmodel = cell(size(params.labelList));
        timingVar = tic;
        parfor lndx = 1:length(params.labelList)
            tic
            if(min(size(labels))==1)
                svmInLabels = double(params.labelList(lndx) == labels);
            else
                svmInLabels = double(labels(:,lndx));
            end
            
            svmInLabels(svmInLabels==0) = -1;
            newmodel{lndx} = params.trainFun(svmInLabels,feats,['-q ' options MySVMOptions(params.C,params.kernel,params.gamma)]);
            %{
            if(isequal(params.testFun, @liblinearpredict)||isequal(params.testFun, @liblineardensepredict))
                predictor(:,lndx) = testFeats*newmodel{lndx}.w'.*newmodel{lndx}.Label(1);
            else
                [a b p] = params.testFun(ones(size(testLabels)),testFeats,newmodel{lndx});
                predictor(:,lndx) = p*newmodel{lndx}.Label(1);
            end
            %}
            toc
        end
        
        parfor lndx = 1:length(params.labelList)
            if(isequal(params.testFun, @liblinearpredict)||isequal(params.testFun, @liblineardensepredict))
                predictor(:,lndx) = testFeats*newmodel{lndx}.w'.*newmodel{lndx}.Label(1);
            else
                [a b p] = params.testFun(ones(size(testLabels)),testFeats,newmodel{lndx});
                predictor(:,lndx) = p*newmodel{lndx}.Label(1);
            end
        end
        [a pl] = max(predictor,[],2);
        pl = params.labelList(pl);
        cvCriteria(end+1) = ComputeCVCriteria(pl,testLabels,params.cvTarget);
        fprintf('Finished: C = %f perfomance: %f in %.2f seconds\n',params.C,cvCriteria(end),toc(timingVar));
        if(length(C)>1)
            if(cvCriteria(end)>cvCriteria(best))
                model = newmodel;
                best = length(cvCriteria);
            else
                if(phase==1)
                    phase = 2;
                    if(length(C)>2)
                        phase=3;
                    end
                    C = C(end:-1:1);
                    cvCriteria = cvCriteria(end:-1:1);
                    [~, best] = max(cvCriteria);
                elseif(phase == 2)
                    phase = 3;
                end
            end
        else
            model = newmodel;
        end
        if(phase == 1)
            C(end+1) = C(end)/10;
            params.C = C(end);
        elseif(phase == 2)
            C(end+1) = C(end)*10;
            params.C = C(end);
        else
            if(length(C) == length(cvCriteria))
                numDiv = numDiv+1;
                [C, a] = sort(C);
                cvCriteria = cvCriteria(a);
                [bC] = sort(cvCriteria,'descend');
                [~, best] = max(cvCriteria);
                if(bC(1)-bC(2)< params.cThresh)
                    break;
                end
                C(end+1) = (C(best)+C(best-1))/2;
                params.C = C(end);
                C(end+1) = (C(best)+C(best+1))/2;
            else
                params.C = C(end);
            end
        end
    end
    params.C = C(best);
    params.cvCriteria = cvCriteria(best);
else
    
    if(params.cvSize>1)
        C = params.C;
        cvCriteria = [];
        predictor = zeros(length(labels),length(params.labelList));
        phase = 1;
        best = 1;
        numDiv = 0;
        testCVSize = ceil(length(labels)/params.cvSize);
        while(numDiv< params.maxCItt);
            tic
            for cv = 1:params.cvSize
                testInd = (cv-1)*testCVSize+1:min(length(labels),cv*testCVSize);
                testMask = zeros(size(labels))==1;
                testMask(testInd) = true;
                trainInd = find(~testMask);
                cvTrainL = labels(trainInd);
                cvTrainF = feats(trainInd,:);
                cvTestF = feats(testInd,:);

                for lndx = 1:length(params.labelList)
                    svmInLabels = double(params.labelList(lndx) == cvTrainL);
                    svmInLabels(svmInLabels==0) = -1;
                    model = params.trainFun(svmInLabels,cvTrainF,['-q ' options MySVMOptions(params.C,params.kernel,params.gamma)]);
                    if(isequal(params.testFun, @liblinearpredict)||isequal(params.testFun, @liblineardensepredict))
                        predictor(testInd,lndx) = cvTestF*model.w'.*model.Label(1);
                    else
                        [a b p] = params.testFun(ones(size(testInd)),cvTestF,model);
                        predictor(testInd,lndx) = p*model.Label(1);
                    end
                end
            end
            [a pl] = max(predictor,[],2);
            pl = params.labelList(pl);
            cvCriteria(end+1) = ComputeCVCriteria(pl,labels,params.cvTarget);
            fprintf('Finished: C = %f perfomance: %f in %.2f seconds\n',params.C,cvCriteria(end),toc);
            if(length(C)>1)
                if(cvCriteria(end)>cvCriteria(best))
                    best = length(cvCriteria);
                else
                    if(phase==1)
                        phase = 2;
                        if(length(C)>2)
                            phase=3;
                        end
                        C = C(end:-1:1);
                        cvCriteria = cvCriteria(end:-1:1);
                        [~, best] = max(cvCriteria);
                    elseif(phase == 2)
                        phase = 3;
                    end
                end
            end
            if(phase == 1)
                C(end+1) = C(end)/10;
                params.C = C(end);
            elseif(phase == 2)
                C(end+1) = C(end)*10;
                params.C = C(end);
            else
                if(length(C) == length(cvCriteria))
                    numDiv = numDiv+1;
                    [C, a] = sort(C);
                    cvCriteria = cvCriteria(a);
                    [bC] = sort(cvCriteria,'descend');
                    [~, best] = max(cvCriteria);
                    if(bC(1)-bC(2)< params.cThresh)
                        break;
                    end
                    C(end+1) = (C(best)+C(best-1))/2;
                    params.C = C(end);
                    C(end+1) = (C(best)+C(best+1))/2;
                else
                    params.C = C(end);
                end
            end
        end
        params.C = C(best);
        params.cvCriteria = cvCriteria(best);
    end
    
    model = cell(length(params.labelList),1);
    %feats = sparse(feats);
    for lndx = 1:length(params.labelList)
        if(min(size(labels))==1)
            svmInLabels = double(params.labelList(lndx) == labels);
        else
            svmInLabels = double(labels(:,lndx));
        end
        svmInLabels(svmInLabels==0) = -1;
        tic;
        model{lndx} = params.trainFun( svmInLabels,feats,['-q ' options MySVMOptions(params.C,params.kernel,params.gamma)]);
        fprintf('Finished: %s in %.2f seconds\n',params.names{params.labelList(lndx)},toc);
    end
end

svm = [];
svm.params = params;
svm.model = model;

function cvCriteria =  ComputeCVCriteria(pl,labels,cvTarget)
if(strcmp(cvTarget,'classification'))
    cvCriteria = sum(pl(:)==labels(:))./numel(pl);
elseif(strcmp(cvTarget,'avgPerClass'))
    ll = unique(labels);
    pc = zeros(size(ll));
    for i = 1:length(ll)
        mask = labels == ll(i);
        pc(i) = sum(pl(mask)==labels(mask))./sum(mask);
    end
    cvCriteria = mean(pc);
elseif(strcmp(cvTarget,'avgPlusClass'))
    rates = MySVMRates(pl,labels);
    cvCriteria = sum(rates(1:2,1)./rates(1:2,2));   
end
