function [ rates ] = MySVMRates( pl, gl )
%MYSVMRATES Summary of this function goes here
%   Detailed explanation goes here
pl = uint16(pl);
gl = uint16(gl);
maxL = max(max(pl),max(gl));
rates = zeros(maxL+2,2);
rates(1,:) = [sum(pl(:)==gl(:)) numel(pl)];
for i = 1:maxL
    mask = gl == i;
    rates(i+2,:) = [sum(pl(mask)==gl(mask)) sum(mask)];
end
rates(2,2)= 1;
rmean = rates(3:end,:);
rmean(rmean(:,2)==0,:)=[];
rates(2,:) = [mean(rmean(:,1)./rmean(:,2)) 1];

end

