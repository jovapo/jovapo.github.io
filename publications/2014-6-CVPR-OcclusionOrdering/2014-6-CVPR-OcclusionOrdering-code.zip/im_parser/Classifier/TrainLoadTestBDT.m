SetUpConstants;

justDetectors=false;
UseClassifier = 0;
if(~exist('loadDone','var') || loadDone == false)
    LoadData2;
end
loadDone = true;
testParams.Rs = Rs;
UseClassifier = 1;


if(~exist('UseClassifier','var'))
    UseClassifier = zeros(size(HOMELABELSETS));
end
claParams.num_nodes = 8;
%claParams.stopval = .0001;
%claParams.num_iterations = 100;
%claParams.subSample = 400000;
%claParams.balancedsubSample = 1;
%claParams.testsetnum = 1;
claParams.segmentDescriptors = testParams.segmentDescriptors;
claParams.K = K;
claParams.segSuffix = segSuffix;
claParams.clFold = fullfile(testParams.TestString,'Classifier');
classifiers = cell(length(K),length(Labels));
for i = find(UseClassifier)
    labelMask = cell(1);
    labelMask{1} = true(size(Labels{i}));
    claParams.labels2Train = rangeN(1):rangeN(2):length(Labels{i});
    classifiers(:,i) = TrainClassifier(HOMEDATA, HOMELABELSETS(i), trainFileList, trainIndex(i), Labels(i), labelMask, claParams);
end


temp = testParams.TestString;
placeHolder = cell(size(HOMELABELSETS));
testParams.TestString = 'RunOnTraining';
testParams.range = rangeTrain;
fullSPDesc{1} = LoadSegmentDesc(trainFileList,trainIndex{1},HOMEDATA,testParams.segmentDescriptors,testParams.K(1),testParams.segSuffix);
%timing = ParseTestImagesWDetectors(HOMEDATA,HOMEDATA,HOMELABELSETS,trainFileList,trainGlobalDesc,trainFileList,trainGlobalDesc,trainIndex,trainCounts,labelPenality,Labels,classifiers,placeHolder,testParams,fullSPDesc);
    
testParams.TestString = temp;
testParams.range = rangeTest;
timing = ParseTestImagesWDetectors(HOMEDATA,HOMEDATA,HOMELABELSETS,testFileList,testGlobalDesc,trainFileList,trainGlobalDesc,trainIndex,trainCounts,labelPenality,Labels,classifiers,placeHolder,testParams,fullSPDesc);
