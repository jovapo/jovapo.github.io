%{-
SetUpConstants;
descFuns = sort({'pose_dist_sym','pose_dist','centered_mask_sp','bb_extent','pixel_area','absolute_mask','top_height','int_text_hist_mr','dial_text_hist_mr','sift_hist_int_','sift_hist_dial','sift_hist_bottom','sift_hist_top','sift_hist_right','sift_hist_left','mean_color','color_std','color_hist','dial_color_hist','color_thumb','color_thumb_mask','gist_int'});

testIndex = LoadSegmentLabelIndex(testFileList,[],HOMELABELSETS{1},fullfile(HOMEDATA,'Descriptors'),sprintf('SP_Desc_k%d%s',testParams.K, testParams.segSuffix),false);
testSetSPDesc = LoadSegmentDesc(testFileList,testIndex,HOMEDATA,descFuns,testParams.K, testParams.segSuffix);
testfeatures = GetFeaturesForClassifier(testSetSPDesc);
testlabels = (testIndex.label == find(strcmp(Labels{1},backgroundLabel)))*2-1;
clear testSetSPDesc;

for doFlip = [false true]
    [segIndex Labels Counts] = LoadSegmentLabelIndex(trainFileList,[],HOMELABELSETS{1},fullfile(HOMEDATA,'Descriptors'),sprintf('SP_Desc_k%d%s',testParams.K, testParams.segSuffix),doFlip);
    retSetSPDesc = LoadSegmentDesc(trainFileList,segIndex,HOMEDATA,descFuns,testParams.K, testParams.segSuffix);
    features = GetFeaturesForClassifier(retSetSPDesc);
    clear retSetSPDesc;
    cat_features = [];
    labels = (segIndex.label == find(strcmp(Labels{1},backgroundLabel)))*2-1;

    for evenWeight = [true false]
        if(evenWeight)
            [a b] = UniqueAndCounts(labels);
            w = ones(length(labels), 1);
            w(labels == a(1)) = 1/b(1);
            w(labels == a(2)) = 1/b(2);
        else
            w = ones(length(labels), 1);
        end
        clSaveFile = fullfile(HOMEDATA,'Classifier','ForeBack',sprintf('BDT-WFlip%01d-EvenW%01d.mat',doFlip,evenWeight~=0));make_dir(clSaveFile);
        if(~exist(clSaveFile,'file'))
            classifier = train_boosted_dt_2c(features, cat_features, labels(:), 100, 8, .0001, w);
            save(clSaveFile,'classifier');
        else
            load(clSaveFile);
        end
        confidences = test_boosted_dt_mc(classifier, testfeatures);
        correct = (sign(confidences)==testlabels(:));
        [fold base] = fileparts(clSaveFile);
        fprintf('%.3f %s\n',sum(correct)./length(correct),base);
        classifier.h0 =  ROCBalance(confidences,testlabels(:));
        
        
        clSaveFile = fullfile(HOMEDATA,'Classifier','ForeBack',sprintf('SVM-WFlip%01d-EvenW%01d.mat',doFlip,evenWeight));make_dir(clSaveFile);
        svmparams.labelList = 1;
        svmparams.options = ['-s 2'];
        if(evenWeight==1)
            [a b] = UniqueAndCounts(labels);
            w = b([2 1])./max(b);
            svmparams.options = [svmparams.options '-wi ' num2str(w(1)) ' ' num2str(w(2))];
        end
        if(evenWeight==-1)
            [a b] = UniqueAndCounts(labels);
            w = b./max(b);
            svmparams.options = [svmparams.options '-wi ' num2str(w(1)) ' ' num2str(w(2))];
        end
        svmparams.cvTarget = 'avgPlusClass';
        if(~exist(clSaveFile,'file'))
            svm = MySVMTrain( features, labels(:),svmparams);
            save(clSaveFile,'svm');
        else
            load(clSaveFile);
        end
        [ rates, pl, predictor ] = MySVMTest(testfeatures,testlabels(:),svm);
        [fold base] = fileparts(clSaveFile);
        fprintf('%.3f %s\n',rates(1,1)/rates(1,2),base);
        classifier.h0 =  ROCBalance(predictor,testlabels(:));
    end
end
