saveFile = fullfile(HOME,'SpatialPrior.mat');
if(exist(saveFile,'file'))
    load(saveFile);
else
    spatialPrior = zeros(priorSize,priorSize,length(names));
    lObjCounts = zeros(size(names));
    pfig = ProgressBar('Building Prior');
    for f = 1:length(trainFileList)
        [fold base] = fileparts(trainFileList{f});
        try
            clear S_instances;
            load(fullfile(HOMELABELSETS{1},fold,[base '.mat'])); %S (ro x co) names
            if(~exist('S_instances','var'))
                S_instances = AddSInstances(HOMELABELSETS{1},fullfile(HOME,'Annotations'),fullfile(fold,[base '.mat']));
                fprintf('Adding %s\n',[fold '\' base]);
            end
            for i = 1:size(S_instances,3)
                l = max(max(S_instances(:,:,i)));
                lObjCounts(l) = lObjCounts(l) + 1;
                spatialPrior(:,:,l) = spatialPrior(:,:,l) + imresize(S_instances(:,:,i)>0, [priorSize priorSize],'nearest');
            end
        catch
            fprintf('Error %s\n',[fold '\' base]);
        end
        if(mod(f,100)==0)
            ProgressBar(pfig,f,length(trainFileList));
        end
    end
    save(saveFile,'spatialPrior','lObjCounts');
end
spatialPrior = spatialPrior+1;
%count norm
%spatialPrior = spatialPrior./repmat(reshape(lObjCounts+1,[1 1 length(lObjCounts)]),[priorSize priorSize]);

%my norm
for l = 1:size(spatialPrior,3)
    spl = spatialPrior(:,:,l);
    spatialPrior(:,:,l) = (spl)./max(spl(:));
end
spatialPrior = spatialPrior./repmat(sum(spatialPrior,3),[1 1 size(spatialPrior,3)]);
