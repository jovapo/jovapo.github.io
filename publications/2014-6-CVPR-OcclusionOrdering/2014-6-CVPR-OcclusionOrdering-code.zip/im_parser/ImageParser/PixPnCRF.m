function [LabelPixels] = PixPnCRF(HOMEDATA,HOMELABELSET,testName,baseFName,Labels,im,unary,pNPot,params)

if(~exist('canskip','var'))
    canskip = 1;
end
if(~isfield(params,'S'))
    params.S = [];
end
if(~isfield(params,'names'))
    params.names = [];
end
outFileName = [];
if(~isempty(HOMELABELSET))
    [foo LabelFolder] = fileparts(HOMELABELSET);
    outFileName = fullfile(HOMEDATA,LabelFolder,testName,sprintf('%s.mat',baseFName));
    if(exist(outFileName,'file')&&canskip)
        load(outFileName);
        LabelPixels = L;
        if(exist('labelList','var'))
            numLabels = size(unary,2);
            if(numLabels==length(labelList))
                return;
            end
        end
    end
end
%reduce the label set to only plausable labels
[ro, co, ch] = size(im);
[foo, Lmin] = min(unary,[],2);
usedLs = unique([Lmin; size(unary,2)]);
if(length(usedLs) == 1)
    dcT = unary;
    dcT(:,usedLs) = max(dcT(:));
    [foo, Lmin] = min(dcT,[],2);
    usedLs = unique([Lmin; usedLs]);
end
unary = unary(:,usedLs);
numPix = numel(unary(:,1));
if(~isempty(pNPot))
    if(~isempty(pNPot.costs))
        pNPot.costs = pNPot.costs(:,[usedLs; end]);
    end
end

hs = pncrf_mex('pncrf_listhandles');
for i = 1:length(hs)
    PNCRF_Delete(hs(i));
end

h = PNCRF_CreateCRF(size(unary,1),size(unary,2));
PNCRF_SetUnary(h,unary');
PNCRF_AddPairwiseGaussian(h,[ro co],params.gausianParams.x_std,params.gausianParams.y_std,params.gausianParams.weight,params.conn);
PNCRF_AddPairwiseBilateral(h,im,params.bilateralParams.dist_std,params.bilateralParams.co_std,params.bilateralParams.weight,params.conn);
if(~isempty(pNPot))
    if(isfield(pNPot,'segCell'))
        PNCRF_SetPnwSegs( h, pNPot.segCell, pNPot.costs,  pNPot.truncFrac );
    else
        PNCRF_SetPnEnergy( h, pNPot.index, pNPot.costs,  pNPot.Q );
    end
end
L = PNCRF_Expand(h,params.itterations);
PNCRF_Delete(h);

L = usedLs(L+1);
L = reshape(L,[ro co]);
labelList = Labels;
if(~isempty(outFileName))
    make_dir(outFileName);
    if(~isfield(params,'clsList'))
        OutputLabeling(outFileName,L,labelList,params.S,params.names);
    else
        Lobj = L;
        L = params.clsList(L);
        %OutputLabeling(outFileName,L,labelList,params.S,params.names,Lobj,params.clsList);
    end
end
LabelPixels = L;

end

