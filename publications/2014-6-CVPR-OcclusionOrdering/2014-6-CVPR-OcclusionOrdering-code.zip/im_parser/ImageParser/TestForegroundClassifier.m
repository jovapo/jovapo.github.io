
SetUpConstants;
descFuns = testParams.segmentDescriptors;%sort({'pose_dist_sym','pose_dist','centered_mask_sp','bb_extent','pixel_area','absolute_mask','top_height','int_text_hist_mr','dial_text_hist_mr','sift_hist_int_','sift_hist_dial','sift_hist_bottom','sift_hist_top','sift_hist_right','sift_hist_left','mean_color','color_std','color_hist','dial_color_hist','color_thumb','color_thumb_mask','gist_int'});

%{-
if(~exist('testfeatures','var'))
    testIndex = LoadSegmentLabelIndex(testFileList,[],HOMELABELSETS{1},fullfile(HOMEDATA,'Descriptors'),sprintf('SP_Desc_k%d%s',testParams.K, testParams.segSuffix),false);
    testSetSPDesc = LoadSegmentDesc(testFileList,testIndex,HOMEDATA,descFuns,testParams.K, testParams.segSuffix);
    testfeatures = GetFeaturesForClassifier(testSetSPDesc);
    testlabels = (testIndex.label == find(strcmp(Labels{1},backgroundLabel)))*2-1;
    clear testSetSPDesc;
end
%}
genWeb = false;
%{
genWeb = true;
MyCleanUp;
HOMEWEB = fullfile(TestFold,'ForeBackWeb');
indexfile = fullfile(HOMEWEB,'index.html');make_dir(indexfile);
indexFID = fopen(indexfile,'w');
fprintf(indexFID,'\n<center>\n');
fprintf(indexFID,'\n<table border="0">\n');
fprintf(indexFID,'\t<tr>\n');
maxDim = 400;
numCols = 6;
colCount = 0;
%}

clSaveFiles = dir_recurse( fullfile(HOMEDATA,'Classifier','ForeBack','*.mat'));
scores = cell(size(clSaveFiles));
params.smoothness_const = [10 100];
params.shape_w = [0 .25];
params.weightedHist = true;
for i = 5%:length(clSaveFiles)
    [~, clname] = fileparts(clSaveFiles{i});
    load(clSaveFiles{i});
    confidences = test_boosted_dt_mc(classifier, testfeatures);
    scores{i} = zeros(length(params.shape_w)*length(params.smoothness_const)*2+1,4);
    testNames = cell(0);
    pfig = ProgressBar('Smoothing Masks');
    for f = 1:length(testFileList)
        [fold, base ext] = fileparts(testFileList{f});clear im;
        im = imread(fullfile(HOMEIMAGES,testFileList{f}));
        [ro, co, ch] = size(im);
        imSP = load(fullfile(HOMEDESCRIPTOR,'SP_Desc_k200','super_pixels',fold,[base '.mat']));
        imSP = imSP.superPixels;
        ndxs = find(testIndex.image==f);
        mu = 1;%mean2(abs(confidences(ndxs)));
        c = 1./(1+exp(-confidences(ndxs)./mu));
        %c = confidences(ndxs);c = c./(2*max(max(c(:)),-min(c(:))))+.5;
        uSP = testIndex.sp(ndxs);
        spMap = zeros(max(uSP),1);
        spMap(uSP) = 1:length(uSP);
        cIm = c(spMap(imSP));
        
        params.weightedHist = true;
        [temp, testname, fg_color_cost] = RefineFGBG(im,1-cIm,params);
        
        if(genWeb)
            imageWebPage = fullfile(HOMEWEB,'ImageWeb',fold,[base '.htm']);make_dir(imageWebPage);
            imFID = fopen(imageWebPage,'w');
            fprintf(imFID,'<br>imageNum %d',i);
            fprintf(imFID,'\n<center>\n');
            fprintf(imFID,'\n<table border="0">\n');
            fprintf(imFID,'\t<tr>\n');
            imageFile = fullfile(HOMEWEB,'Images',testFileList{f});make_dir(imageFile);
            copyfile(fullfile(HOMEIMAGES,testFileList{f}),imageFile);
            fprintf(imFID,'<td><img height="%d" src="%s"> </td></tr>',min(ro,maxDim),['../Images/' fold '/' base ext]);
            fprintf(imFID,'\t\t<tr><td><center>%s</center></td>\n','Classifier weight based Color Model');
            saveFile = fullfile(HOMEWEB,'Output',fold,[base '-wHist.png']);make_dir(saveFile);
            show(temp{1},1);export_fig(saveFile);
            fprintf(imFID,'<td><img height="%d" src="%s"> </td>',min(ro,maxDim),['../Output/' fold '/' base '-wHist.png']);
            saveFile = fullfile(HOMEWEB,'Output',fold,[base '-wHist-cm.png']);make_dir(saveFile);
            show(fg_color_cost,1);export_fig(saveFile);
            fprintf(imFID,'<td><img height="%d" src="%s"><br>Color Model Unary </td>',min(ro,maxDim),['../Output/' fold '/' base '-wHist-cm.png']);
            saveFile = fullfile(HOMEWEB,'Output',fold,[base '-wHist-dt.png']);make_dir(saveFile);
            show(cIm,1);export_fig(saveFile);
            fprintf(imFID,'<td><img height="%d" src="%s"><br>Classifier Unary </td></tr>',min(ro,maxDim),['../Output/' fold '/' base '-wHist-dt.png']);
        end
        for j = 1:length(temp)
            testNames{j} = [testname{j} 'wHist 8 conn'];
            outMasks{j} = temp{j};
            saveFold = sprintf('%s-wHist-8con',testname{j});
            saveFile=fullfile(TestFold,'ForeBack',saveFold,fold,[base '.mat']);make_dir(saveFile);
            mask = temp{j};
            save(saveFile,'mask','cIm','fg_color_cost');
        end
        
        params.weightedHist = false;
        [temp, testname, fg_color_cost] = RefineFGBG(im,1-cIm,params);
        if(genWeb)
            fprintf(imFID,'\t\t<tr><td><center>%s</center></td>\n','Mask based Color Model');
            saveFile = fullfile(HOMEWEB,'Output',fold,[base '.png']);make_dir(saveFile);
            show(temp{1},1);export_fig(saveFile);
            fprintf(imFID,'<td><img height="%d" src="%s"> </td>',min(ro,maxDim),['../Output/' fold '/' base '.png']);
            saveFile = fullfile(HOMEWEB,'Output',fold,[base '-cm.png']);make_dir(saveFile);
            show(fg_color_cost,1);export_fig(saveFile);
            fprintf(imFID,'<td><img height="%d" src="%s"><br>Color Model Unary </td>',min(ro,maxDim),['../Output/' fold '/' base '-cm.png']);
            saveFile = fullfile(HOMEWEB,'Output',fold,[base '-dt.png']);make_dir(saveFile);
            show(cIm,1);export_fig(saveFile);
            fprintf(imFID,'<td><img height="%d" src="%s"><br>Classifier Unary </td></tr></table>',min(ro,maxDim),['../Output/' fold '/' base '-dt.png']);
        end
        
        for j = 1:length(temp)
            testNames{j+length(temp)} = [testname{j} ' 8 conn'];
            outMasks{j+length(temp)} = temp{j};
            saveFold = sprintf('%s-8con',testname{j});
            saveFile=fullfile(TestFold,'ForeBack',saveFold,fold,[base '.mat']);make_dir(saveFile);
            mask = temp{j};
            save(saveFile,'mask','cIm','fg_color_cost');
        end
        
        gtMask = testlabels(ndxs(spMap(imSP)))==-1;
        for j = 1:length(outMasks)
            scores{i}(j,:) = scores{i}(j,:)+[sum(gtMask(gtMask==1)==outMasks{j}(gtMask==1)) sum(gtMask(:)==1) ...
                              sum(gtMask(gtMask==0)==outMasks{j}(gtMask==0)) sum(gtMask(:)==0) ];
        end
        ns = cIm<.5;
        scores{i}(end,:) = scores{i}(end,:)+[sum(gtMask(gtMask==1)==ns(gtMask==1)) sum(gtMask(:)==1) ...
                              sum(gtMask(gtMask==0)==ns(gtMask==0)) sum(gtMask(:)==0) ];
                          
        if(genWeb)
            fprintf(indexFID,'\t\t<td><center> <a href="%s">',['ImageWeb/' base '.htm']);
            fprintf(indexFID,'<img  width="200" src="%s"></a> ',['Images/' fold '/' base ext]);
            fprintf(indexFID,'</center> </td>\n');
            colCount = colCount +1;
            if(colCount == numCols)
                colCount = 0;
                fprintf(indexFID,'\t</tr><tr>\n');
            end 
        end
        ProgressBar(pfig,f,length(testFileList));
    end
    close(pfig);
    fprintf('For Classifier %s:\n',clname);
    swl = length(params.shape_w);
    scl = length(params.smoothness_const);
    for k = 1:length(testNames)
        fprintf('%.3f %.3f: %s\n',scores{i}(k,1)/scores{i}(k,2),scores{i}(k,3)/scores{i}(k,4),testNames{k});        
    end
    fprintf('%.3f %.3f: max likelihood\n',scores{i}(end,1)/scores{i}(end,2),scores{i}(end,3)/scores{i}(end,4));
end