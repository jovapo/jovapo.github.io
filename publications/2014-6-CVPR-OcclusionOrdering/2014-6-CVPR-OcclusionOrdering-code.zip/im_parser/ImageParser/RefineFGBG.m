function [outMask testName fg_color_cost] = RefineFGBG(im,fgScore,params,color_index_map)
    %show(im,1);
    %show(mask,2);
    %show(fgScore,3);
    if(~exist('color_index_map','var'))
        color_bin = 12;
        while (color_bin <= 255)
            [~, color_index_dist, color_index_map, nBin] = RGBQuantization(im, color_bin, 0.95, false);
            if ( nBin < 100 )
                color_bin = color_bin + 12;
            else
                break;
            end
        end
    else
        nBin = max(color_index_map(:));
    end
    img_size = size(color_index_map);
    ubw = fgScore>0.5;%show(ubw);show(fgScore);

    bbox_margin = .25;
    % pick the best boundbox
    [y x] = find(ubw);
    lx = min(x);
    rx = max(x);
    ty = min(y);
    dy = max(y);
    w = rx-lx;
    h = dy-ty;
    lx = max(1,ceil(lx-w*bbox_margin));
    rx = min(img_size(2),ceil(rx+w*bbox_margin));
    ty = max(1,ceil(ty-h*bbox_margin));
    dy = min(img_size(1),ceil(dy+h*bbox_margin));

    % determine bandwidth
    fg_size = sum(ubw(:));
    w = rx-lx;
    h = dy-ty;
    bandwidth = ceil(0.5*fg_size/(w+h));

    % background
    lx2 = lx + bandwidth;
    rx2 = rx - bandwidth;
    ty2 = ty + bandwidth;
    dy2 = dy - bandwidth;
    bgbw = false(img_size);
    bgbw(ty:dy,lx:rx) = true;
    bgbw(ty2:dy2,lx2:rx2) = false;
    bgbw = bgbw & ~ubw;

    % histogram
    if(isfield(params,'weightedHist') && params.weightedHist)
        fg_h = WeightedHistC(color_index_map(:),fgScore(:));
        bg_h = WeightedHistC(color_index_map(:),1-fgScore(:));
    else
        if ( ~isempty(ubw) )
            fg_h = histc(color_index_map(ubw), 1:nBin);
        else
            fg_h = ones(nBin,1);
        end
        if ( ~isempty(bgbw) && ~all(~bgbw(:)) )
            bg_h = histc(color_index_map(bgbw), 1:nBin);
        else
            bg_h = ones(nBin,1);
        end
    end
    fg_h = fg_h./sum(fg_h);
    bg_h = bg_h./sum(bg_h);
   
    fg_color_hist = fg_h;
    bg_color_hist = bg_h;
    
    % bbox
    bbox = [lx rx ty dy]';
    colorSpecs = {'-r','-b','-g','-c','-m','-y','-k','-b'};
    cC = 1;
    %figure(1);hold on;
    %contour(cbw,colorSpecs{cC}); cC = cC +1;
    outMask = cell(0);
    testName = cell(0);
    if(~exist('params','var'))
        params.shape_w = [.5 .75];
        params.smoothness_const = [5 10];
    end
    for shape_t = [2];
    for shape_w = params.shape_w
        for shape_lambda = [.5]
            for smoothness_const = params.smoothness_const
            for conn = 4
            if(shape_t == 1)
                fg_shape_cost = ones(img_size)*(.5+shape_lambda);
                fg_shape_cost(ubw) = .5;
                fg_shape_cost(cbw) = .5-shape_lambda;
            else
                fg_shape_cost = fgScore/max(fgScore(:));
                fg_shape_cost = fg_shape_cost.*(shape_lambda*2)+(.5-shape_lambda);
                fg_shape_cost = 1-fg_shape_cost;
            end

            %contour(fg_shape_cost,colorSpecs{cC}); cC = cC +1;

            fg_color_cost = computeColorHistDataCost(fg_color_hist, bg_color_hist, color_index_map);
            fg_cost = ((1-shape_w).*fg_color_cost + shape_w.*fg_shape_cost);
            %show(fg_cost,5);
            %{
            shape_prior = cbw(:);

            mu = mean(gPb_thin(gPb_thin>0));
            smoothness = exp(-gPb_thin./mu);
            %smoothness_const = 5.0;

            min_overlap_initguess = 0.5;
            fix_seed = false;
            min_obj_size = 250;
            lambda =  [0];%, 0, 0.125];
            %[segments params n_comp] = computeGraphCutMoreCon(fg_cost, lambda, shape_prior, smoothness, smoothness_const, img_size, bbox, min_overlap_initguess, min_obj_size, fix_seed,conn);
            [segments params n_comp] = computeGraphCut(fg_cost, lambda, shape_prior, smoothness, smoothness_const, img_size, bbox, min_overlap_initguess, min_obj_size, fix_seed);
            outMask{end+1} = segments;
            %}
            %testName{end+1} = sprintf('Shape%dSmooth%d',shape_w*100,smoothness_const);
            %for i = 1:size(segments,2)
                %show(reshape(segments(:,i),img_size));%,i+5);
                %figure(1);hold on;
                %contour(reshape(segments(:,i),img_size),colorSpecs{cC}); cC = cC +1;
            %end
            
            % resize by bbox
            fg_cost = fg_cost(ty:dy,lx:rx);
            unary = [(1-fg_cost(:)) fg_cost(:) ];
            
            %{
            l = SmoothCRF(im(ty:dy,lx:rx,:),unary,[],smoothness_const);
            %show(l,10);
            bw = false(img_size);
            bw(ty:dy,lx:rx) = l==2;
            outMask{end+1} = bw;
            %}
            
            smoothingMatrix = smoothness_const*(ones(2)-eye(2));
            mrfparams.edgeParam = 11;
            mrfparams.connected=8;
            Labels{1} = {'fore','null'};
            imSP = ones(size(fg_cost));
            MAX_COST = 10000;
            [LabelPixels] = MultiLevelPixMRF([],[],[],[],Labels,imSP,im(ty:dy,lx:rx,:),{unary*MAX_COST},smoothingMatrix,[],mrfparams);
            %show(LabelPixels{1},11);
            bw = false(img_size);
            bw(ty:dy,lx:rx) = LabelPixels{1}==2;
            outMask{end+1} = bw;
            testName{end+1} = sprintf('Shape%dSmooth%d',shape_w*100,smoothness_const);
            end
            end
        end
    end
    end