glSuffix = '';
timeRetSet=tic; [retInds rank]= FindRetrievalSet(trainGlobalDesc,SelectDesc(testGlobalDesc,i,1),TestFold,fullfile(fold,base),testParams,glSuffix);timeRetSet=toc(timeRetSet);
if(~isfield(fileStats,'timeRetSet') || fileStats.timeRetSet<timeRetSet)
    fileStats.timeRetSet=timeRetSet;
end
rmInds = find(strcmp(trainFileList,testFileList{i}));
if(isfield(testParams,'numFrames2Skip'))
    rmInds = [rmInds-testParams.numFrames2Skip:rmInds+testParams.numFrames2Skip];
end
[a keepInds] =setdiff(retInds,rmInds);
keepInds = sort(keepInds);
retInds = retInds(keepInds);