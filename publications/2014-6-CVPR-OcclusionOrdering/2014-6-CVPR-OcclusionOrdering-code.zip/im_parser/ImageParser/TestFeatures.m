SetUpConstants;
if(false)%isempty(testSVMList))
    foldList = dir(fullfile(TestFold,svmFold,'*.mat'));
    for i = 1:length(foldList)
        if(~foldList(i).isdir)
            [a testSVMList{end+1}] = fileparts(foldList(i).name);
        end
    end
end

[foo LabelSetFold] = fileparts(HOMELABELSETS{1});

dataFile = fullfile(TestFold,'parsingData.mat');

[fold base] = fileparts(testFileList{1});
load(fullfile(HOMELABELSETS{1},fold,[base '.mat'])); %S (ro x co) names
Labels = cell(1);Labels{1} = names;

%{-
predictedLabels = cell(size(testSVMList));
gtLabels = cell(size(testFileList));
close all;
%{
ppdpl = cell(max(rangeTest),1);
sps = cell(max(rangeTest),1);
gt = cell(max(rangeTest),1);
for f = rangeTest(:)';
    [fold base] = fileparts(testFileList{f});
    fprintf('Working on %d: %s/%s\n',f,fold,base);
    try
        a = load(fullfile(TestFold,LabelSetFold,parserFold,fold,[base '.mat'])); %probPerLabel (#SP x #l)
        ppdpl{f} = a.probPerDescPerLabel;
        load(fullfile(HOMEDATA,'Descriptors',spFold,'super_pixels',fold,[base '.mat'])); %superPixels (ro x co)
        sps{f} = superPixels;
        %load(fullfile(HOMEDATA,'Descriptors',spFold,'sp_adjacency',fold,[base '.mat'])); %adjPairs (pairs x 2)
        load(fullfile(HOMELABELSETS{1},fold,[base '.mat'])); %S (ro x co) names
        gt{f} = S(:);
        %{
        clear im;
        try
            im = imread(fullfile(HOMEIMAGES,testFileList{f}));
        catch
            im = imread(fullfile(HOMEIMAGES,fold,[base '.jpg']));
        end
        %}
    catch
        continue;
    end
end
%}
udMask = false(size((testParams.segmentDescriptors)));
for i = 1:length(testParams.segmentDescriptors)
    addDInds = find(udMask==0);
    perLabelStats = zeros(length(names),2,length(testParams.segmentDescriptors));
    pfig = ProgressBar('computing performance');
    for f = rangeTest(:)'
        uSP = unique(sps{f});
        spMap = zeros(max(uSP),1);
        spMap(uSP) = 1:length(uSP);
        ppl = sum(ppdpl{f}(:,:,udMask),3);
        for j = addDInds
            pplu = ppl+ppdpl{f}(:,:,j);
            feat = pplu(spMap(sps{f}),:);
            [maxFeats L] = max(feat,[],2);
            [perPixelStat perLabelStat] = EvalPixelLabeling(L,names,gt{f},names);
            perLabelStats(:,:,j) = perLabelStats(:,:,j)+perLabelStat;
            L = reshape(L,size(superPixels));
        end
        ProgressBar(pfig,f,max(rangeTest));
    end
    close(pfig);
    stats = zeros(2,length(testParams.segmentDescriptors));
    for j = addDInds
        t = sum(perLabelStats(:,:,j));
        stats(1,j) = t(1)/t(2);
        t = perLabelStats(:,1,j)./perLabelStats(:,2,j);        t(isnan(t)) = 0;
        stats(2,j) = mean(t);
        fprintf('%.3f %.3f %s\n',stats(1,j),stats(2,j),testParams.segmentDescriptors{j});
    end
    [s m] = max(sum(stats));
    udMask(m) = true;
    fprintf('Adding %s\n\n',testParams.segmentDescriptors{m});
end
close(pfig);
%}

