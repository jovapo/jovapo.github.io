function  WriteALEDenseDataTerm( labelDir, fromDir, toDir )

files = dir_recurse(fullfile(fromDir,'*.mat'),0,1);

for i = 1:length(files)
    [fold base] = fileparts(files{i});
    load(fullfile(labelDir,files{i}));
    [ro co] = size(S);
    numL = length(names);
    load(fullfile(fromDir,files{i}));
    predictors = reshape(predictors,[ro co numL]);
    predictors = predictors(end:-1:1,:,:);
    predictors = permute(predictors,[3 2 1]);
    toFile = fullfile(toDir,[base '.dns']);make_dir(toFile);
    fid = fopen(toFile,'w');
    fwrite(fid,co,'int32');
    fwrite(fid,ro,'int32');
    fwrite(fid,numL,'int32');
    fwrite(fid,predictors,'double');
    fclose(fid);
    %code to check output
    %{
    fid = fopen(toFile,'r');
    co = fread(fid,1,'int32');
    ro = fread(fid,1,'int32');
    numL = fread(fid,1,'int32');
    predictors2 = fread(fid,numel(predictors),'double');
    fclose(fid);
    %}
end

end

