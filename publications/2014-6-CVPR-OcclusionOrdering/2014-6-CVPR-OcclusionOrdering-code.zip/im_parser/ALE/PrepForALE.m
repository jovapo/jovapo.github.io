if(ispc())
    HOMEDIR = 'D:\im_parser';
else
    HOMEDIR = '~/CS/im_parser/';
end

datasetDir = 'siftFlowDetector';
%datasetDir = 'LMSun';
HOME = fullfile(HOMEDIR,datasetDir);
datasetDir = 'siftFlow';

HOMEIMAGES = fullfile(HOME,'Images');
HOMELABELS = fullfile(HOME,'LabelsSemantic');
HOMEALE = fullfile(HOMEDIR,'ALE',datasetDir);
HOMEALEIMAGES = fullfile(HOMEALE,'Images');
HOMEALELABELS = fullfile(HOMEALE,'GroundTruth');

fileList = dir_recurse(fullfile(HOMEIMAGES,'*.*'),0);
testSetFile = fullfile(HOME, 'TestSet1.txt');
testFileList = sort(importdata(testSetFile));
[a testMask] = intersect(fileList,testFileList);
[fold base] = fileparts(fileList{1});
load(fullfile(HOMELABELS,fold,[base '.mat']));
labelColors = GetColors(HOME, HOMECODE, {HOMELABELS}, {names});
labelColors =labelColors{1};
if(size(labelColors,1)==length(names))
    labelColors(end+1,:) = [0 0 0];
end

if(length(unique(round(labelColors(:,1)*255)+round(labelColors(:,2)*255)*256+round(labelColors(:,3)*255)*256^2))<size(labelColors,1))
    fprintf('ERROR Same Color!\n');
    return;
end
MyCleanUp;

flabels = fopen(fullfile(HOMEALE,'Labels.txt'),'w');
for i = 1:length(names)
    fprintf(flabels,'%s\n',names{i});
end
fclose(flabels);

fcolors = fopen(fullfile(HOMEALE,'labelcolors.dat'),'w');
labelcoloruint8 = uint8(round(labelColors*255));
fwrite(fcolors,labelcoloruint8');
fclose(fcolors);


fcolors = fopen(fullfile(HOMEALE,'labelcolors.dat'),'r');
a = fread(fcolors);
fclose(fcolors);

ftest = fopen(fullfile(HOMEALE,'Test.txt'),'w');
ftrain = fopen(fullfile(HOMEALE,'Train.txt'),'w');

pfig = ProgressBar('Preping For ALE');
for i = 1:length(fileList)
    [fold base] = fileparts(fileList{i});
    savefold = [];
    %{-
    im = imread(fullfile(HOMEIMAGES,fileList{i}));
    outfile = fullfile(HOMEALEIMAGES,savefold,[base '.jpg']);make_dir(outfile);
    copyfile(fullfile(HOMEIMAGES,fileList{i}),outfile);
    %imwrite(im,outfile);
    load(fullfile(HOMELABELS,fold,[base '.mat']));
    S(S==0) = length(names)+1;
    imLabeled = labelcoloruint8(S,:);
    imLabeled = reshape(imLabeled,[size(S) 3]);
    outfile = fullfile(HOMEALELABELS,savefold,[base '.png']);make_dir(outfile);
    imwrite(imLabeled,outfile);
    %}
    if(any(testMask==i))
        fprintf(ftest,'%s.png\n',base);
    else
        fprintf(ftrain,'%s.png\n',base);
    end
    if(mod(i,10) == 0) ProgressBar(pfig,i,length(fileList)); end
end
close(pfig);
fclose(ftest);
fclose(ftrain);