
testName = 'trial';
baseFName = fullfile(fold,base);
Labels{1} = labelList;
imSP = superPixels;
MAX_COST = 10000;
MAX_EXPECTED = 10;
p = exp(objDataTerms);
ps = sum(p,2);
pn = -log(bsxfun(@rdivide,p,ps));
dataCost{1} = (max(MAX_EXPECTED,-min(objDataTerms(:)))-objDataTerms)./(MAX_EXPECTED*2);%-log(bsxfun(@rdivide,p,ps));%
dataCost{1} = int32(dataCost{1}*MAX_COST);
params.edgeParam = 11;
params.connected=8;
params.S{1} = S;
params.names{1} = names;
params.clsList = clsList;
timerVar = 0;
smoothOver = [2.^(1:5)];
for smoothing = smoothOver
    testName = sprintf('%s-SS%03d',[testSVMList{i} smoothSuffix],smoothing);
    smoothingMatrix = smoothing*(ones(length(clsList))-eye(length(clsList)));
    timerVarTic = tic;
    [LabelPixels] = MultiLevelPixMRF(fullfile(TestFold,testParams.MRFFold),HOMELABELSETS,testName,baseFName,Labels,imSP,im,dataCost,smoothingMatrix,[],params);
    timerVar=timerVar+toc(timerVarTic);
    %show(LabelPixels{1},1);
end
fieldName= ['timeMRF' num2str(i)];
avgTime = timerVar/length(smoothOver);
if(~isfield(fileStats,fieldName) || fileStats.(fieldName)<avgTime)
    fileStats.(fieldName) = avgTime;
end
save(timingFile,'fileStats');