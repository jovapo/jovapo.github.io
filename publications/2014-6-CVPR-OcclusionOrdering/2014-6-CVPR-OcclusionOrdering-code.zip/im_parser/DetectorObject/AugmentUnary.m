function unary = AugmentUnary(unary,masks,objOrder,objLs,weight)

depths = sort(unique(objOrder),'descend');
cumMask = false(size(unary,1),1);
for d = depths(:)'
    inds = find(objOrder==d);
    for o = inds(:)'
        mask = masks(:,o);
        mask(cumMask) = false;
        cumMask(mask) = true;
        %show(reshape(unary(:,objLs(o)),[600 800]),1);
        tmp = min(1,unary(mask,objLs(o))+weight);
        unary(mask,:) = max(0,unary(mask,:)-weight);
        unary(mask,objLs(o)) = tmp;
        %show(reshape(unary(:,objLs(o)),[600 800]),2);
    end
end


end

