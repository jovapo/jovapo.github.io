%Lstart = SmoothDCRFOnce(predictorCell{1},im,16);

numL = size(predictorCell{2},2);
unary = 1./(1+exp(-predictorCell{1}));
unary = -log(unary);
%{-
myStuffLs = [stuffLs; find(strcmp(names,'hill')); find(strcmp(names,'tree'))];
nonExUnaryStuff = -log(1./(1+exp(-predictorCell{2}(:,myStuffLs))));
%}

[ro co ch] = size(im);
imSize.ro = ro;
imSize.co = co;
sp = imresize(-log(spatialPrior),[ro co],'nearest');
sp = reshape(sp,size(unary));

w = [4]%
saveInfo.HOMEDATA = fullfile(TestFold,testParams.MRFFold);
saveInfo.HOMELABELSET = HOMELABELSETS{1};
saveInfo.testName = sprintf('DCRF-Sig-%s-w%02d',svmName,w);
saveInfo.baseFName = fullfile(fold,base);
saveInfo.Labels = Labels{1};
saveInfo.names = names;
saveInfo.S = S;

pNPot = [];
pNPot.index = cell(0);
pNPot.costs = [];
pNPot.Q = [];
converge = 0;
sw = .1;
[L0 timerVar] = SmoothCRF(im,unary+sp.*sw,[],w,saveInfo);
fileStats.(['DCRF' num2str(i)]) = timerVar;
save(timingFile,'fileStats');
%DrawImLabels(im,L0,labelColors{1},names,[],1,0,1);

LExcStuff = SmoothCRF(im,unary(:,myStuffLs)+sp(:,myStuffLs).*sw,[],w);
LnonExcStuff = SmoothCRF(im,nonExUnaryStuff+sp(:,myStuffLs).*sw,[],w);
%
make_dir(fullfile(TestFold,'StuffParse',[base '.jpg']));
imwrite(im,fullfile(TestFold,'StuffParse',[base '.jpg']));
DrawImLabels(im,myStuffLs(LExcStuff),labelColors{1},names,fullfile(TestFold,'StuffParse',[base 'x.png']),1,0,1);
DrawImLabels(im,myStuffLs(LnonExcStuff),labelColors{1},names,fullfile(TestFold,'StuffParse',[base 'nx.png']),1,0,1);
