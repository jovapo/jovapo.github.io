function olScore = TestObjHypothesis(mask,S_instances,instNdx)

m1 = double(mask);
m2 = double(S_instances(:,instNdx));
rawPixOl = m1'*m2;
ps1 = sum(m1);
ps2 = sum(m2);
overlap = rawPixOl./(repmat(ps1',[1 length(ps2)])+repmat(ps2,[length(ps1) 1])-rawPixOl);

olScore = zeros(size(S_instances,2),1);
olScore(instNdx) = overlap;

end

