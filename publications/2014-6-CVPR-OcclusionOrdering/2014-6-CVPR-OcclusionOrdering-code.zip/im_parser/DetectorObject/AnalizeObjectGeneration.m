SetUpConstants;


overlapThresh = [.3];
maskRange = [.5];
%{
allResults = cell(size(testFileList));
for f = 1:length(testFileList)
    [fold base ext] = fileparts(testFileList{f});
    saveFile = fullfile(TestFold,'QuantitativeClusterTests2',fold,[base '.mat']);
    if(exist(saveFile,'file'))
        load(saveFile);
        allResults{f} = result;        
    end
end
%}

rmInd = cellfun(@(x) isempty(x),allResults);
allResults(rmInd) = [];
instL = cell2mat(cellfun2(@(x) x.instL,allResults));
fields1 = fieldnames(allResults{1});
fields1 = setdiff(fields1,{'fold','base','instL'});

rawResult = cell(0);
testName = cell(0);
numC = zeros(0);

for i = 1:length(fields1)
    fields2 = fieldnames(allResults{1}.(fields1{i}));
    fields2 = setdiff(fields2,{'name','numC'});
    for j = 1:length(fields2)
        rmIndx = find(cellfun(@(x) ~isfield(x.(fields1{i}),fields2{j}),allResults));
        if(~isempty(rmIndx))
            for k = rmIndx(:)'
                delete(fullfile(TestFold,'QuantitativeClusterTests2',allResults{k}.fold,[allResults{k}.base '.mat']));
            end
            allResults(rmIndx) = [];
        end
        rawResult{end+1} = cell2mat(cellfun2(@(x) x.(fields1{i}).(fields2{j}),allResults));
        testName{end+1} = [allResults{1}.(fields1{i}).name ' ' fields2{j}];
        numC(end+1) = sum(cellfun(@(x) x.(fields1{i}).numC,allResults));
    end
end

if(exist('stuffLs','var'))
    rmStf = false(size(instL));
    for l = stuffLs(:)'
        rmStf(instL==l) = true;
    end
    instL(rmStf) = [];
    for i = 1:length(rawResult)
        rawResult{i}(rmStf) = [];
    end
end


outFile = fullfile(TestFold,'QuantitativeClusterTests2','results_mean.txt');
fid = fopen(outFile,'w');
mm = @mean

[l, c] = UniqueAndCounts(instL);
[counts, ndx] = sort(c,'descend');
usedL = l(ndx);

fprintf(fid,'Label\t');
for i = 1:length(rawResult)
    fprintf(fid,'%s\t',testName{i});
end
fprintf(fid,'\n');

fprintf(fid,'%s\t','Number of Clusters');
fprintf(fid,'%d\t',numC);
fprintf(fid,'\n');

fprintf(fid,'%s\t','Total');
for i = 1:length(rawResult)
    fprintf(fid,'%.3f\t',mm(rawResult{i}));
end
fprintf(fid,'\n');

for l = usedL(:)'
    fprintf(fid,'%s\t',names{l});
    fprintf(fid,'%d\t',sum(instL==l));
    for i = 1:length(rawResult)
        fprintf(fid,'%.3f\t',mm(rawResult{i}(instL==l)));
    end
    fprintf(fid,'\n');
end
fclose(fid);

