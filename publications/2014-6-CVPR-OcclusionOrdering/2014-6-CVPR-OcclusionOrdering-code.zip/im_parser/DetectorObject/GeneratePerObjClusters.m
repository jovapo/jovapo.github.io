%function [objDataTerms clsList] = GeneratePerObjDataTerms(trainedSVM,feat,predictors,test_struct,polygons)

backOutString = '../';
if(isempty(fold))
    fold = '.';
    backOutString = '';
else
    [fo bo] = fileparts(fold);
    if(~isempty(fo))
        backOutString = '../../';
    end
end

ObjectWebFold = fullfile(TestFold,'Web-Cluster');

ImageWebFold = fullfile(ObjectWebFold,'ImageWeb');
imageWebPage = fullfile(ImageWebFold,fold,[base '.htm']);make_dir(imageWebPage);
imFID = fopen(imageWebPage,'w');
fprintf(imFID,'<HTML>\n<HEAD>\n<TITLE>%s %s</TITLE>\n</HEAD>\n<BODY>',fold,base);
fprintf(imFID,'<img  width="256" src="%s"><br> ',['../' backOutString 'Images/' fold '/' base ext]);

fprintf(imFID,'\n<table border="0">\n');
fprintf(imFID,'\t<tr>\n');

numL = size(predictors,2);
[a topL] = max(predictors,[],2);
usedL = unique(topL);
clsList = [];
objDataTerms = cell(0);

objDataTermsRaw = cell(0);
objDataTermsRawWarped = cell(0);

labelBBS = test_struct.final_boxes;
overlap = .3;

%pb = imread(fullfile(HOMEDESCRIPTOR,'Pb','globalPb',fold,[base '.png']));
%pb = double(pb)/max(double(pb(:)));
[ro co ch] = size(im);

dataTerm = cell(3,1);
bbcount = cellfun(@(x) size(x,1),labelBBS);
[~, labelOrder] = sort(bbcount,'descend');

for l = labelOrder(1:10)%find(strcmp(Labels{1},'car'))% 
%for l = [ 40 201 34]%usedL(:)'
    fprintf('Splitting: %s\n',names{l});
    boxes = labelBBS{l};
    if(isempty(boxes))
        continue;
    end
    clusters = cell(0);
    x1 = boxes(:,1);
    y1 = boxes(:,2);
    x2 = boxes(:,3);
    y2 = boxes(:,4);
    s = boxes(:,end);

    area = (x2-x1+1) .* (y2-y1+1);
    [vals, I] = sort(s);

    pick = s*0;
    counter = 1;
    nmsT = zeros(size(s));
    while ~isempty(I)
      last = length(I);
      bbNdx = I(last);  
      pick(counter) = bbNdx;
      counter = counter + 1;

      xx1 = max(x1(bbNdx), x1(I(1:last-1)));
      yy1 = max(y1(bbNdx), y1(I(1:last-1)));
      xx2 = min(x2(bbNdx), x2(I(1:last-1)));
      yy2 = min(y2(bbNdx), y2(I(1:last-1)));

      w = max(0.0, xx2-xx1+1);
      h = max(0.0, yy2-yy1+1);

      o = w.*h ./ area(I(1:last-1));

      clusters{end+1,1} = I([last; find(o>overlap)]);
      nmsT(I([last; find(o>overlap)])) = counter-1;
      I([last; find(o>overlap)]) = [];
    end
    
    
    
    polygonsout = ProjectDetectorPolygons(boxes, polygons);
    %{-
    olScore = [];
    olName{1} = 'NMS Clustering';olFileSuffix{1} = 'NMS';
    tic;olScore{2} = OverlapBBIntUn(boxes);toc
    olName{2} = 'BB Int/Union';olFileSuffix{2} = 'BBIU';
    tic;olScore{3} = OverlapPolygonIntUn(polygonsout);toc
    olName{3} = 'Poly Int/Union';olFileSuffix{3} = 'PIU';
    tic;olScore{4} = OverlapPolygonBIntUn(polygonsout,max(size(im))/128,max(size(im))/128);toc
    olName{4} = 'Poly Boundary Int/Union 6 6';olFileSuffix{4} = 'PBIU66';
    tic;olScore{5} = OverlapPolygonBIntUn(polygonsout,0,max(size(im))/16);toc
    olName{5} = 'Poly Boundary Int/Union 0 50';olFileSuffix{5} = 'PBIU050';
    tic;olScore{6} = OverlapPolygonBDist(polygonsout,max(size(im))/128);toc
    olName{6} = 'Poly Boundary Distance 6';olFileSuffix{6} = 'PBD6';
    d = cell2mat(cellfun2(@(x) x(:),olScore(2:end)));
    %}
    for i = 2:length(olScore);   
        olScore{i}=olScore{i}./max(olScore{i}(:));
        olScore{i}=olScore{i}./median(diag(olScore{i}));
        olScore{i}=min(olScore{i},1);
        olScore{i}=olScore{i} - diag(diag(olScore{i})) + eye(size(olScore{i}));
    end
    %{
    corrcoef(d)
    for i = 1:length(olScore);   
        show(olScore{i},i);    
        sum(sum(olScore{i}>overlap*max(olScore{i}(:))))    
    end
    %}
    
    saveFileNameBase = fullfile(fold,base,Labels{1}{l});
    saveFileNameWebBase = [ base '/' Labels{1}{l}];
    c = 1;
    for os = 1:length(olScore)
        if(os==1)
            T = nmsT;
        else
            Z = linkage(squareform(1-olScore{os}'),'average');
            %dendrogram(Z,0);
            %T = cluster(Z,'cutoff',c);
            T = cluster(Z,'cutoff',1-overlap,'criterion','distance');
        end
        %sort clusters
        clScore = arrayfun(@(x) sum(1+s(T==x)),unique(T));
        %[~, clCount] = UniqueAndCounts(T);
        [clScore, clOrdered] = sort(clScore,'descend');
        clMap = zeros(size(clOrdered));
        clMap(clOrdered) = 1:length(clOrdered);
        T = clMap(T);
        
        %remove clusters
        a = find((clScore/max(clScore))<.1,1);
        if(~isempty(a)); T(T>=a) = 0; end
        
        colors = 'grbymcwkgrbymcwkgrbymcwkgrbymcwkgrbymcwkgrbymcwkgrbymcwkgrbymcwkgrbymcwkgrbymcwkgrbymcwkgrbymcwkgrbymcwkgrbymcwkgrbymcwkgrbymcwkgrbymcwkgrbymcwkgrbymcwkgrbymcwkgrbymcwkgrbymcwkgrbymcwkgrbymcwkgrbymcwkgrbymcwkgrbymcwkgrbymcwkgrbymcwkgrbymcwk';
        colors = uint8([255 0 0; 0 255 0; 0 0 255; 255 255 0; 255 0 255; 0 255 255; 0 0 0; 255 255 255]);
        figure(1);clf;show(im,1);figure(1);hold on;
        for j = 1:min(max(T),8)
            detNdxs = find(T==j);
            for k = detNdxs(:)'
                if(boxes(k,3)-boxes(k,1) <=0 || boxes(k,4)-boxes(k,2) <= 0)
                    continue;
                end
                %rectangle( 'Position',[boxes(k,1) boxes(k,2) boxes(k,3)-boxes(k,1) boxes(k,4)-boxes(k,2)],'LineWidth',2,'EdgeColor',colors(j));%'g');%
                patch(polygonsout(k).x,polygonsout(k).y,'r','FaceColor','none','EdgeColor',double(colors(mod(j-1,8)+1,:))/255,'LineWidth',1)
            end
        end
        
        imFileName = fullfile(ImageWebFold,[saveFileNameBase '-' olFileSuffix{os} '.png']);make_dir(imFileName);
        export_fig(imFileName);%'-nocrop',
        fprintf(imFID,'\t\t<td><center>%s<br><img  width="256" src="%s"><br>\n',Labels{1}{l},[saveFileNameWebBase '-' olFileSuffix{os} '.png']);
        fprintf(imFID,'%s <br>',olName{os});%</center></td>
        
        maxD = 0;
        scolors = [];
        shapes = cell(0);
        for j = 1:min(max(T),8)
            detNdxs = find(T==j);
            dataTerm{j} = zeros(ro,co);
            for k = detNdxs(:)'
                mask = poly2mask(polygonsout(k).x,polygonsout(k).y,ro,co);
                dataTerm{j} = dataTerm{j} + mask.*(boxes(k,end)+1);
            end
            mask = dataTerm{j}>(max(dataTerm{j}(:))*.5);
            b = bwboundaries(mask);
            if(length(b) > 0)
                scolors = [scolors; colors(mod(j-1,8)+1,:)];
                shapes{end+1} = b{1}(:,[2 1])';
                shapes{end} = shapes{end}(:);
            end
        end
        poly = zeros(length(shapes),max(cellfun(@(x) length(x),shapes)));
        figure(1);clf;show(im,1);figure(1);hold on;
        for j = 1:length(shapes)
            poly(j,1:length(shapes{j})) = shapes{j};
            poly(j,length(shapes{j})+1:end) = repmat(shapes{j}(end-1:end),[(size(poly,2)-length(shapes{j}))/2,1]);
            
            patch(shapes{j}(1:2:end),shapes{j}(2:2:end),'r','FaceColor','none','EdgeColor',double(scolors(j,:))/255,'LineWidth',3)
        end
        %shapeInserter = vision.ShapeInserter('Shape','Polygons','BorderColor','Custom', 'CustomBorderColor', scolors);
        %pim = step(shapeInserter,im,int32(round(poly)));
        
        imFileName = fullfile(ImageWebFold,[saveFileNameBase '-' olFileSuffix{os} '-50.png']);make_dir(imFileName);
        export_fig(imFileName);%'-nocrop',
        %imwrite(pim,imFileName);
        fprintf(imFID,'\t\t<img width="256" src="%s"><br>\n',[saveFileNameWebBase '-' olFileSuffix{os} '-50.png']);
        fprintf(imFID,'</center></td>');%</center></td>
    end
    
    
    fprintf(imFID,'\t</tr><tr>\n');
end
fprintf(imFID,'\t</tr>\n</table></center>');
fprintf(imFID,'</BODY>\n</HTML>');
fclose(imFID);