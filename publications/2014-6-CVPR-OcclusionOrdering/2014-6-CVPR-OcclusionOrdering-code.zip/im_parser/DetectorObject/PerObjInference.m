
if(web)
    try for i = 4:100;fclose(i);fprintf('closed %d\n',i);end;catch ERR;end
    backOutString = '../';
    if(isempty(fold))
        fold = '.';
        backOutString = '';
    else
        [fo bo] = fileparts(fold);
        if(~isempty(fo))
            backOutString = '../../';
        end
    end
    if(~exist('ObjectWebFold','var'))
        ObjectWebFold = fullfile(TestFold,'Web-ObjInference');
    end
    ImageWebFold = fullfile(ObjectWebFold,'ImageWeb');
    imageWebPage = fullfile(ImageWebFold,fold,[base '.htm']);make_dir(imageWebPage);
    imFID = fopen(imageWebPage,'w');
    fprintf(imFID,'<HTML>\n<HEAD>\n<TITLE>%s %s</TITLE>\n</HEAD>\n<BODY>',fold,base);
    fprintf(imFID,'\n<table border="0">\n');
    fprintf(imFID,'\t<tr>\n');
    fprintf(imFID,'<td><img  src="%s"></td>',['../' backOutString 'Images/' fold '/' base ext]);
    make_dir(fullfile(ObjectWebFold,'Smoothing',fold,[base '.png']));
    outFile = fullfile(ObjectWebFold,'Smoothing',fold,[base '.png']);
    DrawImLabels(im,sResult.L,labelColors{1},names,outFile,1,0,1,800);
    fprintf(imFID,'<td><img  src="%s"></td></tr><tr>',['../' backOutString 'Smoothing/' fold '/' base '.png']);
end


beta = 1;
svmCutoff = -1;
betaCutoff = 1/(1+exp(-beta*svmCutoff));
labelTermCutoff = .25;
numL = size(predictorCell{2},2);
posLabels = find(sum(predictorCell{2}>svmCutoff)>0);
labelBBS = test_struct.final_boxes;
overlapScore = .3;
[ro co ch] = size(im);
[maxP maxPL] = max(predictorCell{2},[],2);
%show(reshape(maxP,[ro co]),1);show(reshape(maxPL,[ro co]),2);

if(~exist('overlapStats','var'))
    load(fullfile(HOME,'overlap.mat'));
end
pixOverlapLikelihood = overlapStats.overlapPixel;
pixOverlapLikelihood = pixOverlapLikelihood-diag(diag(pixOverlapLikelihood))+100*eye(size(pixOverlapLikelihood));
pixOverlapLikelihood = pixOverlapLikelihood./repmat(sum(pixOverlapLikelihood,1),[232 1]);
pixOverlapLikelihood = pixOverlapLikelihood-diag(diag(pixOverlapLikelihood));
pixOverlapLikelihood = pixOverlapLikelihood+eye(size(pixOverlapLikelihood));
%{-
objNdx = 1;
masks = cell(1,0);
objDataTerm = cell(0,1);
objClustScore = cell(0,1);
objLabelTerm = cell(0,1);
objLabel = cell(0,1);
objCutoff = cell(0,1);
maskRange = [.5];
posLabels = find(strcmp(names,'car'));


%ucm =imread(fullfile(HOMEDESCRIPTOR,'Pb','globalPb',fold,[base '.png']));
%gPb = max(gPb_orient, [], 3);
%gPb_thin = gPb .* (ucm>0);
%gPb_thin = gPb_thin .* bwmorph(gPb_thin, 'skel', inf);
for l = posLabels(:)'
    boxes = labelBBS{l};
    if(length(boxes)==0)
        continue;
    end
    polygonsout = ProjectDetectorPolygons(boxes, polygons);
    olScore = OverlapPolygonBIntUn(polygonsout,0,max(size(im))/16);
    
    olScore=olScore./max(olScore(:));
    olScore=olScore./median(diag(olScore));
    olScore=min(olScore,1);
    olScore=olScore - diag(diag(olScore)) + eye(size(olScore));
    
    Z = linkage(squareform(1-olScore'),'average');
    %dendrogram(Z,0);
    %T = cluster(Z,'cutoff',c);
    T = cluster(Z,'cutoff',1-overlapScore,'criterion','distance');
    if(size(boxes,1)<length(T))
        T(size(boxes,1)+1:end) = [];
    end
    for j = 1:max(T)
        detNdxs = find(T==j);
        clMask = zeros(ro,co);
        score = 0;
        for k = detNdxs(:)'
            m = poly2mask(polygonsout(k).x,polygonsout(k).y,ro,co);
            clMask = clMask + m.*(boxes(k,end)+1);
            score = score + (boxes(k,end)+1);
        end
        for mr = 1:length(maskRange)
            masks{objNdx,1} = clMask(:)'>(max(clMask(:))*maskRange(mr));
            if((objNdx>1 && all(masks{objNdx}==masks{objNdx-1}))|| sum(masks{objNdx,1}(:))<20); 
                continue; 
            end
            objDataTerm{objNdx,1} = mean(1./(1+exp(-beta*predictorCell{2}(masks{objNdx},l))));
            objLabelTerm{objNdx,1} = mean(pixOverlapLikelihood(l,smoothL(masks{objNdx})));
            objClustScore{objNdx,1} = score;
            %objDataTerm{objNdx,2} =1./(1+exp(-beta* mean(predictorCell{2}(masks{objNdx},l))));
            if(objDataTerm{objNdx}<(betaCutoff) || objLabelTerm{objNdx}<labelTermCutoff); 
                continue; 
            end
            RefineMask(im,clMask>(max(clMask(:)).*maskRange(mr)),clMask,reshape(predictorCell{2}(:,l),[size(im,1) size(im,2)]),gPb_thin);
            objDataTerm{objNdx} = objDataTerm{objNdx};
            objLabel{objNdx,1} = l;
            objCutoff{objNdx,1} = maskRange(mr);
            objNdx = objNdx + 1;
            
        end
    end
end

masks = masks(1:length(objLabel));
objDataTerm = objDataTerm(1:length(objLabel));
objLabelTerm = objLabelTerm(1:length(objLabel));
objClustScore = objClustScore(1:length(objLabel));

objLabel = cell2mat(objLabel);
[ind] = find(overlapStats.labelOrderHist(objLabel,1)>0&sum(overlapStats.labelOrderHist(objLabel,2:end),2)==0);%
bkLs = intersect(unique(sResult.L(:)),find(overlapStats.labelOrderHist(:,1)>0 & sum(overlapStats.labelOrderHist(:,2:end),2)==0));
masks(ind) = [];
objDataTerm(ind) = [];
objLabelTerm(ind) = [];
objClustScore(ind) = [];
objLabel(ind) = [];
for l = bkLs(:)'
    m = sResult.L(:)' == l;
    if(sum(m)>0)
        masks{end+1} = m;
        objDataTerm{end+1,1} = mean(1./(1+exp(-beta*predictorCell{2}(masks{end},l))));
        objLabelTerm{end+1,1} = mean(pixOverlapLikelihood(l,smoothL(masks{end})));
        objClustScore{end+1,1} = 1;
        objCutoff{end+1} = 0;
        objLabel(end+1) = l;
    end
end
    
masks = cell2mat(masks(end:-1:1));
objDataTerm = cell2mat(objDataTerm(end:-1:1));
objLabelTerm = cell2mat(objLabelTerm(end:-1:1));
objClustScore = cell2mat(objClustScore(end:-1:1));
objCutoff = cell2mat(objCutoff(end:-1:1));
objLabel = objLabel(end:-1:1);


maskSize = sum(masks,2);
overlapPixels = single(masks)* single(masks');
%}

overlapScore = overlapPixels./min(repmat(maskSize,[1 length(maskSize)]),repmat(maskSize',[length(maskSize) 1]));
%overlapScore = maskIntersect./(repmat(maskSize',[1 length(maskSize)])+repmat(maskSize,[length(maskSize) 1])-maskIntersect);
overlapBehindHist = overlapStats.overlapBehindHist;
overlapBehindHist = overlapBehindHist(:,:,2:end);
overlapBehindHist(:,:,end) = overlapBehindHist(:,:,end) - diag(diag(overlapBehindHist(:,:,end)));
overlapBehindHist = overlapBehindHist+1;
numBins = 10;
blocks =  BlockRange(size(overlapBehindHist,3),numBins);
for i = 1:numBins;
    overlapBehindHist(:,:,i) = sum(overlapBehindHist(:,:,blocks(i,1):blocks(i,2)),3);
end
overlapBehindHist(:,:,numBins+1:end) = [];
g = exp((-(-2:2).^2)./2);g = g./sum(g);
overlapBehindHist = g(1).*overlapBehindHist(:,:,[1 1 1:end-2]) + g(2).*overlapBehindHist(:,:,[1 1:end-1])+g(3).*overlapBehindHist+g(4).*overlapBehindHist(:,:,[2:end end])+g(5).*overlapBehindHist(:,:,[3:end end end]);
sumO = sum(overlapBehindHist,3);
%overlapBehindHist = log(overlapBehindHist./(repmat(sumO,[1 1 size(overlapBehindHist,3)])+repmat(sumO',[1 1 size(overlapBehindHist,3)])-overlapBehindHist));
overlapBehindHist = overlapBehindHist./(50+repmat(sumO,[1 1 size(overlapBehindHist,3)])+repmat(sumO',[1 1 size(overlapBehindHist,3)]));

labelPrior = sResult.L;




clear in;
in.im = im;
in.masks = masks;
in.objDataTerm = objDataTerm;
in.objLabelTerm = objLabelTerm;
in.objClustScore = objClustScore;
in.objLabel = objLabel;
in.overlapPixels = overlapPixels;
in.overlapScore = overlapScore;
in.overlapBehindHist = overlapBehindHist;
in.labelOrderHist = overlapStats.labelOrderHist;
in.names = names;
in.masks = masks;
in.labelColors = labelColors{1};
in.maskSize = maskSize;
in.objCutoff = objCutoff;
if(web)
    in.ObjectWebFold = ObjectWebFold;
    in.imFID = imFID;
    in.fold = fold;
    in.base = base;
end

ObjectMRF(in);

%{
CurrEnergy = 0;
L = zeros(size(maskSize));
while(true)
    avlNdx = find(L==0);
    ls = unique(L)+.5;
    Energy = zeros(length(avlNdx),length(ls));
    for i = 1:length(avlNdx)
        for j = 1:length(ls)
            l = L;
            l(avlNdx(i)) = ls(j);
            Energy(i,j) = ComputePerObjEnergy(l,objDataTerm,overlapScore,overlapPixels,objLabel,overlapBehindHist,labelPrior);
        end
    end
    [MaxE,ind] = max(Energy(:));
    if(MaxE<CurrEnergy)
        break;
    end
    CurrEnergy = MaxE;
    [i, j] = ind2sub(size(Energy),ind);
    if(round(ls(j)-.5)>0&& all(overlapScore(L==round(ls(j)-.5),avlNdx(i))==0))
        L(avlNdx(i)) = round(ls(j)-.5);
    elseif(round(ls(j)+.5)<=max(L)&& all(overlapScore(L==round(ls(j)+.5),avlNdx(i))==0))
        L(avlNdx(i)) = round(ls(j)+.5);
    else
        L(L>ls(j)) = L(L>ls(j)) + 1;
        L(avlNdx(i)) = round(ls(j)+.5);
    end
    
    if(display)
        [a, objOrder] = sort(L);
        objOrder(a<1) = [];
        show(im,1);hold on;
        for i = objOrder(:)'
            b = bwboundaries(reshape(masks(i,:),[ro co]));
            patch(b{1}(:,2),b{1}(:,1),'r','FaceColor','none','EdgeColor',labelColors{1}(objLabel(i),:),'LineWidth',2);
        end
        legend(Labels{1}(objLabel(objOrder)));hold off;drawnow;
    end
end
    

%}