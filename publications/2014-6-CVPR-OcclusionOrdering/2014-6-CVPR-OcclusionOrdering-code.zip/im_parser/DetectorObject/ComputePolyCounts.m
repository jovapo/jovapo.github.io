function [ polyCounts ] = ComputePolyCounts( fileList, HOMEANNOTATIONS, numLabels )

close all;
polyCounts = zeros(numLabels,20);
pfig = ProgressBar('Computing Poly Counts');
for f = 1:length(fileList)
    [fold, base] = fileparts(fileList{f});
    [annraw] = LMread(fullfile(HOMEANNOTATIONS,fold,[base '.xml']));
    if(~isfield(annraw,'object'))
        continue;
    end
    [l c] = UniqueAndCounts(cellfun(@(x) str2double(x),{annraw.object.namendx}));
    if(max(c)>size(polyCounts,2))
        polyCounts(1,max(c)) = 0;
    end
    for i = 1:length(l)
        polyCounts(l(i),c(i)) = polyCounts(l(i),c(i))+1;
    end
    if(mod(f,100) == 0)
        ProgressBar(pfig,f,length(fileList));
    end
end
close(pfig);