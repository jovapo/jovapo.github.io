SetUpConstants;

web=true;
if(web)
    MyCleanUp;
    ObjectWebFold = fullfile(TestFold,'Web-Cluster');
    webIndex = fullfile(ObjectWebFold,'bad.htm'); make_dir(webIndex);
    indexFID = fopen(webIndex,'w');
    fprintf(indexFID,'\n<center>\n');
    fprintf(indexFID,'\n<table border="0">\n');
    fprintf(indexFID,'\t<tr>\n');

    numCols = 6;
    colCount = 0;
end


if(isempty(testSVMList))
    foldList = dir(fullfile(TestFold,svmFold,'*.mat'));
    for i = 1:length(foldList)
        if(~foldList(i).isdir)
            [a testSVMList{end+1}] = fileparts(foldList(i).name);
        end
    end
end

[foo LabelSetFold] = fileparts(HOMELABELSETS{1});

dataFile = fullfile(TestFold,'parsingData.mat');

[fold base] = fileparts(testFileList{1});
load(fullfile(HOMELABELSETS{1},fold,[base '.mat'])); %S (ro x co) names
Labels = cell(1);Labels{1} = names;

%{-
predictedLabels = cell(size(testSVMList));
gtLabels = cell(size(testFileList));
close all;
pfig = ProgressBar('Loading SVM test data');
for f = [ 1 103 146 132]%rangeTest(:)';
    [fold base ext] = fileparts(testFileList{f});
    
    if(web)
        imageToFold = fullfile(ObjectWebFold,'Images',fold,[base ext]);make_dir(imageToFold);
        copyfile(fullfile(HOME,'Images',testFileList{f}),imageToFold);
        fprintf(indexFID,'\t\t<td><center> <a href="%s">',['ImageWeb/' fold '/' base '.htm']);
        fprintf(indexFID,'<img  width="200" src="%s"></a> ',['Images/' fold '/' base ext]);
        fprintf(indexFID,'</center> </td>\n');
        colCount = colCount +1;
        if(colCount == numCols)
            colCount = 0;
            fprintf(indexFID,'\t</tr><tr>\n');
        end
    end
    
    %{
    busyFile = fullfile(TestFold,testParams.MRFFold,'BusyFiles',fold,[base '.mat']);make_dir(busyFile);
    if(exist(busyFile,'file'))
        fprintf('Busy %d: %s/%s\n',f,fold,base);
        continue;
    end
    a = 1; save(busyFile,'a');
    %}
    timingFile = fullfile(TestFold,'Timing',fold,[base '.mat']);make_dir(timingFile);
    if(exist(timingFile,'file'))
        load(timingFile);
    else
        fileStats = [];
    end
    
    fprintf('Working on %d: %s/%s\n',f,fold,base);
    try
        load(fullfile(TestFold,'ExemplarDataTerm',detectorFold,fold,[base '.mat'])); %dataTerm (ro x co x #l) dataTermMax
    	load(fullfile(TestFold,'ExemplarDetectionResults',detectorFold,fold,[base '.mat'])); % test_struct polygons
        a = load(fullfile(TestFold,LabelSetFold,parserFold,fold,[base '.mat'])); %probPerLabel (#SP x #l)
        if(isfield(a,'probPerLabel'))
            probPerLabel = a.probPerLabel;
        elseif(isfield(a,'prob'))
            probPerLabel = a.prob;
        end
        load(fullfile(HOMEDATA,'Descriptors',spFold,'super_pixels',fold,[base '.mat'])); %superPixels (ro x co)
        load(fullfile(HOMEDATA,'Descriptors',spFold,'sp_adjacency',fold,[base '.mat'])); %adjPairs (pairs x 2)
        load(fullfile(HOMELABELSETS{1},fold,[base '.mat'])); %S (ro x co) names
        clear im;
        try
            im = imread(fullfile(HOMEIMAGES,testFileList{f}));
        catch
            im = imread(fullfile(HOMEIMAGES,fold,[base '.jpg']));
        end
    catch
        continue;
    end
    uSP = unique(superPixels);
    spMap = zeros(max(uSP),1);
    spMap(uSP) = 1:length(uSP);
    feat = probPerLabel(spMap(superPixels),:);
    feat = [feat reshape(dataTerm,[],size(dataTerm,3))];
    featSP = zeros(length(uSP),size(feat,2));
    for i = 1:length(uSP)
        featSP(i,:) = mean(feat(superPixels==uSP(i),:));
    end
    label = S(:);
    %feat(label==0,:) = [];
    labelAll = label;
    label(label==0) = [];
    gtLabels{f} = label;
    labelList = names;
    numLs = length(names);    
    saveFile = fullfile(TestFold,testParams.MRFFold,LabelSetFold,'SuperParsing',fold,[base '.mat']);make_dir(saveFile);
    if(~exist(saveFile,'file'))
        [maxFeats pl] = max(feat(:,1:numLs),[],2);
        L = reshape(pl,size(superPixels));
        OutputLabeling(saveFile,L,labelList,S,names);
    end
    saveFile = fullfile(TestFold,testParams.MRFFold,LabelSetFold,'DetectorScore',fold,[base '.mat']);make_dir(saveFile);
    if(~exist(saveFile,'file'))
        [maxFeats pl] = max(feat(:,1+numLs:end),[],2);
        L = reshape(pl,size(superPixels));
        OutputLabeling(saveFile,L,labelList,S,names);
    end
    for i = 1:length(testSVMList)
        
        saveFile = fullfile(TestFold,testParams.MRFFold,LabelSetFold,testSVMList{i},fold,[base '.mat']);make_dir(saveFile);
        saveFileObj = fullfile(TestFold,testParams.MRFFold,LabelSetFold,[testSVMList{i} '-obj'],fold,[base '.mat']);make_dir(saveFileObj);
        saveFileObjThing = fullfile(TestFold,testParams.MRFFold,LabelSetFold,[testSVMList{i} '-obj-thing'],fold,[base '.mat']);make_dir(saveFileObj)
        objDataTermFile = fullfile(TestFold,'PerObjDataTerms',detectorFold,testSVMList{i},fold,[base '.mat']);make_dir(objDataTermFile);
        %saveFileSP = fullfile(TestFold,testParams.MRFFold,LabelSetFold,[testSVMList{i} '-SP'],fold,[base '.mat']);make_dir(saveFileSP);
        pFile = fullfile(TestFold,svmFold,testSVMList{i},'Predictors',fold,[base '.mat']);
        svmFile = fullfile(TestFold,svmFold,[testSVMList{i} '.mat']);
        trainedSVM = load(svmFile);
                    
            if(exist(pFile,'file'))
                load(pFile);
            else
                if(exist(svmFile,'file'))
                    timerVar=tic;[rates, pl, predictors] = MySVMTestInMem(feat,labelAll,trainedSVM.svm,1024^3);timerVar=toc(timerVar);
                    fileStats.(['timeSVM' num2str(i)]) = timerVar;
                    save(timingFile,'fileStats');
                end
                L = reshape(pl,size(superPixels));
                OutputLabeling(saveFile,L,labelList,S,names);
                %L = plSP(superPixels);
                %OutputLabeling(saveFileSP,L,labelList,S,names);
                make_dir(pFile);save(pFile,'predictors','-v7.3');
            end
            %SmoothDetectorSVM;
        %if(~exist(saveFileObjThing,'file'))
            clear objDataTerms clsList;
            GeneratePerObjClusters;
            %{
            if(~exist(objDataTermFile,'file'))
                %[objDataTerms clsList] = GeneratePerObjDataTerms(trainedSVM,feat,predictors,test_struct,polygons);
                GeneratePerObjDataTerms;
                save(objDataTermFile, 'objDataTerms','clsList','-v7.3');
            else
                load(objDataTermFile);
            end
            try
                objDataTerms = cell2mat(objDataTerms);
                [a mndx] = max(objDataTerms,[],2);
                L = reshape(clsList(mndx),size(superPixels));
                OutputLabeling(saveFileObj,L,labelList,S,names,reshape(mndx,size(superPixels)),clsList);
            catch
                GeneratePerObjDataTerms;
                save(objDataTermFile, 'objDataTerms','clsList','-v7.3');
                objDataTerms = cell2mat(objDataTerms);
                [a mndx] = max(objDataTerms,[],2);
                L = reshape(clsList(mndx),size(superPixels));
                OutputLabeling(saveFileObj,L,labelList,S,names,reshape(mndx,size(superPixels)),clsList);
            end
            sl = importdata(fullfile(HOME,'StuffLabels.txt'));
            [~, stuffLs] = intersect(names,sl);
            rmndx = ismember(clsList,stuffLs);
            addLs = unique(clsList(rmndx));
            clsList(rmndx) = [];
            objDataTerms(:,rmndx) = [];
            objDataTerms = [predictors(:,addLs) objDataTerms];
            clsList = [addLs clsList];
            [a mndx] = max(objDataTerms,[],2);
            mndx = reshape(mndx,size(superPixels));
            L = clsList(mndx);
            OutputLabeling(saveFileObjThing,L,labelList,S,names,mndx,clsList);
            smoothSuffix = '-obj-thing';
            SmoothDetectorSVMObj;
            SmoothDetectorSVM;
            clear objDataTerms clsList;
            %}
        %end
    end
    ProgressBar(pfig,f,length(testFileList));
end
close(pfig);
if(web)
    fprintf(indexFID,'\t</tr>\n</table></center>');
    fclose(indexFID);
end

%}

