function [ overlapStats ] = ComputePolyOverlapStats( fileList, HOMEIMAGES, HOMEANNOTATIONS, numLabels )

close all;
numBins = 101;
parstep =  200;
maxLayers = 20;
sizeBins= 100;

overlapStats.pixelCount = zeros(numLabels,1);
overlapStats.polyCount = zeros(numLabels,1);
overlapStats.labelOrderHist = zeros(numLabels,maxLayers);
overlapStats.labelSizeHist = zeros(numLabels,sizeBins);
overlapStats.overlapPixel = zeros(numLabels,numLabels);
overlapStats.overlapAvgScore = zeros(numLabels,numLabels);
overlapStats.overlapCount = zeros(numLabels,numLabels);
%{-
overlapStats.overlapHist = zeros(numLabels,numLabels,numBins);
overlapStats.overlapInFrontHist = zeros(numLabels,numLabels,numBins);
overlapStats.overlapBehindHist = zeros(numLabels,numLabels,numBins);
%}

pixelCount = cell(1,1,parstep);
polyCount = cell(1,1,parstep);
labelOrderHist = cell(1,1,parstep);
labelSizeHist = cell(1,1,parstep);
overlapPixel = cell(1,1,parstep);
overlapAvgScore = cell(1,1,parstep);
overlapCount = cell(1,1,parstep);
%{-
overlapHist = cell(1,1,1,parstep);
overlapInFrontHist = cell(1,1,1,parstep);
overlapBehindHist = cell(1,1,1,parstep);
%}

pfig = ProgressBar('Computing Overlap Stats');
for d = 1:parstep:length(fileList)
    sFileList = fileList(d:min(d+parstep-1,length(fileList)));
    parfor pi = 1:length(sFileList) 
        pixelCount{pi} = zeros(numLabels,1);
        polyCount{pi} = zeros(numLabels,1);
        labelOrderHist{pi} = zeros(numLabels,maxLayers);
        labelSizeHist{pi} = zeros(numLabels,sizeBins);
        overlapPixel{pi} = zeros(numLabels,numLabels);
        overlapAvgScore{pi} = zeros(numLabels,numLabels);
        overlapCount{pi} = zeros(numLabels,numLabels);
        %{-
        overlapHist{pi} = zeros(numLabels,numLabels,numBins);
        overlapInFrontHist{pi} = zeros(numLabels,numLabels,numBins);
        overlapBehindHist{pi} = zeros(numLabels,numLabels,numBins);
        %}
        
        [fold base ext] = fileparts(sFileList{pi});
        [annraw] = LMread(fullfile(HOMEANNOTATIONS,fold,[base '.xml']));
        im = imread(fullfile(HOMEIMAGES,sFileList{pi}));
        [ro co ch] = size(im);
        [ann, j, layers] = LMsortlayers(annraw, im);
        if(~isfield(ann,'object'))
            continue;
        end
        lNdx = arrayfun(@(x)str2double(x.namendx),ann.object);
        mask = zeros(ro*co,length(lNdx));
        for k = 1:length(lNdx)
            [X,Y] = getLMpolygon(ann.object(k).polygon);
            mask(:,k) = double(reshape(poly2mask(double(X),double(Y),ro,co),ro*co,1));
        end
        rawPixOl = mask'*mask;
        polySize  = eps+diag(rawPixOl);
        overlap = rawPixOl./(repmat(polySize,[1 length(polySize)])+repmat(polySize',[length(polySize) 1])-rawPixOl);
        %{
        %poly = arrayfun(@(x)[arrayfun(@(y)str2double(y.x),x.polygon.pt);arrayfun(@(y)str2double(y.y),x.polygon.pt)],ann.object,'UniformOutput',false)
        polygons = [];
        for o = 1:length(ann.object)
            polygons(o).x = str2double({ann.object(o).polygon.pt.x})';
            polygons(o).y = str2double({ann.object(o).polygon.pt.y})';
        end
        [overlap, rawPixOl, polySize] = OverlapPolygonIntUn(polygons,1);
        %}
        if(any(isnan(overlap)))
            keyboard;
        end
        for j = 1:length(overlap)
            pixelCount{pi}(lNdx(j),1) = pixelCount{pi}(lNdx(j))+polySize(j);
            polyCount{pi}(lNdx(j)) = polyCount{pi}(lNdx(j)) + 1;
            labelSizeHist{pi}(lNdx(j),ceil(mod(min((sizeBins-1)*(polySize(j)./(ro*co)),sizeBins-1),sizeBins))+1) = labelSizeHist{pi}(lNdx(j),ceil(mod(min((sizeBins-1)*(polySize(j)./(ro*co)),sizeBins-1),sizeBins))+1) + 1;
            if(~isempty(layers))
                labelOrderHist{pi}(lNdx(j),min(maxLayers,layers(j)+1)) = labelOrderHist{pi}(lNdx(j),min(maxLayers,layers(j)+1)) + 1;
            end
            %{
            %j infront of k put in lower triangle
            for k = 1:j-1
                %bin = min(ceil(mod((numBins-1)*overlap(j,k),numBins))+1,numBins);
                %overlapHist{pi}(lNdx(j),lNdx(k),bin) = overlapHist{pi}(lNdx(j),lNdx(k),bin)+1;
                %divid by size of front object 
                ol = rawPixOl(j,k)/(min(polySize(j),polySize(k)));
                bin = min(ceil(mod((numBins-1)*ol,numBins))+1,numBins);
                overlapInFrontHist{pi}(lNdx(j),lNdx(k),bin) = overlapInFrontHist{pi}(lNdx(j),lNdx(k),bin)+1;
            end
            %}
            %j behind k 
            %{-
            for k = j+1:length(overlap)
                overlapPixel{pi}(lNdx(j),lNdx(k)) = overlapPixel{pi}(lNdx(j),lNdx(k))+rawPixOl(j,k);
                overlapAvgScore{pi}(lNdx(j),lNdx(k)) = overlapAvgScore{pi}(lNdx(j),lNdx(k))+overlap(j,k);
                overlapCount{pi}(lNdx(j),lNdx(k)) = overlapCount{pi}(lNdx(j),lNdx(k))+(rawPixOl(j,k)>0);
                
                %{-
                bin = min(ceil(mod((numBins-1)*overlap(j,k),numBins))+1,numBins);
                overlapHist{pi}(lNdx(j),lNdx(k),bin) = overlapHist{pi}(lNdx(j),lNdx(k),bin)+1;
                
                ol = rawPixOl(j,k)/(min(polySize(j),polySize(k)));
                bin = min(ceil(mod((numBins-1)*ol,numBins))+1,numBins);
                overlapBehindHist{pi}(lNdx(j),lNdx(k),bin) = overlapBehindHist{pi}(lNdx(j),lNdx(k),bin)+1;
                overlapInFrontHist{pi}(lNdx(k),lNdx(j),bin) = overlapInFrontHist{pi}(lNdx(k),lNdx(j),bin)+1;
                %}
            end
            %}
        end
    end
    overlapStats.pixelCount = overlapStats.pixelCount + sum(cell2mat(pixelCount),3);
    overlapStats.polyCount = overlapStats.polyCount + sum(cell2mat(polyCount),3);
    overlapStats.labelOrderHist = overlapStats.labelOrderHist + sum(cell2mat(labelOrderHist),3);
    overlapStats.labelSizeHist = overlapStats.labelSizeHist + sum(cell2mat(labelSizeHist),3);
    overlapStats.overlapPixel = overlapStats.overlapPixel + sum(cell2mat(overlapPixel),3);
    overlapStats.overlapAvgScore = overlapStats.overlapAvgScore + sum(cell2mat(overlapAvgScore),3);
    overlapStats.overlapCount = overlapStats.overlapCount + sum(cell2mat(overlapCount),3);
    %{-
    overlapStats.overlapHist = overlapStats.overlapHist + sum(cell2mat(overlapHist),4);
    overlapStats.overlapInFrontHist = overlapStats.overlapInFrontHist + sum(cell2mat(overlapInFrontHist),4);
    overlapStats.overlapBehindHist = overlapStats.overlapBehindHist + sum(cell2mat(overlapBehindHist),4);
    %}
    ProgressBar(pfig,d+parstep-1,length(fileList));
    show(overlapStats.overlapPixel>0,1);drawnow;
end
close(pfig);