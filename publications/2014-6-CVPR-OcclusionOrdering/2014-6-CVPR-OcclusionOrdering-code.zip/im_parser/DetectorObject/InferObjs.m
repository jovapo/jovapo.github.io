function [curConfig x] = InferObjs(objLs,score,goodLOvlp,overlapScore,validBehindHist,overlapPenality,invalidPairs,countParams,params)

[coOccMat A] = MakeCoOccMat(objLs,overlapScore,validBehindHist);
coOccMat = coOccMat & ~invalidPairs;

[o1 o2] = find(~coOccMat);
rm = o1>=o2;
o1(rm) = [];o2(rm) = [];
A = zeros(length(o1),length(objLs));
A(sub2ind(size(A),1:length(o1),o1')) = 1;
A(sub2ind(size(A),1:length(o1),o2')) = 1;

curConfig = false(1,length(objLs));
changed = true;
curBest = inf;
H = (~coOccMat).*max(score)*100;
f = -score.*goodLOvlp;

T = zeros(length(objLs),size(countParams,1));
T(sub2ind(size(T),1:length(objLs),objLs)) = 1;
U = countParams(:,1);
W = score*T/params.w;
W(isnan(W))=0;
if(params.w == 0)
    W(:) = 0;
end

S = diag(W'./(countParams(:,2).^2));
Q1 = T*S*T';
L = -U'*(S+S')*T'./2;
if(~isempty(overlapPenality))
    Q = Q1+overlapPenality;
else
    Q = Q1;
end

if(params.greedy==3)
   config = zeros(1,length(objLs));
   while(any(config==0))
       inds = find(config==0);
       [m n] = max(score(inds));
       config(inds(n)) = 1;
       lind = find((objLs==objLs(inds(n)) & config==0));
       config(lind(overlapScore(inds(n),lind)>.5)) = 2;
   end
   curConfig = config == 1;
elseif(params.greedy)
    while(changed)
        configs = GetPosibleConfigs(curConfig,'add');
        if(params.greedy==2)
            configs2 = GetPosibleConfigs(curConfig,'swap',objLs);
            configs = [configs; configs2];
        end
        configs = ValidateConfigs(configs,coOccMat);
        %scores = GetConfigScore(configs,f,countParams,objLs,W);
        scores = [];
        if(~isempty(configs))
            scores = 1/2*diag(configs*Q*configs')'+(f+L)*configs';%+U'*S*U./2;
        end
        %scores2 = GetConfigScore(configs,f);
        [m ind] = min(scores);
        if(m<curBest)
            curBest = m;
            curConfig = configs(ind,:);
            %DisplayObjects(params.im,params.masks(:,curConfig),params.names(objLs(curConfig)),3,1:sum(curConfig), params.labelColors(objLs(curConfig),:) );
        else
            changed = false;
        end
    end
    curConfig = curConfig > .5;
else
    %x = quadprog(H,f,[],[],[],[],zeros(size(score)),ones(size(score)));
    %x = bintprog(f,A,ones([size(A,1) 1]));
    %opts = cplexoptimset('cplex');
    opts.threads = 1;
    opts.diagnostics = 'on';
    opts.timelimit = 60;
    x = cplexmiqp(Q,f+L,A,ones([size(A,1) 1]),[],[],[],[],[],zeros(size(score)),ones(size(score)),repmat('B',size(score)),[],opts);
    %DisplayObjects(params.im,params.masks(:,x>.5),params.names(objLs(x>.5)),3,1:sum(x>.5), params.labelColors(objLs(x>.5),:) );

    %x = cplexbilp(f,A,ones([size(A,1) 1]));
    if(sum(x) == 0)
        [~, b] = min(f);
        x(b) = 1;
    end
    curConfig = x>.5;
end
end
function [coOccMat A] = MakeCoOccMat(objLs,overlapScore,validBehindHist)
bins = ceil(overlapScore*size(validBehindHist,3));
[o1 o2] = find(bins>0);
ind = sub2ind(size(validBehindHist),objLs(o1)',objLs(o2)',bins(bins>0));
valid = validBehindHist(ind);
ind = sub2ind(size(validBehindHist),objLs(o2)',objLs(o1)',bins(bins>0));
valid2 = validBehindHist(ind);
coOccMat = true(size(overlapScore));
v = valid|valid2;
coOccMat(sub2ind(size(coOccMat),o1,o2)) = v;
%coOccMat(sub2ind(size(coOccMat),o2,o1)) = valid2;
coOccMat = coOccMat|eye(size(coOccMat));
ind = find((o1<o2)&(v==0));
o1 = o1(ind);
o2 = o2(ind);
A = zeros(length(o1),length(objLs));
A(sub2ind(size(A),1:length(o1),o1')) = 1;
A(sub2ind(size(A),1:length(o1),o2')) = 1;
end

function [configs] = GetPosibleConfigs(curConfig,opp,objLs)
if(strcmp(opp,'add'))
    addInds = find(~curConfig);
    if(isempty(addInds))
        addInds = 1;
    end
    configs = repmat(curConfig,[length(addInds) 1]);
    inds = sub2ind(size(configs),1:length(addInds),addInds);
    configs(inds) = true;
end
if(strcmp(opp,'swap'))
    pNdxs = find(curConfig);
    configs = cell(length(pNdxs),1);
    for p = pNdxs(:)'
        oNdxs = find(~curConfig & objLs(p)==objLs);
        [a b] = meshgrid(oNdxs,oNdxs);
        a = a(:)'; b = b(:)';
        rm = a<=b;
        a(rm) = [];b(rm) = [];
        configst = repmat(curConfig,[length(b) 1]);
        configst(:,p) = false;
        configst(sub2ind(size(configst),1:length(a),a)) = true;
        configst(sub2ind(size(configst),1:length(a),b)) = true;
        configs{p==pNdxs} = configst;
    end
    configs = cell2mat(configs);
end
end
function [configs] = ValidateConfigs(configs,coOccMat)
    valid = false(size(configs,1),1);
    for i = 1:size(configs,1)
        valid(i) = all(all(coOccMat(configs(i,:)==1,configs(i,:)==1)));
        %valid(i) = configs(i,:)*double(~coOccMat)*configs(i,:)'==0;
    end
    %valid =  diag(double(configs)*double(~coOccMat)*double(configs'))==0;
    configs = configs(valid,:);
end

function [score] = GetConfigScore(configs,f,countParams,objLs,w)
    if(exist('countParams','var'))
        T = zeros(size(configs,2),size(countParams,1));
        T(sub2ind(size(T),1:length(objLs),objLs)) = 1;
        U = repmat(countParams(:,1),[1 size(configs,1)])';
        S = repmat(2*countParams(:,2).^2,[1 size(configs,1)])';
        score = configs*f'+sum(repmat(w,[size(configs,1) 1]).*((configs*T-U).^2)./S,2);
    else
        score = configs*f';
    end
end
