function [overlap rawPixOl polySize] = OverlapPolygonIntUn(polygons,subsample)
if(~exist('subsample','var'))
    subsample = 4;
end
overlap = zeros(length(polygons));
rawPixOl = zeros(length(polygons));
co =  ceil(max(cell2mat(arrayfun(@(x) x.x,polygons,'UniformOutput',false)'))/subsample);
ro =  ceil(max(cell2mat(arrayfun(@(x) x.y,polygons,'UniformOutput',false)'))/subsample);
%masks = zeros(ro*co,length(polygons));
masks = zeros(length(polygons),ro*co);
for i = 1:length(polygons)
    masks(i,:) = double(reshape(poly2mask(polygons(i).x./subsample,polygons(i).y./subsample,ro,co),1,ro*co));
end
rawPixOl = masks*masks';
%optimized this is the best
%polySize = cellfun(@(x)sum(x),masks); 
polySize  = eps+diag(rawPixOl);
%{
for i = 1:length(polygons)
    %rawPixOl(i,i:end) = cellfun(@(x) sum(masks{i}&x),masks(i:end));
    %{-
    for j = i:length(polygons)
        rawPixOl(i,j) = sum(masks{i}&masks{j});
    end
    %}-
end
%}
overlap = rawPixOl./(repmat(polySize,[1 length(polySize)])+repmat(polySize',[length(polySize) 1])-rawPixOl);

function o = CompOverlap(mask1,mask2)
    o= sum(mask1&mask2);
    o = o/(sum(mask1)+sum(mask2)-o);
    