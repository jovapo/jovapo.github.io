%function gtObjDesc = ComputeObjectDescriptors(fileList)
fileList = trainFileList(retInds);

allObjs = cell(size(fileList));
pfig = ProgressBar('Loading GT Desc');
for g = 1:length(fileList)
    [foldTrain baseTrain extTrain] = fileparts(fileList{g});
    saveFile = fullfile(HOMEDATA,'RunOnTraining','GTObjDescriptors',foldTrain,[baseTrain '.mat']);
    if(exist(saveFile,'file'))
        load(saveFile);
        if(iscell(objs(1).clsNum))
            for o = 1:length(objs)
                objs(o).clsNum = find(strcmp(names,objs(o).clsNum));
            end
            make_dir(saveFile);save(saveFile,'objs');
        end
    else
        try
            load(fullfile(HOMEDATA,'RunOnTraining','ExemplarDataTermTmp',detectorFold,foldTrain,[baseTrain '.mat'])); %dataTerm (ro x co x #l) dataTermMax
            %load(fullfile(HOMEDATA,'RunOnTraining','ExemplarDetectionResults',detectorFold,foldTrain,[baseTrain '.mat'])); % test_struct polygons
            a = load(fullfile(HOMEDATA,'RunOnTraining',LabelSetFold,parserFold,foldTrain,[baseTrain '.mat'])); %probPerLabel (#SP x #l)
            if(isfield(a,'probPerLabel'))
                probPerLabel = a.probPerLabel;
            elseif(isfield(a,'prob'))
                probPerLabel = a.prob;
            end
            load(fullfile(HOMEDATA,'Descriptors',spFold,'super_pixels',foldTrain,[baseTrain '.mat'])); %superPixels (ro x co)
            a = loadXML(fullfile(HOMEANNOTATIONS,foldTrain,[baseTrain '.xml']));
            uSP = unique(superPixels);
            spMap = zeros(max(uSP),1);
            spMap(uSP) = 1:length(uSP);
            feat = probPerLabel(spMap(superPixels),:);
            feat = [feat reshape(dataTerm,[],size(dataTerm,3))];
        catch
            continue;
        end
        [masks class] = LMobjectmask(a.annotation,HOMEIMAGES);
        [ro co on] = size(masks);
        masks = reshape(masks,[ro*co on]);
        [ objs ] = ComputeObjectFeatures( masks, feat );
        for o = 1:length(objs)
            objs(o).clsNum = find(strcmp(names,class{o}));
        end
        make_dir(saveFile);save(saveFile,'objs');
        ProgressBar(pfig,g,length(fileList));
    end
    allObjs{g} = objs;
end
close(pfig);