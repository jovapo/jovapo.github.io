function [indexs, scores, maskSizes, objLs, masks] = GenerateObjHyp(L,numL,labelBBS,polygons,unary,retPoly,retClasses,suffMasks,stuffClasses,detScore)%,stuffLs)
%GENERATEOBJHYP Summary of this function goes here
%   Detailed explanation goes here
[ro co] = size(L);
lUsed = unique(L);
indexs = cell(0);
objLs = cell(0);
scores = [];
maskSizes = [];
masks = cell(0);

for l = lUsed(:)'
    boxes = labelBBS{l};
    [s ind] = sort(boxes(:,12),'descend');
    boxes = boxes(ind,:);
    if(length(boxes)==0)
        %continue;
    end
    polygonsout = ProjectDetectorPolygons(boxes, polygons);
    if(exist('retPoly','var'))
        polygonsout = [polygonsout; retPoly(retClasses==l)];
    end
    for i = 1:size(boxes,1)
        mask = poly2mask(polygonsout(i).x,polygonsout(i).y,ro,co);
        index = int32(find(mask(:)));
        %score = (boxes(i,12)+1)*maskSize;
        if(detScore)
            score = boxes(i,12)+1;
        else
            score = sum(1+unary(index,l));
            if(score<=0)
                continue;
            end
        end
        if(nargout>4)
            masks{end+1} = mask(:);
        end
        indexs{end+1} = index;
        scores(end+1,:) = ones(1,numL+1)*score;
        scores(end,l) = 0;
        maskSizes(end+1) = length(index);
        objLs{end+1} = l;
    end
    if(exist('stuffClasses','var'))
        ndxs = find(stuffClasses==l);
        for i = ndxs(:)'
            mask = suffMasks(:,:,i);
            index = int32(find(mask(:)));
            %score = (boxes(i,12)+1)*maskSize;
            score = sum(1+unary(index,l));
            if(score<=0)
                continue;
            end
            if(nargout>4)
                masks{end+1} = mask(:);
            end
            indexs{end+1} = index;
            scores(end+1,:) = ones(1,numL+1)*score;
            scores(end,l) = 0;
            maskSizes(end+1) = length(index);
            objLs{end+1} = l;
        end
    end
end
%{
bps = [0 -.5 -1];
stuffLs = intersect(stuffLs,lUsed);
for l = stuffLs(:)'
    mx = max(unary(:,l));
    mn = min(unary(:,l));
    %md = (mx+mn)/2;
    for bp = bps(:)'
        mask = unary(:,l)>bp;%show(reshape(mask,[ro co]));%(bp*mx+(1-bp)*mn);
        if(sum(mask)>.5*length(mask))
            continue;
        end
        index = int32(find(mask(:)));
        %score = (boxes(i,12)+1)*maskSize;
        score = sum(1+unary(index,l));
        if(score<=0)
            continue;
        end
        if(nargout>4)
            masks{end+1} = mask(:);
        end
        indexs{end+1} = index;
        scores(end+1,:) = ones(1,numL+1)*score;
        scores(end,l) = 0;
        maskSizes(end+1) = length(index);
        objLs{end+1} = l;
    end
end
%}
masks = cell2mat(masks);
end

