function objs = RefineMasks(im,objs,gPb_thin)
tic
color_bin = 12;
while (color_bin <= 255)
    [~, color_index_dist, color_index_map, nBin] = RGBQuantization(im, color_bin, 0.95, false);
    if ( nBin < 100 )
        color_bin = color_bin + 12;
    else
        break;
    end
end
[ro co ch] = size(im);
SE = strel('disk', 10,0);
SE2 = strel('disk', 10,0);
params.shape_w = .5;
params.smoothness_const = 10;
toc
tic
for o = 1:length(objs.Ls)
    detMask = reshape(objs.masks(:,o),[ro co]);
    detMask = detMask + imdilate(detMask,SE) + imerode(detMask,SE2);
    outMask = RefineMask(im,objs.masks(:,o),detMask,gPb_thin,params,color_index_map);
    pt = params;
    while(all(~outMask{1}))
        params.smoothness_const = params.smoothness_const/2;
        outMask = RefineMask(im,objs.masks(:,o),detMask,gPb_thin,params,color_index_map);
    end
    objs.masks(:,o) = outMask{1}(:);
end
toc