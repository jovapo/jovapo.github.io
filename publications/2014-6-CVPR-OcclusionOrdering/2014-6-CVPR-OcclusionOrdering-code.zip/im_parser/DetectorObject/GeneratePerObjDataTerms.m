%function [objDataTerms clsList] = GeneratePerObjDataTerms(trainedSVM,feat,predictors,test_struct,polygons)

[featNorm] = MySVMNormalize(feat,trainedSVM.svm.params);
featsTemp = featNorm;

numL = size(predictors,2);
[a topL] = max(predictors,[],2);
usedL = unique(topL);
clsList = [];
objDataTerms = cell(0);

objDataTermsRaw = cell(0);
objDataTermsRawWarped = cell(0);

labelBBS = test_struct.final_boxes;
overlap = .3;

pb = imread(fullfile(HOMEDESCRIPTOR,'Pb','globalPb',fold,[base '.png']));
pb = double(pb)/max(double(pb(:)));

for l = 40%usedL(:)'
    fprintf('Splitting: %s\n',names{l});
    boxes = labelBBS{l};
    if(isempty(boxes))
        continue;
    end
    clusters = cell(0);
    x1 = boxes(:,1);
    y1 = boxes(:,2);
    x2 = boxes(:,3);
    y2 = boxes(:,4);
    s = boxes(:,end);

    area = (x2-x1+1) .* (y2-y1+1);
    [vals, I] = sort(s);

    pick = s*0;
    counter = 1;
    while ~isempty(I)
      last = length(I);
      bbNdx = I(last);  
      pick(counter) = bbNdx;
      counter = counter + 1;

      xx1 = max(x1(bbNdx), x1(I(1:last-1)));
      yy1 = max(y1(bbNdx), y1(I(1:last-1)));
      xx2 = min(x2(bbNdx), x2(I(1:last-1)));
      yy2 = min(y2(bbNdx), y2(I(1:last-1)));

      w = max(0.0, xx2-xx1+1);
      h = max(0.0, yy2-yy1+1);

      o = w.*h ./ area(I(1:last-1));

      clusters{end+1,1} = I([last; find(o>overlap)]);
      I([last; find(o>overlap)]) = [];
    end
    
    %{
    colors = 'grbymcwkgrbymcwkgrbymcwkgrbymcwkgrbymcwkgrbymcwkgrbymcwkgrbymcwkgrbymcwkgrbymcwkgrbymcwkgrbymcwkgrbymcwkgrbymcwkgrbymcwk';
    show(im,1);figure(1);hold on;
    for j = 1:size(clusters,1)
        top = boxes(clusters{j},:);
        for k = 1:length(clusters{j})
            if(top(k,3)-top(k,1) <=0 || top(k,4)-top(k,2) <= 0)
                continue;
            end
            rectangle( 'Position',[top(k,1) top(k,2) top(k,3)-top(k,1) top(k,4)-top(k,2)],'LineWidth',2,'EdgeColor',colors(j));%'g');%
        end
    end
    hold off;
    %}
    
    lndx = find(trainedSVM.svm.params.labelList==l);
    notL = 1:numL;    notL(l) = [];
    for j = 1:size(clusters,1)
        [objDataTerm objDataTermWarped] = ProjectDetectorResponses(im,boxes(clusters{j},:),polygons);
        [objDataTermNorm] = MySVMNormalize(objDataTerm(:),trainedSVM.svm.params,l+numL);
        featsTemp(:,l+numL) = objDataTermNorm;
        objPred = featsTemp*(trainedSVM.svm.model{lndx}.w'.*trainedSVM.svm.model{lndx}.Label(1));
        featsTemp(:,l+numL) = featNorm(:,l+numL);
        
        [a topLLocal] = max([objPred predictors(:,notL)],[],2);
        if(any(topLLocal==1))
            objDataTerms{end+1} = objPred;
            clsList = [clsList l];
            fprintf('   Found object: %d\n',j);
            objDataTermsRaw{end+1} = objDataTerm;
            objDataTermsRawWarped{end+1} = objDataTermWarped;
            show(objDataTerm,1);show(objDataTermWarped,2);
        end
    end
end