SetUpConstants;


overlapThresh = [.3];
maskRange = [.5];

allResults = cell(size(testFileList));

if(exist('pfig','var'))try;close(pfig);end;end;

pfig = ProgressBar('Testing Clustering Methods');
for f = rangeTest
    [fold base ext] = fileparts(testFileList{f});
    saveFile = fullfile(TestFold,'QuantitativeClusterTests2',fold,[base '.mat']);
    if(exist(saveFile,'file'))
        load(saveFile);
        allResults{f} = result;
        ProgressBar(pfig,find(f==rangeTest),length(rangeTest));
        continue;
    end
    result = [];
    result.fold = fold;
    result.base = base;
    try
        load(fullfile(TestFold,'ExemplarDetectionResults',detectorFold,fold,[base '.mat'])); % test_struct polygons
        labelBBS = test_struct.final_boxes;
        clear gPb_thin;
        load(fullfile(HOMEDESCRIPTOR,'Pb','globalPb25',fold,[base '.mat'])); %  gPb_orient gPb_thin textons
        %gPb_thin = max(gPb_orient,[],3);
        im = imread(fullfile(HOMEIMAGES,fold,[base ext]));
        clear S_instances;
        load(fullfile(HOMELABELSETS{1},fold,[base '.mat'])); %S (ro x co) S_instances names
        if(~exist('S_instances','var')) continue; end
    catch
        continue;
    end
    [ro co inst] = size(S_instances);
    S_instances = reshape(S_instances,[ro*co inst]);
    instL = zeros(size(S_instances,2),1);
    for i = 1:length(instL)
        l = unique(S_instances(:,i));
        instL(i) = l(l~=0);
    end
    
    instanceMasks = S_instances>0;
    usedL = unique(instL);
    result.instL = instL;
    
    for l = usedL(:)'
        %init structure
        instNdx = find(instL==l);
        boxes = labelBBS{l};
        rmNdx = find(boxes(:,3)<boxes(:,1) | boxes(:,4)<boxes(:,2));
        boxes(rmNdx,:) = [];
        if(length(boxes)==0)
            continue;
        end
        polygonsout = ProjectDetectorPolygons(boxes, polygons);
        olScores = cell(0);olName = cell(0);olFileSuffix = cell(0);
        olScores{end+1} = OverlapBBIntUn(boxes);
        olName{end+1} = 'BB Int/Union';olFileSuffix{end+1} = 'BBIU';
        olScores{end+1} = OverlapPolygonIntUn(polygonsout);
        olName{end+1} = 'Poly Int/Union';olFileSuffix{end+1} = 'PIU';
        olScores{end+1} = OverlapPolygonBIntUn(polygonsout,max(size(S))/128,max(size(S))/128);
        olName{end+1} = 'Poly Boundary Int/Union 6 6';olFileSuffix{end+1} = 'PBIU66';
        olScores{end+1} = OverlapPolygonBIntUn(polygonsout,0,max(size(S))/16);
        olName{end+1} = 'Poly Boundary Int/Union 0 50';olFileSuffix{end+1} = 'PBIU050';
        olScores{end+1} = OverlapPolygonBDist(polygonsout,max(size(S))/128);
        olName{end+1} = 'Poly Boundary Distance 6';olFileSuffix{end+1} = 'PBD6';
                
        for c = 1:length(olScores)
            olScore = olScores{c};
            olScore = 1 - olScore;
            olScore = olScore - diag(diag(olScore));
            Z = linkage(squareform(olScore'),'average');
            %dendrogram(Z,0);
            %T = cluster(Z,'cutoff',c);
            T = cluster(Z,'cutoff',1-overlapThresh,'criterion','distance');
            
            if(~isfield(result,olFileSuffix{c}))
                result.(olFileSuffix{c}).name = olName{c};
                result.(olFileSuffix{c}).numC =0;
            end
            result.(olFileSuffix{c}).numC = result.(olFileSuffix{c}).numC + max(T);
            [a b] = UniqueAndCounts(T);
            [a b] = sort(b,'descend');
            map = zeros(size(b));map(b) = 1:length(b);
            T = map(T);
            if(length(olScore)==1)
                T = 1;
            end
            for j = 1:max(T)
                detNdxs = find(T==j);
                if(length(detNdxs)<=1)
                    continue;
                end
                clMask = zeros(ro,co);
                score = 0;
                for k = detNdxs(:)'
                    m = poly2mask(polygonsout(k).x,polygonsout(k).y,ro,co);
                    clMask = clMask + m.*(boxes(k,end)+1+.000001);
                    score = score + (boxes(k,end)+1+.000001);
                end
                for mr = 1:length(maskRange)
                    mask = clMask(:)'>(max(clMask(:))*maskRange(mr));
                    if(~isfield(result.(olFileSuffix{c}),'raw'))
                        result.(olFileSuffix{c}).raw = zeros(size(instL));
                    end
                    result.(olFileSuffix{c}).raw = max(TestObjHypothesis(mask(:),instanceMasks,instNdx),result.(olFileSuffix{c}).raw);
                    %show(clMask,1);
                    if(c==4)
                        [masks, names] = RefineMask(im,mask,clMask,clMask,gPb_thin);
                        for i = 1:length(masks)
                            if(~isfield(result.(olFileSuffix{c}),names{i}))
                                result.(olFileSuffix{c}).(names{i}) = zeros(size(instL));
                            end
                            result.(olFileSuffix{c}).(names{i}) = max(TestObjHypothesis(masks{i}(:),instanceMasks,instNdx),result.(olFileSuffix{c}).(names{i}));
                        end
                    end
                end
            end
        end
    end
    allResults{f} = result;
    make_dir(saveFile);save(saveFile,'result');
    ProgressBar(pfig,find(f==rangeTest),length(rangeTest));
end
close(pfig);