SetUpConstants;

ls = 1;
[foo LabelSetFold] = fileparts(HOMELABELSETS{ls});

dataset_params.datadir = HOMEDATA;
dataset_params.localdir = '';%fullfile(HOMEDATA,testParams.TestString);
dataset_params.display = 0;
detectorParams = esvm_get_default_params;
detectorParams.dataset_params = dataset_params;

ObjectWebFold = fullfile(TestFold,'ObjectWeb');
webIndex = fullfile(ObjectWebFold,'bad.htm'); make_dir(webIndex);
indexFID = fopen(webIndex,'w');
fprintf(indexFID,'\n<center>\n');
fprintf(indexFID,'\n<table border="0">\n');
fprintf(indexFID,'\t<tr>\n');

numCols = 6;
colCount = 0;

range = 1:length(testFileList);
if(exist('rangeN','var'))
    range = rangeN(1):rangeN(2):length(testFileList);
end
%{-
allBB = [];
allBB.baseBB = [];
allBB.baseExpanded = [];
allBB.prunClSize = [];
allBB.prunClSizeExpanded = [];
allBB.prunClScore = [];
allBB.prunClScoreExpanded = [];
%}
pfig = ProgressBar('Computing Bounding Boxes');

for i = range
    [fold base ext] = fileparts(testFileList{i});
    
    imageToFold = fullfile(ObjectWebFold,'Images',fold,[base ext]);make_dir(imageToFold);
    copyfile(fullfile(HOME,'Images',testFileList{i}),imageToFold);
    fprintf(indexFID,'\t\t<td><center> <a href="%s">',['ImageWeb/' fold '/' base '.htm']);
    fprintf(indexFID,'<img  width="200" src="%s"></a> ',['Images/' fold '/' base ext]);
    fprintf(indexFID,'</center> </td>\n');
    colCount = colCount +1;
    if(colCount == numCols)
        colCount = 0;
        fprintf(indexFID,'\t</tr><tr>\n');
    end
    %{-
    im = imread(fullfile(HOME,'Images',testFileList{i}));
    [ro co ch] = size(im);
    timingFile = fullfile(TestFold,'Timing',fold,[base '.mat']);make_dir(timingFile);
    if(exist(timingFile,'file'))
        load(timingFile);
    else
        fileStats = [];
    end
    fileStats.imSize = [ro co];
    
    FindRetrievalSetAndFixUp;
    retIndsSm = retInds(1:min(testParams.retSetSize,length(retInds)));
    
    detectorSuffix = [testParams.ModelFold '-MM' myN2S(testParams.MaxModelPerCls,4) '-R' myN2S(testParams.retSetSize)];
    detectorDataSuffix = [detectorSuffix '-NMS' num2str(testParams.NMS)];
    dataResultFile = fullfile(TestFold,'ExemplarDetectionResults',detectorDataSuffix,fold,[base '.mat']);
    clear polygons;
    if(exist(dataResultFile,'file'))
        load(dataResultFile);
        %continue;
    end
    if(~exist('polygons','var'))
        %{-
        allModels = cell(0);
        fileStats.timeLoadDetectors = tic;
        for rNdx = 1:length(retIndsSm)
            [retFold retBase] = fileparts(trainFileList{retIndsSm(rNdx)});
            modelFile = fullfile(HOMEDATA,'Classifier','Exemplar',testParams.ModelFold,retFold,[retBase '.mat']);
            if(exist(modelFile,'file'))
                load(modelFile);
                models = AddPolyToModel(fullfile(HOME,'Annotations'),models,modelFile);
                allModels = [allModels(:); models(:)];
            end
        end
        fileStats.timeLoadDetectors = toc(fileStats.timeLoadDetectors);
        modelCls = cellfun2(@(x)x.cls,allModels);
        [unmodelCls a mNdx] = unique(modelCls);
        fileStats.numDetRaw = length(modelCls);
        if(testParams.MaxModelPerCls>0)
            [a b] = UniqueAndCounts(mNdx);
            rmNdx = [];
            for ovNdx = find(b>testParams.MaxModelPerCls)'
                ndx = find(mNdx == a(ovNdx));
                rmNdx = [rmNdx; ndx(testParams.MaxModelPerCls+1:end)];
            end
            allModels(rmNdx) = [];
            modelCls(rmNdx) = [];
            [unmodelCls a mNdx] = unique(modelCls);
        end
        m2lnum = 1:length(unmodelCls);
        fileStats.numDetReduced = length(modelCls);
        for m2lNdx = 1:length(unmodelCls)
            m2lnum(m2lNdx) = find(strcmp(strtrim(unmodelCls{m2lNdx}),Labels{ls}));
        end
        modelLnum = m2lnum(mNdx);

        testResultFile = fullfile(TestFold,'ExemplarResult',detectorSuffix,fold,[base '.mat']);
        if(exist(testResultFile,'file'))
            load(testResultFile);
        else
            fileStats.timeDetect = tic;test_grid = esvm_detect_imageset({fullfile(HOME,'Images',testFileList{i})}, allModels, detectorParams); fileStats.timeDetect = toc(fileStats.timeDetect);
            fileStats.numDetect = size(test_grid{1}.coarse_boxes,1);
            save(timingFile,'fileStats');
            make_dir(testResultFile);save(testResultFile,'test_grid');
        end
        cls_test_grid = cell(size(Labels{ls}));
        for l = 1:length(Labels{ls});
            cls_test_grid{l} = test_grid{1};
            rmNdx = modelLnum(cls_test_grid{l}.coarse_boxes(:,6))~=l;
            cls_test_grid{l}.coarse_boxes(rmNdx,:) = [];
            cls_test_grid{l}.bboxes(rmNdx,:) = [];
        end
        M = [];
        min_val = -1;
        detectorParams.do_nms = testParams.NMS;
        test_struct = esvm_pool_exemplar_dets(cls_test_grid, allModels,M, detectorParams);
        
        polygons = cellfun2(@(x) x.polygon.pt,allModels);
        make_dir(dataResultFile);save(dataResultFile,'test_struct','polygons');
    end
    ClusterBB;
    ProgressBar(pfig,find(i==range),length(range));
    fprintf('Finished Detectors\n');
    %}
end
close(pfig);
fprintf(indexFID,'\t</tr>\n</table></center>');
fclose(indexFID);
