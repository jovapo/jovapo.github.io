function imOut = DisplayObjects( im,masks,names,figNo,order,labelColors, useLegend )
[ro co ch] = size(im);
if(~exist('useLegend','var'))
    useLegend = true;
end
if(useLegend)
    tmp = zeros([size(im,1) 160 size(im,3)]);
    im = [im tmp];
end
show(im,figNo);hold on;
ind = 1:size(masks,2);
bkColor = true;
if(exist('order','var')&& ~isempty(order))
    [~, ind] = sort(order);
    bkColor = true;
end
if(exist('labelColors','var'))
    if(bkColor)
        for i = ind
            b = bwboundaries(reshape(masks(:,i),[ro co]));
            patch(b{1}(:,2),b{1}(:,1),'r','FaceColor',labelColors(i,:),'EdgeColor','none');
        end
        drawnow;
        %h=gca;
        %F=getframe(h);
        %im2=F.cdata;
        im2 = export_fig;
        show(uint8(double(im2)*.5+double(im)*.5),figNo);hold on;
    end
    for i = ind
        b = bwboundaries(reshape(masks(:,i),[ro co]));
        patch(b{1}(:,2),b{1}(:,1),'r','FaceColor','none','EdgeColor',labelColors(i,:),'LineWidth',4);
    end
    drawnow;
    %h=gca;
    %F=getframe(h);
    %imOut=F.cdata;
    imOut = export_fig;
    %{-
    
    %}
elseif(exist('order','var'))
    orderColors = jet(max(order));
    for i = ind
        b = bwboundaries(reshape(masks(:,i),[ro co]));
        patch(b{1}(:,2),b{1}(:,1),'r','FaceColor','none','EdgeColor',orderColors(order(i),:),'LineWidth',3);
    end
else
    orderColors = jet(size(masks,2));
    for i = ind
        b = bwboundaries(reshape(masks(:,i),[ro co]));
        patch(b{1}(:,2),b{1}(:,1),'r','FaceColor','none','EdgeColor',orderColors(i,:),'LineWidth',3);
    end
end
if(useLegend)
    legend(names(ind));
end
hold off;
end

