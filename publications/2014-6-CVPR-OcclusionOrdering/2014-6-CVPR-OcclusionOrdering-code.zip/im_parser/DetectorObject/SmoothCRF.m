function [L timerVar] = SmoothCRF(im,unary,pNPot,w,saveInfo)
[ro co ch] = size(im);
gausianParams.x_std = 3;
gausianParams.y_std = 3;
gausianParams.weight = w;
gausianParams.pixelNorm = false;
crfParams.gausianParams = gausianParams;
bilateralParams.dist_std = 15;
bilateralParams.co_std = 20;
bilateralParams.weight = w;
bilateralParams.pixelNorm = false;
crfParams.bilateralParams = bilateralParams;
crfParams.itterations = 10;
crfParams.conn = 8;
timerVar = 0;
MAX_COST = 10000;
if(~exist('saveInfo','var'))
    if(~isempty(pNPot))
        L = PixPnCRF([],[],[],[],[],im,unary,pNPot,crfParams);
    else
        [L timerVar] = PixDenseCRF([],[],[],[],[],im,unary,crfParams);
    end
else
    crfParams.names = saveInfo.names;
    crfParams.S = saveInfo.S;
    if(isfield(saveInfo,'MRFType') && saveInfo.MRFType == 0)
        params.edgeParam = 11;
        params.connected=8;
        params.S{1} = saveInfo.S;
        params.names{1} = saveInfo.names;
        dataCost{1} = int32(unary*MAX_COST);
        %testName = sprintf('Sig-%s-SS%03d-sw%.2f',testSVMList{i},smoothing,sw);
        smoothingMatrix = w*(ones(size(unary,2))-eye(size(unary,2)));
        timerVarTic = tic;
        HLS = [];
        if(~isempty(saveInfo.HOMELABELSET))
            HLS = {saveInfo.HOMELABELSET};
        end
        [L] = MultiLevelPixMRF(saveInfo.HOMEDATA,HLS,saveInfo.testName,saveInfo.baseFName,{saveInfo.Labels},saveInfo.imSP,im,dataCost,smoothingMatrix,[],params);
        L = L{1};
        timerVar=timerVar+toc(timerVarTic);
    elseif(~isempty(pNPot))
        L = PixPnCRF(saveInfo.HOMEDATA,saveInfo.HOMELABELSET,saveInfo.testName,saveInfo.baseFName,saveInfo.Labels,im,unary,pNPot,crfParams);
    else
        [L timerVar] = PixDenseCRF(saveInfo.HOMEDATA,saveInfo.HOMELABELSET,saveInfo.testName,saveInfo.baseFName,saveInfo.Labels,im,unary,crfParams);
    end
end

    
