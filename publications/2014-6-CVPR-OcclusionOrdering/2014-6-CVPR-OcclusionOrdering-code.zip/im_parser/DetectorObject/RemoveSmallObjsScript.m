SetUpConstants;

objFoldList = {'RetPoly0-rmStDet1-w04-cw00-gd1-olp1','RetPoly0-rmStDet1-w04-cw00-gd2-olp1'};
thresh = [2 3 4];

pfig = ProgressBar('Removing Small Objects');
for f = rangeTest(:)'%[ 1 146 132 125 219 103  ]%1:500% rangeTest(:)'
    [fold base ext] = fileparts(testFileList{f});
    
    try
        load(fullfile(HOMELABELSETS{1},fold,[base '.mat'])); %S (ro x co) names
        clear im;
        try
            im = imread(fullfile(HOMEIMAGES,testFileList{f}));
        catch
            im = imread(fullfile(HOMEIMAGES,fold,[base '.jpg']));
        end
    catch
        continue;
    end
    for i = 1:length(objFoldList)
        fileName = fullfile(TestFold,testParams.MRFFold,'ObjectsPicked',objFoldList{i},fold,[base '.mat']);
        load(fileName);
        orgObjs = objs;
        %DisplayObjects( im,objs.masks,names(objs.Ls),4,objOrder, labelColors{1}(objs.Ls,:) );
        objSize = sum(objs.masks);
        uls = unique(objs.Ls);
        for t = thresh
            objs = orgObjs;
            rm = false(size(objSize));
            for l = uls
                inds = find(objs.Ls == l);
                lm = single(objs.masks(:,inds));
                ovlap = lm'*lm;
                os1 = repmat(objSize(inds),[length(inds) 1]);
                os2 = repmat(objSize(inds)',[1 length(inds)]);
                mxRatio = max((os1./os2).*(ovlap>0),[],2);
                rm(inds(mxRatio>t))= true;
            end
            objs.masks(:,rm) = [];
            objs.Ls(rm) = [];
            objs.order(rm) = [];
            fileName = fullfile(TestFold,testParams.MRFFold,'ObjectsPicked',[objFoldList{i} '-t' num2str(t)],fold,[base '.mat']);
            make_dir(fileName);save(fileName,'objs');
        end
    end
    ProgressBar(pfig,find(f==rangeTest),length(rangeTest));
end
close(pfig);