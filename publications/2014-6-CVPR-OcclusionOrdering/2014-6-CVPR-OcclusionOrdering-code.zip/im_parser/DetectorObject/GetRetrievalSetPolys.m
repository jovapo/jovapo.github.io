function [retPoly retClasses] = GetRetrievalSetPolys(HOMEANN,fileList,imSize)

retClasses = cell(length(fileList),1);
retPoly = cell(size(fileList));
for i = 1:length(fileList)
    [fold base] = fileparts(fileList{i});
    xmlFile = fullfile(HOMEANN,fold,[base '.xml']);
    [ann] = LMread(xmlFile);
    if(isfield(ann,'object'))
        retClasses{i} = zeros(length(ann.object),1);
    else
        retClasses{i} = zeros(0,1);
        continue;
    end
    if(isfield(ann,'imagesize'))
        ro = str2double(ann.imagesize.nrows);
        co = str2double(ann.imagesize.ncols);
    else
        ro = imSize.ro;
        co = imSize.co;
    end
    rs = imSize.ro/ro;
    cs = imSize.co/co;
    %retPoly{i} = cell(length(ann.object),1);
    for j = 1:length(ann.object)
        poly.x = str2double({ann.object(j).polygon.pt.x}).*cs;
        poly.y = str2double({ann.object(j).polygon.pt.y}).*rs;
        retClasses{i}(j) = str2double(ann.object(j).namendx);
        retPoly{i}(j,1) = poly;
    end
end
retClasses = cell2mat(retClasses);
retPoly = vertcat(retPoly{:});