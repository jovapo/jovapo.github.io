%Lstart = SmoothDCRFOnce(predictorCell{1},im,16);

timingFile = fullfile(TestFold,'Timing',fold,[base '.mat']);make_dir(timingFile);
fileStats = [];
if(exist(timingFile,'file'))
    try
        load(timingFile);
    catch
        delete(timingFile);
    end
end

labelBBS = test_struct.final_boxes;
numL = size(predictorCell{2},2);
svmCutoff = -1;
svmShiftAmount = .5;
inconsistPerc = .3;
[ro co ch] = size(im);

if(~exist('overlapStats','var'))
    load(fullfile(HOME,'overlap.mat'));
end
%overlapStats.overlapPixel(m,n) the number of pixels of class m that occur behind class n
minPix = max(1,min(repmat(overlapStats.pixelCount,[1 numL]),repmat(overlapStats.pixelCount',[numL 1])));
validPixelOverlap = eye(size(minPix)) | (overlapStats.overlapPixel./minPix)>.001; %chose .001% from looking at the file generated below
%{
[val, ind] = sort(validPixelOverlap(:),'descend');
fid = fopen(fullfile(HOME,'labelRelationships.txt'),'w');
for i = 1:sum(ind~=0)
    [m n] = ind2sub(size(validPixelOverlap),ind(i));
    fprintf(fid,'%.04f %s behind %s\n',val(i),names{m},names{n});
end
fclose(fid);
%}

%overlapStats.overlapBehindHist(m,n,o) the number of pixels of class m that occur behind class n at overlap bin o
overlapBehindHist = overlapStats.overlapBehindHist;
overlapBehindHist = overlapBehindHist(:,:,2:end);
%overlapBehindHist = overlapBehindHist+1;
numBins = 10;
blocks =  BlockRange(size(overlapBehindHist,3),numBins);
for i = 1:numBins;
    overlapBehindHist(:,:,i) = sum(overlapBehindHist(:,:,blocks(i,1):blocks(i,2)),3);
end
overlapBehindHist(:,:,numBins+1:end) = [];
overlapBehindHist(:,:,end) = overlapBehindHist(:,:,end) - diag(diag(overlapBehindHist(:,:,end))); %remove duplicate objects
%overlapBehindHist(:,:,1:numBins/2) = overlapBehindHist(:,:,1:numBins/2)+1; %smooth non-attached objects
overlapBehindHist(:,:,:) = overlapBehindHist(:,:,:)+.1; %smooth non-attached objects
for d = ceil(numBins*.501):size(overlapBehindHist,3);
    overlapBehindHist(sub2ind(size(overlapBehindHist),1:numLs,1:numLs,d*ones(1,numLs))) = 0; % zero out overlap between the same obj over 50%
end
minObj = repmat(max(1,min(repmat(overlapStats.polyCount,[1 numL]),repmat(overlapStats.polyCount',[numL 1]))),[1 1 numBins]);
overlapBehindProb =  overlapBehindHist./minObj;
validBehindHist = (overlapBehindProb)>.001;
%{
[val, ind] = sort(overlapBehindHist(:),'descend');
fid = fopen(fullfile(HOME,'labelRelationships.txt'),'w');
for i = 1:sum(ind~=0)
    [m n o] = ind2sub(size(overlapBehindHist),ind(i));
    fprintf(fid,'%.04f %s behind %s by %.1f\n',val(i),names{m},names{n},o/10);
end
fclose(fid);
%}

unary = 1./(1+exp(-predictorCell{1}));
%ps = sum(unaryProb,2);
%unaryProbNorm = bsxfun(@rdivide,unaryProb,ps);
%unaryNorm = -log(unaryProbNorm);
unary = -log(unary);
%{-
myStuffLs = [stuffLs; find(strcmp(names,'hill')); find(strcmp(names,'tree'))];
nonExUnaryStuff = -log(1./(1+exp(-predictorCell{2}(:,myStuffLs))));
%}

[ro co ch] = size(im);
imSize.ro = ro;
imSize.co = co;
sp = imresize(-log(spatialPrior),[ro co],'nearest');
sp = reshape(sp,size(unary));

for w = [ 65 129]%
saveInfo.HOMEDATA = fullfile(TestFold,testParams.MRFFold);
saveInfo.HOMELABELSET = HOMELABELSETS{1};
saveInfo.testName = sprintf('Lin-Sig-%s-w%02d',svmName,w);
saveInfo.baseFName = fullfile(fold,base);
saveInfo.Labels = Labels{1};
saveInfo.names = names;
saveInfo.S = S;
saveInfo.imSP = superPixels;
saveInfo.MRFType = 0;

pNPot = [];
pNPot.index = cell(0);
pNPot.costs = [];
pNPot.Q = [];
converge = 0;
sw = .05;
[L0 timerVar] = SmoothCRF(im,unary+sp.*sw,[],w,saveInfo);
fileStats.(['DCRF' num2str(i)]) = timerVar;
save(timingFile,'fileStats');
%DrawImLabels(im,L0,labelColors{1},names,[],1,0,1);


timeRetSet=tic; 
LExcStuff = SmoothCRF(im,unary(:,myStuffLs)+sp(:,myStuffLs).*sw,[],w);
LnonExcStuff = SmoothCRF(im,nonExUnaryStuff+sp(:,myStuffLs).*sw,[],w);
%DrawImLabels(im,myStuffLs(LExcStuff),labelColors{1},names,[],1,0,1);DrawImLabels(im,myStuffLs(LnonExcStuff),labelColors{1},names,[],1,0,2);
[suffMasks stuffClasses] = GenerateStuffMasks(LExcStuff);
[suffMasks2 stuffClasses2] = GenerateStuffMasks(LnonExcStuff);
suffMasks = cat(3,suffMasks,suffMasks2);
stuffClasses = [stuffClasses; stuffClasses2];
stuffClasses = myStuffLs(stuffClasses);
timeRetSet=toc(timeRetSet);
fileStats.timeGenStuffMasks=timeRetSet;
save(timingFile,'fileStats');
retInds = FindRetrievalSet([],[],TestFold,fullfile(fold,base),testParams,'');
retIndsSm = retInds(1:min(testParams.retSetSize,length(retInds)));
for includeRetPoly = [false]% true
if(includeRetPoly)
    [retPoly retClasses] = GetRetrievalSetPolys(HOMEANNOTATIONS,trainFileList(retIndsSm),imSize);
    rmInd = ~ismember(retClasses,myStuffLs);
    retPoly(rmInd) = [];
    retClasses(rmInd) = [];
else
    retPoly = [];
    retClasses = [];
end
for countW = [0]
for useGreedy = [0 1]
for useOLP = [true]
for stuffBehind = [true];% false
for sizeThresh = [3];%3 
for useStuffParse = [true];
for rmStuffDet = [true]%false
if(useGreedy == 2 && (useOLP == false || countW > 0 || stuffBehind == true || sizeThresh ~= 3))
    continue;
end
if(useGreedy == 0 && ~useStuffParse)
    continue;
end


bxs = test_struct.final_boxes;
if(rmStuffDet&&useStuffParse)
    for i = myStuffLs(:)';
        bxs{i} = zeros(0,12);
    end
end
if(useStuffParse)
    [indexAll scoresAll maskSizesAll objLsAll masksAll] = GenerateObjHyp(L0,numL,bxs,polygons,predictorCell{2},retPoly,retClasses,suffMasks,stuffClasses,false);%,stuffLs)
else
	[indexAll scoresAll maskSizesAll objLsAll masksAll] = GenerateObjHyp(L0,numL,bxs,polygons,predictorCell{2},retPoly,retClasses,[],[],~rmStuffDet&&~useStuffParse&&useGreedy==3);%,stuffLs)
end
scoresAll = cellfun(@(x,l) sum(1+predictorCell{2}(x,l)),indexAll,objLsAll);
goodLOvlp = cellfun(@(x,l) sum(validPixelOverlap(l,L0(x))),indexAll,objLsAll)./maskSizesAll;
goodLPix = cellfun(@(x,l) sum(l==L0(x)),indexAll,objLsAll)./maskSizesAll;
rm = goodLPix<.1;
if(~rmStuffDet&&~useStuffParse&&useGreedy==3)
    rm(:) = false;
end
index = indexAll(~rm);scores = scoresAll(~rm);maskSizes = maskSizesAll(~rm);objLs = objLsAll(~rm);masks = masksAll(:,~rm);goodLOvlp(rm) = [];
objLs = cell2mat(objLs);
%overlapPixels2 = single(masks')* single(masks);
overlapPixels = zeros(size(masks,2));
smasks = single(masks);
for i = 1:100:size(masks,2)
    overlapPixels(i:min(i+99,size(masks,2)),:) = smasks(:,i:min(i+99,size(masks,2)))'*smasks;
end
clear smasks;
overlapPenality = zeros(size(masks,2));
overlapPenality2 = zeros(size(masks,2));
overlapPenalityw = zeros(size(masks,2));
sizeRatio = zeros(size(masks,2));
tic
for l = unique(objLs)
    p = 1+predictorCell{2}(:,l);
    ind = find(objLs == l);
    dm = double(masks(:,ind));
    overlapPenality(ind,ind) = dm'*diag(sparse(p))*dm;
    for i = 1:length(ind)
        for j = (i+1):length(ind)
            intM = dm(:,i)&dm(:,j);
            if(any(intM~=0))
                overlapPenality2(ind(i),ind(j)) = sum(p(intM));
                overlapPenalityw(ind(i),ind(j)) = sum(p(intM)).*mean(validPixelOverlap(l,L0(intM)));
            end
        end
    end

    os1 = repmat(maskSizes(ind),[length(ind) 1]);
    os2 = repmat(maskSizes(ind)',[1 length(ind)]);
    sizeRatio(ind,ind) = max(os1,os2)./min(os1,os2).*(overlapPixels(ind,ind)>0);
    %rm(inds(mxRatio>t))= true;
end
overlapPenality = (overlapPenality + overlapPenality')./2;
overlapPenality = overlapPenality-diag(diag(overlapPenality));
overlapPenality2 = overlapPenality2 + overlapPenality2';
overlapPenalityw = overlapPenalityw + overlapPenalityw';
if(~useOLP)
    overlapPenality = zeros(size(masks,2));
    overlapPenalityw = zeros(size(masks,2));
end
toc
overlapScore = overlapPixels./min(repmat(maskSizes',[1 length(maskSizes)]),repmat(maskSizes,[length(maskSizes) 1]));
inferParams.im = im;
inferParams.masks = masks;
inferParams.names = names;
inferParams.labelColors = labelColors{1};
inferParams.greedy = useGreedy;
inferParams.w = countW;
timeRetSet=tic; 
[usedObjList] = InferObjs(objLs,scores,goodLOvlp,overlapScore,validBehindHist,overlapPenalityw,sizeRatio>sizeThresh,countParams,inferParams);
timeRetSet=toc(timeRetSet);
if(useGreedy)
    fileStats.timeInferObjsGreedy=timeRetSet;
else
    fileStats.timeInferObjsQP=timeRetSet;
end
fileStats.numObjs = length(objLsAll);
fileStats.numInferedObjs = length(usedObjList);
save(timingFile,'fileStats');
timeRetSet=tic; 
if(~rmStuffDet&&~useStuffParse&&useGreedy==3)
    objOrder = ones(1,sum(usedObjList));
else
    if(stuffBehind)
        objOrder = InferOrder(objLs(usedObjList),overlapScore(usedObjList,usedObjList),overlapBehindProb,maskSizes(usedObjList),myStuffLs);
    else
        objOrder = InferOrder(objLs(usedObjList),overlapScore(usedObjList,usedObjList),overlapBehindProb,maskSizes(usedObjList));
    end
end
timeRetSet=toc(timeRetSet);
fileStats.timeInferOrder=timeRetSet;
save(timingFile,'fileStats');
%DisplayObjects(im,masks(:,usedObjList),names(objLs(usedObjList)),3,objOrder, labelColors{1}(objLs(usedObjList),:) );
%fileName = fullfile(TestFold,testParams.MRFFold,'ObjectsPicked',fold,sprintf('%s-RetPoly%d-rmStDet%d-stffPrs%d.png',base,includeRetPoly,rmStuffDet,useStuffParse));
%make_dir(fileName);export_fig(fileName);
objs.masks = masks(:,usedObjList);
objs.Ls = objLs(usedObjList);
objs.order = objOrder;
fileName = fullfile(TestFold,testParams.MRFFold,'ObjectsPicked',sprintf('RetPoly%d-rmStDet%d-stffPrs%d-w%02d-cw%02d-gd%d-olp%d-stb%d-szt%d',includeRetPoly,rmStuffDet,useStuffParse,w,countW,double(useGreedy),double(useOLP),double(stuffBehind),sizeThresh),fold,[base '.mat']);
make_dir(fileName);save(fileName,'objs');
%objs = RefineMasks(im,objs,[]);
%fileName = fullfile(TestFold,testParams.MRFFold,'ObjectsPicked',sprintf('RetPoly%d-rmStDet%d-stffPrs%d-w%02d-gd%d-olp%d-stb%d-szt%d-ref',includeRetPoly,rmStuffDet,useStuffParse,w,double(useGreedy),double(useOLP),double(stuffBehind),sizeThresh),fold,[base '.mat']);
%make_dir(fileName);save(fileName,'objs');
%DisplayObjects( im,objs.masks,names(objs.Ls),4,objOrder, labelColors{1}(objs.Ls,:) );
usedObjListFirst = usedObjList;
objOrderFirst = objOrder;
masksFirst = masks;
objLsFirst = objLs;
for w2 = [.025 .05 .1 ] 
    usedObjList = usedObjListFirst;
    objOrder = objOrderFirst;
    masks = masksFirst;
    objLs = objLsFirst;
    for itts = 1:3
        saveInfo.testName = sprintf('DCRF-Sig-RetPoly%d-rmStDet%d-stffPrs%d-w%02d-w%.3f-cw%02d-gd%d-olp%d-stb%d-szt%d-itt%d',includeRetPoly,rmStuffDet,useStuffParse,w,w2,countW,double(useGreedy),double(useOLP),double(stuffBehind),sizeThresh,itts);
        augUnary = -log(AugmentUnary(ones(size(unary)).*.5,masks(:,usedObjList),objOrder,objLs(usedObjList),w2));
        L1 = SmoothCRF(im,unary+augUnary+sp.*sw,[],w,saveInfo);
        %DrawImLabels(im,L1,labelColors{1},names,[],1,0,2);

        goodLOvlp = cellfun(@(x,l) sum(validPixelOverlap(l,L1(x))),indexAll,objLsAll)./maskSizesAll;
        goodLPix = cellfun(@(x,l) sum(l==L1(x)),indexAll,objLsAll)./maskSizesAll;
        rm = goodLPix<(.1+((itts)/20));% | goodLOvlp<((itts+1)/10);
        if(~rmStuffDet&&~useStuffParse&&useGreedy==3)
            rm(:) = false;
        end
        index = indexAll(~rm);scores = scoresAll(~rm);maskSizes = maskSizesAll(~rm);objLs = objLsAll(~rm);masks = masksAll(:,~rm);goodLOvlp(rm) = [];
        objLs = cell2mat(objLs);
        %overlapPixels = single(masks')* single(masks);
        overlapPixels = zeros(size(masks,2));
        smasks = single(masks);
        for i = 1:100:size(masks,2)
            overlapPixels(i:min(i+99,size(masks,2)),:) = smasks(:,i:min(i+99,size(masks,2)))'*smasks;
        end
        clear smasks;
        overlapPenality = zeros(size(masks,2));
        overlapPenality2 = zeros(size(masks,2));
        overlapPenalityw = zeros(size(masks,2));
        sizeRatio = zeros(size(masks,2));
        %tic
        for l = unique(objLs)
            p = 1+predictorCell{2}(:,l);
            ind = find(objLs == l);
            dm = double(masks(:,ind));
            overlapPenality(ind,ind) = dm'*diag(sparse(p))*dm;
            for i = 1:length(ind)
                for j = (i+1):length(ind)
                    intM = dm(:,i)&dm(:,j);
                    if(any(intM~=0))
                        overlapPenality2(ind(i),ind(j)) = sum(p(intM));
                        overlapPenalityw(ind(i),ind(j)) = sum(p(intM)).*mean(validPixelOverlap(l,L0(intM)));
                    end
                end
            end

            os1 = repmat(maskSizes(ind),[length(ind) 1]);
            os2 = repmat(maskSizes(ind)',[1 length(ind)]);
            sizeRatio(ind,ind) = max(os1,os2)./min(os1,os2).*(overlapPixels(ind,ind)>0);
            %rm(inds(mxRatio>t))= true;
        end
        overlapPenality = (overlapPenality + overlapPenality')./2;
        overlapPenality = overlapPenality-diag(diag(overlapPenality));
        overlapPenality2 = overlapPenality2 + overlapPenality2';
        overlapPenalityw = overlapPenalityw + overlapPenalityw';
        if(~useOLP)
            overlapPenality = zeros(size(masks,2));
            overlapPenalityw = zeros(size(masks,2));
        end
        overlapScore = overlapPixels./min(repmat(maskSizes',[1 length(maskSizes)]),repmat(maskSizes,[length(maskSizes) 1]));
        inferParams.masks = masks;
        [usedObjList] = InferObjs(objLs,scores,goodLOvlp,overlapScore,validBehindHist,overlapPenalityw,sizeRatio>sizeThresh,countParams,inferParams);
        if(~rmStuffDet&&~useStuffParse&&useGreedy==3)
            objOrder = ones(1,sum(usedObjList));
        else
            if(stuffBehind)
                objOrder = InferOrder(objLs(usedObjList),overlapScore(usedObjList,usedObjList),overlapBehindProb,maskSizes(usedObjList),myStuffLs);
            else
                objOrder = InferOrder(objLs(usedObjList),overlapScore(usedObjList,usedObjList),overlapBehindProb,maskSizes(usedObjList));
            end
        end
        %DisplayObjects( im,masks(:,usedObjList),names(objLs(usedObjList)),4,objOrder, labelColors{1}(objLs(usedObjList),:) );
        %fileName = fullfile(TestFold,testParams.MRFFold,'ObjectsPicked',fold,sprintf('%s-RetPoly%d-rmStDet%d-stffPrs%d-w%.2f-itt%d.png',base,includeRetPoly,rmStuffDet,useStuffParse,w2,itts));
        %make_dir(fileName);export_fig(fileName);
        
        objs.masks = masks(:,usedObjList);
        objs.Ls = objLs(usedObjList);
        objs.order = objOrder;
        fileName = fullfile(TestFold,testParams.MRFFold,'ObjectsPicked',sprintf('RetPoly%d-rmStDet%d-stffPrs%d-w%02d-w%.2f-w%02d-gd%d-olp%d-stb%d-szt%d-itt%d',includeRetPoly,rmStuffDet,useStuffParse,w,w2,countW,double(useGreedy),double(useOLP),double(stuffBehind),sizeThresh,itts),fold,[base '.mat']);
        make_dir(fileName);save(fileName,'objs');
        %objs = RefineMasks(im,objs,[]);
        %fileName = fullfile(TestFold,testParams.MRFFold,'ObjectsPicked',sprintf('RetPoly%d-rmStDet%d-stffPrs%d-w%02d-w%.2f-gd%d-olp%d-stb%d-itt%d-szt%d-ref',includeRetPoly,rmStuffDet,useStuffParse,w,w2,double(useGreedy),double(useOLP),double(stuffBehind),sizeThresh,itts),fold,[base '.mat']);
        %make_dir(fileName);save(fileName,'objs');
        %DisplayObjects( im,objs.masks,names(objs.Ls),4,objOrder, labelColors{1}(objs.Ls,:) );

    end
    %objs = RefineMasks(im,objs,gPb_thin);
    %DisplayObjects( im,objs.masks,names(objs.Ls),2,objOrder, labelColors{1}(objs.Ls,:) );
    %fileName = fullfile('C:\Users\jtighe\Desktop\objrefine',[base '-refined.png']);
    %make_dir(fileName);export_fig(fileName);
    %DisplayObjects( im,masks(:,usedObjList),names(objLs(usedObjList)),3,objOrder, labelColors{1}(objLs(usedObjList),:) );
    %fileName = fullfile('C:\Users\jtighe\Desktop\objrefine',[base '-initial.png']);
    %make_dir(fileName);export_fig(fileName);
    %fileName = fullfile(TestFold,testParams.MRFFold,'ObjectsPicked',sprintf('RetPoly%d-rmStDet%d-stffPrs%d-w%02d-w%.2f-itt%d-refined',includeRetPoly,rmStuffDet,useStuffParse,w,w2,itts),fold,[base '.mat']);
    %make_dir(fileName);save(fileName,'objs');
end
end
end
end
end
end
end
end
end
end