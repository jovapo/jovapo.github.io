function [ objs ] = ComputeObjectFeatures( masks, feat )
%COMPUTEOBJECTFEATURES Summary of this function goes here
%   Detailed explanation goes here
    detBins = MakeBins([0 10],10);
    regBins = MakeBins([-40 40],10);
    [nPts, nDim] = size(feat);
    nLables = nDim/2;
    
    if(ndims(masks) > 2)
        [ro, co, ob] = size(masks);
        masks = reshape(masks,[ro*co ob]);
    end
    for o = 1:size(masks,2)
        mask = masks(:,o)==1;
        objFeats = feat(mask(:),:);
        objs(o).avg = mean(objFeats);
        objs(o).std = std(objFeats);
        objs(o).hist = [hist(objFeats(:,1:nLables),regBins) hist(objFeats(:,nLables+1:end),detBins)];
    end

end

