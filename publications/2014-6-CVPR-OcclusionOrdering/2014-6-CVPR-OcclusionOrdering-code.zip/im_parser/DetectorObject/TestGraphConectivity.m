dbNum = 5;
%SetUpConstants
seed = true;
fileList = trainFileList;
for i = 2:length(fileList)
    [fold base] = fileparts(fileList{i});
    im = imread(fullfile(HOMEIMAGES,fileList{i}));
    [ro co ch] = size(im);
    load(fullfile(HOMEDESCRIPTOR,'Pb','globalPb25',fold,[base '.mat']));
    show(im,1)
    show(gPb_thin,2)
    gPb_max = max(gPb_orient,[],3);
    show(gPb_max,3)
    
    
    if(seed)
        fg_cost = .4*ones(size(gPb_thin));
        fg_cost(1:end,1:5) = 1;    fg_cost(1:end,end-4:end) = 1;    fg_cost(end-4:end,1:end) = 1;    fg_cost(1:5,1:end) = 1;    fg_cost(24:25,24:25,1) = 0;
    else
        fg_cost = im(:,:,1)./max(im(:));
    end
    show(fg_cost,1);
    bg_cost = 1 - fg_cost;
    lambda = 0;
           
    DataCost = zeros([size(fg_cost),2]); 
    DataCost(:,:,1) = bg_cost - lambda;
    DataCost(:,:,2) = fg_cost + lambda;
    
    mu = mean(gPb_thin(gPb_thin>0));
    smoothness = exp(-gPb_thin./mu);
    %mu = mean(gPb_max(gPb_max>0));
    %smoothness = exp(-gPb_max./mu);gPb_orient
    mu = mean(gPb_orient(gPb_orient>0));
    smoothness = exp(-gPb_orient./mu);
    smoothness = smoothness - min(smoothness(:));
    show(smoothness(:,:,1),5);
    %{
    
    for s = [0 .1*2.^(1:10)]
        SmoothnessCost = s*(1 - eye(2));
        [gch] = GraphCut('open', DataCost, SmoothnessCost, smoothness, smoothness);
        %[gch labels] = GraphCut('expand', gch, [], 0);
        %[gch labels] = GraphCut('expand', gch, [], 1);
        [gch labels] = GraphCut('expand', gch);
        [gch] = GraphCut('close', gch);
        %labels = logical(labels);
        show(labels,4);
    end
    %}
    
    INTMUL = 1000;
    dInt = int32(round(DataCost.*INTMUL));
    dInt = reshape(dInt,[ro*co 2])';
    sInt = round(smoothness.*INTMUL/4);
    mu = mean(abs(im(2:end)-im(1:end-1)));
    normIm = double(im)./255;
    for con = 1:5
    for d = [2.^(2:8)]
        sparseSmooth = MakeSparseSmoothIm(normIm,con).*INTMUL/4;
        scInt = d.*(1 - eye(2));

        graph = GCO_Create(ro*co,2);
        GCO_SetVerbosity(graph,2);
        GCO_SetDataCost(graph,int32(dInt));
        %GCO_SetLabeling(graph,Lin);
        GCO_SetSmoothCost(graph,scInt);
        stemp = (round(sparseSmooth));
        GCO_SetNeighbors(graph,stemp);
        %GCO_SetLabeling(graph,Lin);
        %GCO_SetLabelOrder(graph,1:numTotalLabs);%randperm(numTotalLabs)
        GCO_Expansion(graph);
        %GCO_Swap(graph);
        labels = GCO_GetLabeling(graph);
        E = GCO_ComputeEnergy(graph);
        GCO_Delete(graph);
        show(reshape(labels,[ro co]),4);
    end
    end
    
    
    
    
    
    
    
end