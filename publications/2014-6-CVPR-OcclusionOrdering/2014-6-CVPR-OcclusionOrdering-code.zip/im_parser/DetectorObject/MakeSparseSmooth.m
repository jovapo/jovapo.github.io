function [ sparseSmooth ] = MakeSparseSmooth( smoothness, levels )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here)
[ro co or] = size(smoothness);
sparseSmooth = sparse(ro*co,ro*co);
cords = [];
for i = 1:levels
    cords = [cords; GenCords(i,0)];
    fprintf('%d ',2*length(cords));
end
dir = GetDir(cords);
[dir ndx] = sort(dir);
cords = cords(ndx,:);
w = ([dir(2:end); dir(1)+pi]-dir)./(2*sqrt(sum(cords.^2,2)));
w = w./sum(w);
bin = mod(floor(dir.*or./(pi)+.5),or)+1;
midPt = cords./2;
[X, Y] = meshgrid(1:co,1:ro);
for i = 1:length(w)
    X1 = X; Y1 = Y;
    X2 = X+cords(i,2);
    Y2 = Y+cords(i,1);
    rmndx = X2<1 | X2>co | Y2<1 | Y2>ro;
    X1(rmndx) = [];X2(rmndx) = []; Y1(rmndx) = []; Y2(rmndx) = [];
    XM = round(X1+midPt(i,2));
    YM = round(Y1+midPt(i,1));
    a = sub2ind([ro co],Y1,X1);
    b = sub2ind([ro co],Y2,X2);
    sparseSmooth = sparseSmooth + sparse(a,b,w(i).*smoothness(sub2ind([ro co],YM,XM)+(ro*co)*(bin(i)-1)),ro*co,ro*co)+ sparse(b,a,w(i).*smoothness(sub2ind([ro co],YM,XM)+(ro*co)*(bin(i)-1)),ro*co,ro*co);
end
end

function [cords] = GenCords(level,includePreviousDir)
    x = (0:level)';
    cords = [x level-x;
            x x-level;
            -x level-x;
            -x x-level];
    [dir,ndx] = unique(GetDir(cords));
    cords = cords((ndx),:);
    cords(dir>=pi,:) = [];
    dir(dir>=pi) = [];
    if(~includePreviousDir)
        %dir = GetDir(cords);
        preDir = [];
        for i = 1:level-1
            preDir = [preDir; GetDir(GenCords(i,1))];
        end
        [dirU ndx] = setdiff(dir,preDir);
        cords = cords(sort(ndx),:);
    end
end

function [dir] = GetDir(cords)
    dir = atan(cords(:,1)./cords(:,2))+(cords(:,2)<0)*pi;
    dir(dir<0) = dir(dir<0)+2*pi;
end