function imOut =  DisplayObjectsLayered( im,masks,names,figNo,order,labelColors, lw )
[ro co ch] = size(im);
depths = unique(order);

for o = depths(:)'
    imt{o} = DisplayObjects(im,masks(:,order==o),names(order==o),figNo+1,[],labelColors(order==o,:),0);
end
f = figure(figNo);
clf;
%set(f,'Renderer','OpenGL');

imw =  800;
if(~exist('lw','var'))
    lw = 2;
end
imRatio = (ro/co)/lw;
set(f, 'Position', [0, 0, imw, imRatio*imw]);
h = axes('Units','normalized', ...
        'Position',[0 0 1 1], ...
        'XTickLabel','', ...
        'YTickLabel','');
hold on;
xView = -.80*length(depths).^2+12.5*length(depths)+119.75;
fprintf('%.1f\n',xView);
view(xView,6);
masks2 = reshape(masks,[ro co size(masks,2)]);

div = max(ro,co)/255;
[y z] = meshgrid(1:round(co/4),1:round(ro/4));
x=ones(round(ro/4),round(co/4));
md = max(depths-1);
s = 9.9;
for o = depths(:)'
    mask = false(ro,co);
    for i = find(order==o)
        mask = mask|masks2(:,:,i);
    end
    alphaM = .4+.6*double(mask(end:-2:1,1:2:end));
    alphaM(1,1) = 0;
    surface((s*(o-1)/md).*x,y,z,imresize(imt{o}(end:-1:1,:,:),.5),'FaceColor','texture',...
        'EdgeColor','none','AlphaData',alphaM,'FaceAlpha','texture');
end
drawnow;
axis off;
hold off;
imOut = export_fig('-transparent');
[ro co ch] = size(imOut);
if((ro/co)<imRatio)
    padBy = round((imRatio*co-ro)/2);
    imOut = padarray(imOut,[padBy 0 0],255);
else
    padBy = round((ro/imRatio-co)/2);
    imOut = padarray(imOut,[0 padBy 0],255);
end