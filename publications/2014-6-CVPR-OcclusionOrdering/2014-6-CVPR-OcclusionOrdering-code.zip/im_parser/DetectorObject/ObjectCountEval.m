SetUpConstants;
range = 1:length(testFileList);
%gtBBs = LoadGtBBs(HOMEANNOTATIONS,testFileList(range));

addMissed = true;

testTypes = fields(allBB);
testTypes = {'prunClScore'};
range = unique(allBB.(testTypes{1})(:,5));
oThresh= .5;
MyCleanUp;
fcid = fopen(fullfile(TestFold,'Count_tests.txt'),'w');
fid = fopen(fullfile(TestFold,'AUC_tests.txt'),'w');
labelInstanceCount = zeros(size(Labels{1}));
for l = 1:length(Labels{1})
    labelInstanceCount(l) = sum(gtBBs(:,6)==l);
end
[useLCount lRange] = sort(labelInstanceCount,'descend');
lRange(useLCount==0) = [];
useLCount(useLCount==0) = [];

fprintf(fid,'\t');
for l = lRange
    fprintf(fid,'%s\t',Labels{1}{l});
end
fprintf(fid,'\n');
fprintf(fid,'\t');
for l = 1:length(useLCount)
    fprintf(fid,'%d\t',useLCount);
end
fprintf(fid,'\n');
for tt = 1:length(testTypes)
    stype = 'score';
    for sNdx = 7:8
        fprintf(fid,'%s-%s\t',testTypes{tt},stype);
        gtLCount = zeros(max(range),length(Labels{1}));
        predCount = zeros(max(range),length(Labels{1}));
        for l = lRange
            compBB = allBB.(testTypes{tt})(allBB.(testTypes{tt})(:,6)==l,:);
            lscore = compBB(:,sNdx);
            lgood = zeros(size(lscore));
            addToBad = 0;
            numPos = 0;
            for i = range(:)'
                imGtBB = gtBBs(gtBBs(:,5)==i&gtBBs(:,6)==l,1:4);
                bbNdx = compBB(:,5)==i;
                numPos = numPos + size(imGtBB,1);
                if(isempty(imGtBB))
                    continue;
                end
                imCompBB = compBB(bbNdx,1:4);
                gtLCount(i,l) = size(imGtBB,1);
                predCount(i,l) = size(imCompBB,1);
                overlap = FindOverlap(imGtBB,imCompBB);
                if(~isempty(overlap))
                    [olm ndx] = max(overlap,[],2);
                    overlap = zeros(size(overlap));
                    overlap(sub2ind(size(overlap),(1:length(ndx))',ndx)) = olm;
                    lgood(bbNdx) = (max(overlap,[],1)>oThresh);
                    addToBad = addToBad + sum(max(overlap,[],2)<oThresh);
                else
                    addToBad = addToBad + size(imGtBB,1);
                end
                %{
                if((sum(max(overlap,[],2)<oThresh)+sum(max(overlap,[],1)>oThresh))~=size(imGtBB,1))
                    fprintf('Error\n');
                    im = imread(fullfile(HOME,'Images',testFileList{i}));
                    [ro co ch] = size(im);
                    show(im,1);hold on;
                    DrawBBs(imGtBB,'g');
                    DrawBBs(imCompBB,'b');
                    hold off;
                    keyboard;
                end
                %}
            end
            if(addMissed)
                lscore = [lscore; zeros(addToBad,1)];
                lgood = [lgood; ones(addToBad,1)];
            end
            auc = SampleError(lscore,lgood,'AUC');
            if(isnan(auc)) auc = 0; end
            [s ndx] = sort(lscore,'descend');
            tp = lgood(ndx);
            fp = tp == 0;
            fp=cumsum(fp);
            tp=cumsum(tp);
            rec=tp/(numPos);
            prec=tp./(fp+tp);
            ap = VOCap(rec,prec);
            fprintf(fid,'%.5f\t',ap);
        end
        
        fprintf(fcid,'%s-%s\n',testTypes{tt},stype);
        for l = 1:length(Labels{1})
            fprintf(fcid,'%s\t',Labels{1}{l});
        end
        fprintf(fcid,'\n');
        for i = range(:)'
            for l = 1:length(Labels{1})
                fprintf(fcid,'%d\t',gtLCount(i,l));
            end
            fprintf(fcid,'\n');
        end
        for l = 1:length(Labels{1})
            fprintf(fcid,'%d\t',sum(gtLCount(:,l)));
        end
        fprintf(fcid,'\n');
        for l = 1:length(Labels{1})
            fprintf(fcid,'%s\t',Labels{1}{l});
        end
        fprintf(fcid,'\n');
        for i = range(:)'
            for l = 1:length(Labels{1})
                fprintf(fcid,'%d\t',predCount(i,l));
            end
            fprintf(fcid,'\n');
        end
        for l = 1:length(Labels{1})
            fprintf(fcid,'%d\t',sum(predCount(:,l)));
        end
        fprintf(fcid,'\n\n');
        
        stype = 'count';
        fprintf(fid,'\n');
    end
end
fclose(fid);