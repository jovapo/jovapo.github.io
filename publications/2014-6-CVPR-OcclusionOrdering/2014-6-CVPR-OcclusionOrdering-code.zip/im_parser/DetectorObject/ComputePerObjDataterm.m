SetUpConstants;
if(~exist('trainIndex','var'))
    LoadIndexScript;
end
testParams.Rs = Rs;
if(~exist('fullSPDesc','var'))
    fullSPDesc = cell(size(trainIndex));
end

%trainIndex = [];
testParams.TestString = 'RunOnTraining';
%testParams.TestString = 'FinalVerification';
TestFold = fullfile(HOMEDATA,testParams.TestString);
myRandomize;
testFileList = trainFileList;
rangeTest = [rangeTrain(randperm(length(rangeTrain))) randperm(setdiff(length(testFileList),rangeTrain))];
%rangeTest = [rangeTest(randperm(length(rangeTest)))];% randperm(setdiff(length(testFileList),rangeTest))];
%rangeTest = [rangeTrain(randperm(length(rangeTrain))) randperm(setdiff(length(testFileList),rangeTrain))];
%rangeTest = [rangeTest(randperm(length(rangeTest))) randperm(setdiff(length(testFileList),rangeTest))];
%rangeTest = 102;

testParams.doneDir = 'Done';
testParams.BusyFold = 'Busy';

if(isempty(trainGlobalDesc.spatialPryScaled))
    %testGlobalDesc = ComputeGlobalDescriptors(testFileList, HOMEIMAGES, HOMELABELSETS, HOMEDATA);
    %trainGlobalDesc = ComputeGlobalDescriptors(trainFileList, HOMEIMAGES, HOMELABELSETS, HOMEDATA);
end
%testGlobalDesc = trainGlobalDesc;

%pfig = ProgressBar('Computing Dataterm');
glSuffix = '';
for f = rangeTest(:)'
    [fold base] = fileparts(testFileList{f});
    %{-
    busyFile = fullfile(TestFold,'Busy',fold,base);
    if(isfield(testParams,'doneDir'))
        doneFile = fullfile(TestFold,testParams.doneDir,fold,[base '.mat']);
        if(exist(doneFile,'file'))
            %fprintf('Already Done\n');
            continue;
        end
    end
    if(isfield(testParams,'BusyFold'))
        busyFile = fullfile(TestFold,testParams.BusyFold,fold,base);
    end
    if(exist(busyFile,'file'))
        continue;
    end
    %mkdir(busyFile);
    fprintf('Starting %s\n',testFileList{f});
    %}
    try
    im = imread(fullfile(HOME,'Images',testFileList{f}));
    [ro co ch] = size(im);
    baseFName = fullfile(fold,base);
    timingFile = fullfile(TestFold,'Timing',fold,[base '.mat']);make_dir(timingFile);
    if(exist(timingFile,'file'))
        load(timingFile);
    else
        fileStats = [];
    end
    fileStats.imSize = [ro co];
    
    timeRetSet=tic;  [retInds rank]= FindRetrievalSet(trainGlobalDesc,SelectDesc(testGlobalDesc,f,1),TestFold,baseFName,testParams,glSuffix);  timeRetSet=toc(timeRetSet);
    if(length(retInds)~=length(trainFileList))
        delete(fullfile(fullfile(HOMECLASSIFIER),'RetrievalSet',fold,[base '.mat']));
        [retInds rank] = FindRetrievalSet(trainGlobalDesc,SelectDesc(testGlobalDesc,f,1),fullfile(HOMECLASSIFIER),fullfile(fold,base),testParams,'');
    end
    if(~isfield(fileStats,'timeRetSet') || fileStats.timeRetSet<timeRetSet)
        fileStats.timeRetSet=timeRetSet;
    end
    save(timingFile,'fileStats');
    %{-
    rmInds = find(strcmp(trainFileList,testFileList{f}));
    if(isfield(testParams,'numFrames2Skip'))
        rmInds = [rmInds-testParams.numFrames2Skip:rmInds+testParams.numFrames2Skip];
    end
    [a keepInds] = setdiff(retInds,rmInds);
    keepInds = sort(keepInds);
    retInds = retInds(keepInds);
    
    svmstr = '';
    %% Superpixel dataterm
    if(~isempty(trainIndex))
        Kndx = 1;
        classifierStr = repmat('0',[1 length(HOMELABELSETS)]);
        probSuffix = sprintf('K%d',testParams.K(Kndx));
        clear imSP testImSPDesc;
        [testImSPDesc imSP] = LoadSegmentDesc(testFileList(f),[],HOMETESTDATA,testParams.segmentDescriptors,testParams.K,testParams.segSuffix);
        probPerLabel = cell(size(HOMELABELSETS));
        dataCost = cell(size(probPerLabel));
        for ls=1:length(HOMELABELSETS)
            [foo labelSet] = fileparts(HOMELABELSETS{ls});
            if(strcmp(labelSet,'LabelsForgroundBK'))
                FGSet = ls;
            end
            if(isempty(classifiers{ls}))
                if(testParams.retSetSize == length(trainFileList) )
                    retSetIndex = trainIndex{ls,Kndx};
                else
                    [retSetIndex descMask] = PruneIndex(trainIndex{ls,Kndx},retInds,testParams.retSetSize,testParams.minSPinRetSet);
                end
                suffix = sprintf('R%dK%dTNN%d',testParams.retSetSize,testParams.K(Kndx),testParams.targetNN);%nn%d  ,testParams.targetNN
                suffix = [suffix testParams.globalDescSuffix];
                suffix = [suffix glSuffix];
                probSuffix = [suffix '-sc' myN2S(testParams.smoothingConst) testParams.probType];
                labelNums = 1:length(trainCounts{ls});
                probPerLabel{ls} = GetAllProbPerLabel(fullfile(TestFold,labelSet),baseFName,probSuffix,retSetIndex,[],labelNums,trainCounts{ls,Kndx},testParams.probType,testParams.smoothingConst,1); %#ok<AGROW>
                if(~isempty(probPerLabel{ls}) && size(probPerLabel{ls},1)~=size(testImSPDesc.sift_hist_dial,1))
                    suffix = [suffix 'added'];
                    probPerLabel{ls} = [];
                end
                if(isempty(probPerLabel{ls}))
                    rawNNs = DoRNNSearch(testImSPDesc,[],fullfile(TestFold,labelSet),baseFName,suffix,testParams,Kndx);
                    if(isempty(rawNNs))
                        if(testParams.retSetSize >= length(trainFileList) )
                            if(isempty(fullSPDesc{ls,Kndx}))
                                fullSPDesc{ls,Kndx} = LoadSegmentDesc(trainFileList,retSetIndex,HOMEDATA,testParams.segmentDescriptors,testParams.K(Kndx),testParams.segSuffix);
                            end
                        end
                        if(isempty(fullSPDesc{ls,Kndx}))
                            retSetSPDesc = LoadSegmentDesc(trainFileList,retSetIndex,HOMEDATA,testParams.segmentDescriptors,testParams.K(Kndx),testParams.segSuffix);
                        else
                            retSetSPDesc = [];
                            for dNdx = 1:length(testParams.segmentDescriptors)
                                retSetSPDesc.(testParams.segmentDescriptors{dNdx}) = fullSPDesc{ls,Kndx}.(testParams.segmentDescriptors{dNdx})(descMask,:);
                            end
                        end
                        %timing(f,2)=toc;  rawNNs = DoRNNSearch(testImSPDesc,retSetSPDesc,fullfile(TestFold,labelSet),baseFName,suffix,testParams,Kndx);  timing(f,2)=toc-timing(f,2);
                        [rawNNs fileStats.timeNNSearch totalMatches] = DoRNNSearch(testImSPDesc,retSetSPDesc,fullfile(TestFold,labelSet),baseFName,suffix,testParams,Kndx,0);
                        fprintf('%03d: %d\n',f',totalMatches);
                        clear retSetSPDesc;
                    end
                    [probPerLabel{ls} fileStats.timeGetProb] = GetAllProbPerLabel(fullfile(TestFold,labelSet),baseFName,probSuffix,retSetIndex,rawNNs,labelNums,trainCounts{ls,Kndx},testParams.probType,testParams.smoothingConst,1);
                    save(timingFile,'fileStats');
                end

                %nomalize the datacosts for mrf. This is especiall important when using some classifier or when some labelsets are under represented
                dataCost{ls} = testParams.maxPenality*(1-1./(1+exp(-(testParams.BConst(2)*probPerLabel{ls}+testParams.BConst(1)))));
            else
                %NOT REFACTORED YET !!
                probCacheFile = fullfile(TestFold,'ClassifierOutput',[labelSet testParams.CLSuffix],[baseFName  '.mat']);
                classifierStr(ls) = '1';
                if(~exist(probCacheFile,'file'))
                    features = GetFeaturesForClassifier(testImSPDesc);
                    prob = test_boosted_dt_mc(classifiers{ls}, features);
                    make_dir(probCacheFile);save(probCacheFile,'prob');
                else
                    clear prob;
                    load(probCacheFile);
                end
                probPerLabel{ls} = prob;
                if(size(prob,2) == 1 && length(Labels{ls}) ==2)
                    probPerLabel{ls}(:,2) = -prob;
                end
                if(ls == FGSet)
                    probPerLabel{ls}(:,1) = probPerLabel{ls}(:,1);
                    probPerLabel{ls}(:,2) = probPerLabel{ls}(:,2);
                end

                %nomalize the datacosts for mrf. This is especiall important when using some classifier or when some labelsets are under represented
                dataCost{ls} = testParams.maxPenality*(1-1./(1+exp(-(testParams.BConstCla(2)*probPerLabel{ls}+testParams.BConstCla(1)))));
            end
        end

        fprintf('Finished SuperParsing\n');
    end

    %% Detector Dataterm
    retIndsSm = retInds(1:min(testParams.retSetSize,length(retInds)));
    ls = 1;
    min_val = -1;
    detectorSuffix = [testParams.ModelFold '-MM' myN2S(testParams.MaxModelPerCls,4) '-R' myN2S(testParams.retSetSize)];
    detectorDataSuffix = [detectorSuffix '-NMS' num2str(testParams.NMS)];
    dataResultFile = fullfile(TestFold,'ExemplarDataTerm',detectorDataSuffix,fold,[base '.mat']);
    detectionResultFile = fullfile(TestFold,'ExemplarDetectionResults',detectorDataSuffix,fold,[base '.mat']);
    testResultFile = fullfile(TestFold,'ExemplarResult',detectorSuffix,fold,[base '.mat']);
    clear dataTerm;
    if(true || ~exist(dataResultFile,'file') || ~exist(detectionResultFile,'file') || ~exist(testResultFile,'file'))
        %load(dataResultFile);
    %end
    %if(~exist('dataTerm','var'))
        clear test_struct polygons;
        if(exist(detectionResultFile,'file'))
            %load(detectionResultFile);
        end
        if(~exist('test_struct','var'))
            allModels = cell(0);
            fileStats.timeLoadDetectors = tic;
            for rNdx = 1:length(retIndsSm)
                [retFold retBase] = fileparts(trainFileList{retIndsSm(rNdx)});
                modelFile = fullfile(HOMETESTDATA,'Classifier','Exemplar',testParams.ModelFold,retFold,[retBase '.mat']);
                if(exist(modelFile,'file'))
                    load(modelFile);
                    models = AddPolyToModel(fullfile(HOME,'Annotations'),models,modelFile);
                    allModels = [allModels(:); models(:)];
                end
            end
            fileStats.timeLoadDetectors = toc(fileStats.timeLoadDetectors);
            modelCls = cellfun2(@(x)x.cls,allModels);
            [unmodelCls a mNdx] = unique(modelCls);
            fileStats.numDetRaw = length(modelCls);
            if(testParams.MaxModelPerCls>0)
                [a b] = UniqueAndCounts(mNdx);
                rmNdx = [];
                for ovNdx = find(b>testParams.MaxModelPerCls)'
                    ndx = find(mNdx == a(ovNdx));
                    rmNdx = [rmNdx; ndx(testParams.MaxModelPerCls+1:end)];
                end
                allModels(rmNdx) = [];
                modelCls(rmNdx) = [];
                [unmodelCls a mNdx] = unique(modelCls);
            end
            m2lnum = 1:length(unmodelCls);
            fileStats.numDetReduced = length(modelCls);
            for m2lNdx = 1:length(unmodelCls)
                m2lnum(m2lNdx) = find(strcmp(strtrim(unmodelCls{m2lNdx}),Labels{ls}));
            end
            modelLnum = m2lnum(mNdx);

            
            if(exist(testResultFile,'file'))
                load(testResultFile);
            else
                fileStats.timeDetect = tic;test_grid = esvm_detect_imageset({fullfile(HOME,'Images',testFileList{f})}, allModels, detectorParams); fileStats.timeDetect = toc(fileStats.timeDetect);
                fileStats.numDetect = size(test_grid{1}.coarse_boxes,1);
                save(timingFile,'fileStats');
                make_dir(testResultFile);save(testResultFile,'test_grid');
            end
            cls_test_grid = cell(size(Labels{ls}));
            for l = 1:length(Labels{ls});
                cls_test_grid{l} = test_grid{1};
                if(~isempty(cls_test_grid{l}.coarse_boxes))
                    rmNdx = modelLnum(cls_test_grid{l}.coarse_boxes(:,6))~=l;
                    cls_test_grid{l}.coarse_boxes(rmNdx,:) = [];
                    cls_test_grid{l}.bboxes(rmNdx,:) = [];
                end
            end
            M = [];
            detectorParams.do_nms = testParams.NMS;
            test_struct = esvm_pool_exemplar_dets(cls_test_grid, allModels, M, detectorParams);
            
            if(isfield(allModels{1}.polygon,'pt'))
                polygons = cellfun2(@(x) x.polygon.pt,allModels);
            else
                polygons = cellfun2(@(x) x.polygon,allModels);
            end
            make_dir(detectionResultFile);save(detectionResultFile,'test_struct','polygons');
        end
        %{-
        clear dataTermAvg;
        if(exist(dataResultFile,'file'))
            load(dataResultFile);
        else
            dataTerm = zeros([ro co length(Labels{ls})]);
            dataTermMax = zeros([ro co length(Labels{ls})]);
            fileStats.timeProjectDetectors = tic;
            for l = 1:length(test_struct.unclipped_boxes)
                [dt] = ProjectDetectorResponses(im,test_struct.final_boxes{l},polygons,min_val);
                dataTerm(:,:,l) = dt;
            end
            fileStats.timeProjectDetectors = toc(fileStats.timeProjectDetectors);
            save(timingFile,'fileStats');
            make_dir(dataResultFile);save(dataResultFile,'dataTerm','-v7.3');
        end
        %}0
    end
    fprintf('Finished Detectors\n');
    %ProgressBar(pfig,find(f==rangeTest),length(rangeTest));
    
    if(isfield(testParams,'doneDir'))
        a = 1;make_dir(doneFile); save(doneFile,'a');%mkdir(doneFile);
    end
    %}
    catch ME
        ME
        ME.stack
    end
    try
        rmdir(busyFile);
    end
    try
        %rmdir(fileparts(busyFile));
    end
    try
        %rmdir(fileparts(fileparts(busyFile)));
    end
    try
        %rmdir(fileparts(fileparts(busyFile)));
    end
    %save(timingFile,'fileStats');
end
%close(pfig);
