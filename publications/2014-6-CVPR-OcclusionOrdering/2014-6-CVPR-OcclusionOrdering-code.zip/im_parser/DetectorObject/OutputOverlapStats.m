function OutputOverlapStats(HOME,names,overlapStats)

outfile = fullfile(HOME,'overlap.xls');
fid = fopen(outfile,'w');

WriteStatsToFile(fid,names,overlapStats.pixelCount,overlapStats.overlapPixel);
WriteStatsToFile(fid,names,overlapStats.polyCount,overlapStats.overlapAvgScore);
WriteStatsToFile(fid,names,overlapStats.polyCount,overlapStats.overlapCount);

fclose(fid)

function WriteStatsToFile(fid,names,count,overlap)
[count, order] = sort(count,'descend');
overlap = triu(overlap)+tril(overlap',-1);
overlap = overlap(order,:);
overlap = overlap(:,order);
names = names(order);

fprintf(fid,'\t\t');
for i = 1:length(names)
    fprintf(fid,'%s\t',names{i});
end
fprintf(fid,'\n');

for i = 1:length(names)
    fprintf(fid,'%s\t',names{i});
    fprintf(fid,'%f\t',count(i));
    fprintf(fid,'%f\t',overlap(i,:));
    fprintf(fid,'\n');
end
fprintf(fid,'\n');
    