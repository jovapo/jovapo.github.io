function overlap = OverlapPolygonBDist(polygons,d,subsample)
if(~exist('d','var'))
    d = 4;
end
if(~exist('subsample','var'))
    subsample = 4;
end
overlap = zeros(length(polygons));
co =  ceil(max(cell2mat(arrayfun(@(x) x.x,polygons,'UniformOutput',false)'))/subsample);
ro =  ceil(max(cell2mat(arrayfun(@(x) x.y,polygons,'UniformOutput',false)'))/subsample);
%masks = zeros(ro*co,length(polygons));
%{
works for old matlab but is slower
boundaries = cell(length(polygons),1);
tic
for i = 1:length(polygons)
    m = poly2mask(polygons(i).x./subsample,polygons(i).y./subsample,ro,co);
    boundaries{i} = bwboundaries(m);boundaries{i}=boundaries{i}{1};
end
toc
%}

boundaries = cell(length(polygons),1);
shapeInserter = vision.ShapeInserter('Shape','Polygons','BorderColor','White');
base = zeros(ro,co);
for i = 1:length(polygons)
    poly = [polygons(i).x; polygons(i).y];
    if(isempty(poly))
        boundaries{i} = [1 1];
        continue;
    end
    m = step(shapeInserter,base,poly(:)'./subsample);
    [a b] = find(m);
    boundaries{i} = [a b];
end

%optimized: this is the best
%sums = cellfun(@(x)sum(x),masks);
for i = 1:length(polygons)
    for j = i:length(polygons)
        dist = dist2(boundaries{i}, boundaries{j});
        dists = [min(dist) min(dist')];
        overlap(i,j) = sum(dists<d)/length(dists);
    end
    %}
end
overlap(isnan(overlap)) = 0;


    