function E = ComputePerObjEnergy(L,objDataTerm,overlapScore,overlapPixels,objLabel,overlapBehindHist,labelPrior)

[a, objOrder] = sort(L);
objOrder(a<=0) = [];

E = 0;
numBins = size(overlapBehindHist,3);

for i = objOrder(:)'
    E = E + objDataTerm(i);
end

for i = 1:length(objOrder)
    objBehind = objOrder(i);
    for j = i+1:length(objOrder)
        objInfront = objOrder(j);
        if(overlapScore(objBehind,objInfront)>0)
            bin = min(ceil(mod((numBins)*overlapScore(objBehind,objInfront),numBins+1)),numBins);
            E = E + overlapBehindHist(objLabel(objBehind),objLabel(objInfront),bin)*overlapPixels(objBehind,objInfront);
        end
    end
end
