testName = 'trial';
baseFName = fullfile(fold,base);
Labels{1} = labelList;
imSP = superPixels;
MAX_COST = 10000;
MAX_EXPECTED = 10;
pn = 1./(1+exp(-predictors));
ps = sum(pn,2);
pn = -log(bsxfun(@rdivide,pn,ps));
dataCost{1} = pn./max(pn(:));
dataCost{1} = int32(dataCost{1}*MAX_COST);
clear params;
params.edgeParam = 11;
params.connected=8;
params.S{1} = S;
params.names{1} = names;
smoothOver = [2.^(0:5)];

[ro co ch] = size(im);
gausianParams.x_std = 3;
gausianParams.y_std = 3;
gausianParams.weight = 3;
gausianParams.pixelNorm = false;
crfParams.gausianParams = gausianParams;
bilateralParams.dist_std = 15;
bilateralParams.co_std = 20;
bilateralParams.weight = 10;
bilateralParams.pixelNorm = false;
crfParams.bilateralParams = bilateralParams;
crfParams.itterations = 10;
crfParams.S = S;
crfParams.names = names;
for w1 = [0 1 2 4 8 16 32]
    for w2 = 1%[.5 1 2]
        crfParams.gausianParams.weight = w1;
        crfParams.bilateralParams.weight = w1/w2;
        for xstd = [2 3 6]
        crfParams.gausianParams.x_std = xstd;
        crfParams.gausianParams.y_std = xstd;
        for dstd = [10 15 20]
        crfParams.bilateralParams.dist_std = dstd;
        testName = sprintf('DCRF-SigRowNorm-%s-w%03d-w%03d-xstd%02d-dstd%03d',testSVMList{i},w1,w1/w2,xstd,dstd);
        [LabelPixels] = PixDenseCRF(fullfile(TestFold,testParams.MRFFold),HOMELABELSETS{1},testName,baseFName,Labels{1},im,pn,crfParams);
        %show(LabelPixels);set(gcf,'name', ['  ' testName]);drawnow;
    end
end
    end
end
dataCost{1} = pn./max(pn(:));
dataCost{1} = int32(dataCost{1}*MAX_COST);
clear params;
params.edgeParam = 11;
params.connected=8;
params.S{1} = S;
params.names{1} = names;
smoothOver =  [2.^(0:5)];
timerVar = 0;
for smoothing = smoothOver
    testName = sprintf('%s-SS%03d',testSVMList{i},smoothing);
    smoothingMatrix = smoothing*(ones(length(labelList))-eye(length(labelList)));
    timerVarTic = tic;
    [LabelPixels] = MultiLevelPixMRF(fullfile(TestFold,testParams.MRFFold),HOMELABELSETS,testName,baseFName,Labels,imSP,im,dataCost,smoothingMatrix,[],params);
    timerVar=timerVar+toc(timerVarTic);
    %show(LabelPixels{1},1);
end
    
