function overlap = OverlapPolygonBIntUn(polygons,d,subsample)
if(~exist('d','var'))
    d = 4;
end
if(~exist('subsample','var'))
    subsample = 4;
end
overlap = zeros(length(polygons));
co =  ceil(max(cell2mat(arrayfun(@(x) x.x,polygons,'UniformOutput',false)'))/subsample);
ro =  ceil(max(cell2mat(arrayfun(@(x) x.y,polygons,'UniformOutput',false)'))/subsample);
masks = cell(length(polygons),1);
shapeInserter = vision.ShapeInserter('Shape','Polygons','BorderColor','White');
base = zeros(ro,co);
for i = 1:length(polygons)
    poly = [polygons(i).x; polygons(i).y];
    if(isempty(poly))
        m = base;
    else
        m = step(shapeInserter,base,poly(:)'./subsample);
    end
    if(d>0)
        G = fspecial('gaussian',[ceil(d+1) ceil(d+1)],sqrt(d));
        masks{i} = reshape(conv2(double(m),G,'same'),ro*co,1);
    else
        masks{i} = reshape(double(m),ro*co,1);
    end
end
%{ 
%works for old matlab but slower
for i = 1:length(polygons)
    m = poly2mask(polygons(i).x./subsample,polygons(i).y./subsample,ro,co);
    b = bwboundaries(m);b=b{1};
    m(:,:) = false;
    m(sub2ind(size(m),b(:,1),b(:,2))) = true;
    G = fspecial('gaussian',[ceil(d+1) ceil(d+1)],sqrt(d));
    masks{i} = reshape(conv2(double(m),G,'same'),ro*co,1);
end
%}
%{
slower
sums = cellfun(@(x)sum(x.*x),masks);
for i = 1:length(polygons)
    for j = i:length(polygons)
        overlap(i,j) = sum(masks{i}.*masks{j});
        overlap(i,j) = overlap(i,j)/(sums(i)+sums(j)-overlap(i,j));
        if(isnan(overlap(i,j)))
            if(i==j)
                overlap(i,j) = 1;
            else
                overlap(i,j) = 0;
            end
        end
        %o = sum(min(masks{i},masks{j}))/sum(max(masks{i},masks{j}));
        %if(o<overlap(i,j))
        %    fprintf('o: %f ov: %f\n',o,overlap(i,j));
        %end
    end
    %}-
end
%}
masks = cell2mat(masks');
rawPixOl = masks'*masks; 
polySize  = eps+diag(rawPixOl);
overlap = rawPixOl./(repmat(polySize,[1 length(polySize)])+repmat(polySize',[length(polySize) 1])-rawPixOl);



    