function params = ComputePolyCountParams(polyCounts)

params = zeros(size(polyCounts,1),2);

for l = 1:size(polyCounts,1)
    v = polyCounts(l,:);
    if(sum(v)==0)
        params(l,:) = [1 .5];
        continue;
    end
    bins = 1:length(v);
    m = sum(v.*bins)./sum(v);
    s = sqrt(sum(v.*((bins-m).^2))./(sum(v)-1));
    %{
    datapts = [];
    for i = 1:length(v)
        datapts = [datapts repmat(i,[1 v(i)])];
    end
    ps = fitdist(datapts(:),'poisson');
    %}
    
    mn = round(m);
    v2 = [v(end:-1:mn*2) v];
    bins2 = (1+length(v)-length(v2)):length(v);
    m2 = sum(v2.*bins2)./sum(v2);
    s2 = sqrt(sum(v2.*((bins2-m2).^2))./(sum(v2)-1));
    if(s==0 || isnan(s))
        s = .1;
    end
    params(l,:) = [m2 s];
    %{
	hold off;
    bar(bins,v./sum(v),[bins(1),bins(end)],'hist');
    x = bins2(1):.1:bins2(end);
    y = exp(-(x-m).^2./(2*s^2))./(s*sqrt(2*pi));
    hold on;plot(x,y,'r');
    
    y = exp(-(x-m2).^2./(2*s2^2))./(s2*sqrt(2*pi));
    hold on;plot(x,y,'b');
    
    y = pdf(ps,x);
    hold on;plot(x,y,'g');
    %}
end