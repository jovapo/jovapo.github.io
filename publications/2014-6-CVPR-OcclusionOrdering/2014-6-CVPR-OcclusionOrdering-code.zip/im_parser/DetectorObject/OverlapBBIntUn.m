function overlap = OverlapBBIntUn(boxes)
overlap =  zeros(size(boxes,1));
x1 = boxes(:,1);
y1 = boxes(:,2);
x2 = boxes(:,3);
y2 = boxes(:,4);

area = (x2-x1+1) .* (y2-y1+1);

for i = 1:size(boxes,1);
  xx1 = max(x1(i), x1(i:end));
  yy1 = max(y1(i), y1(i:end));
  xx2 = min(x2(i), x2(i:end));
  yy2 = min(y2(i), y2(i:end));

  w = max(0.0, xx2-xx1+1);
  h = max(0.0, yy2-yy1+1);

  overlap(i,i:end) = w.*h ./ (area(i)+area(i:end)-w.*h);
end
    