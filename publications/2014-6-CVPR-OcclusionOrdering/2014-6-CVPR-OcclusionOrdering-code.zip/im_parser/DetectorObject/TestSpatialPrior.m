
unary = 1./(1+exp(-predictorCell{1}));
%ps = sum(unaryProb,2);
%unaryProbNorm = bsxfun(@rdivide,unaryProb,ps);
%unaryNorm = -log(unaryProbNorm);
unary = -log(unary);

[ro co ch] = size(im);
sp = imresize(-log(spatialPrior),[ro co],'nearest');
sp = reshape(sp,size(unary));

w = 4;
saveInfo.HOMEDATA = fullfile(TestFold,testParams.MRFFold);
saveInfo.HOMELABELSET = HOMELABELSETS{1};
saveInfo.baseFName = fullfile(fold,base);
saveInfo.Labels = Labels{1};
saveInfo.names = names;
saveInfo.S = S;


L0 = S;
for w = [0 4 8 16]
    for sw = [0 .05 .1 .2]
        saveInfo.testName = sprintf('DCRF-Sig-mynorm-%s-sw%.2f-w%02d',svmName,sw,w);
        L1 = SmoothCRF(im,unary+sp.*sw,[],w,saveInfo);
        L0=L1;
    end
end
clear unary sp;
