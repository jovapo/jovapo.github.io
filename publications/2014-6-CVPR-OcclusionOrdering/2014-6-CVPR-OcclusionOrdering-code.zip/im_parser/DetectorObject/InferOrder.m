function [objOrder] = InferOrder(objLs,overlapScore,overlapBehindHist,maskSize,stuffLs)
%INFERORDER Summary of this function goes here
%   Detailed explanation goes here
if(length(objLs) == 1)
    objOrder = 1;
    return;
end
bins = ceil(overlapScore*size(overlapBehindHist,3));
bins = bins-diag(diag(bins));
[r c] = find(bins>0);
ind = sub2ind(size(overlapBehindHist),objLs(r)',objLs(c)',bins(bins>0));
ovlpProb = zeros(size(bins));
ovlpProb(bins>0) = overlapBehindHist(ind);
a = bins>0 | bins'>0;a = tril(a);
[r c] = find(a);
behindP = ovlpProb(sub2ind(size(ovlpProb),r,c));
infrontP = ovlpProb(sub2ind(size(ovlpProb),c,r));
if(exist('stuffLs','var'))
    rs = ismember(objLs(r),stuffLs);
    cs = ismember(objLs(c),stuffLs);
    ind = rs==1&cs==0;
    behindP(ind) = 1;infrontP(ind) = 0;
    ind = rs==0&cs==1;
    behindP(ind) = 0;infrontP(ind) = 1;
end
if(exist('maskSize','var') && ~isempty(maskSize))
    sn = objLs(r)==objLs(c);
    if(sum(sn)>0)
        ratios = maskSize(r(sn))./maskSize(c(sn));
        infrontP(sn) = infrontP(sn).*ratios(:);
    end
end
diffP = abs(behindP-infrontP);
[mx edDir] = max([behindP infrontP], [],2);
flip = [2; 1];
inds = [edDir flip(edDir)];
rc = [r c];
e1 = rc(sub2ind(size(rc),(1:length(r))',edDir));
e2 = rc(sub2ind(size(rc),(1:length(r))',flip(edDir)));
edges = [e1 e2];
DG = sparse(edges(:,1),edges(:,2),true,length(objLs),length(objLs));
swappedList = [];
for j = 1:100
    if(graphisdag(DG))
        break;
    end
    cycles = findcycles(DG);
    cInd = randi(size(cycles),1);%pick a random cycle
    c = cycles{cInd};
    eInds = zeros(size(c));
    for i = 1:length(c)
        eInds(i) = find(e1==c(i) & e2==c(mod(i,length(c))+1));
    end
    [~,rm] = intersect(eInds,swappedList);
    if(length(rm) == length(eInds))
        swappedList = [];
    elseif(~isempty(rm))
        eInds(rm) = [];
    end
    [mn ind] = min(diffP(eInds));
    e = eInds(ind);
    edDir(e) = flip(edDir(e));
    DG(e1(e),e2(e)) = 0;
    tmp = e1(e);e1(e) = e2(e);e2(e) = tmp;
    DG(e1(e),e2(e)) = 1;
    swappedList = [swappedList e];
end
if(~graphisdag(DG))
    fprintf('Error Bad Ordering\n');
    objOrder = 1:length(objLs);
else
    %view(biograph(DG));
    order = graphtopoorder(DG);
    objOrder = zeros(size(objLs));
    for i = 1:length(order)
        l = 1+max(objOrder(DG(:,order(i))));
        if(isempty(l))
            objOrder(order(i)) = 1;
        else
            objOrder(order(i)) = l;
        end
    end
end
end

function loops = ValidateGraph(N, edges)
reachable = cell(N,1);
curCounts = zeros(N,1);
while(true)
    for i = 1:size(edges,1)
        reachable{edges(i,1)} = union(reachable{edges(i,1)},edges(i,2));
        for j = 1:N
            if(any(reachable{j}==edges(i,1)))
                reachable{j} = union(reachable{j},edges(i,2));
            end
        end
    end
    nexCounts = cellfun(@(x)length(x),reachable);
    if(all(nexCounts==curCounts))
        break;
    end
    curCounts = nexCounts;
end
valid = cellfun(@(x,y) all(x~=y),reachable,mat2cell(1:N,1,ones(N,1))');
loops = sum(~valid);
end