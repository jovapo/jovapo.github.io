SetUpConstants;

display= true;
web=false;
if(web)
    MyCleanUp;
    ObjectWebFold = fullfile(TestFold,'Web-ObjInference');
    webIndex = fullfile(ObjectWebFold,'bad.htm'); make_dir(webIndex);
    indexFID = fopen(webIndex,'w');
    fprintf(indexFID,'\n<center>\n');
    fprintf(indexFID,'\n<table border="0">\n');
    fprintf(indexFID,'\t<tr>\n');

    numCols = 6;
    colCount = 0;
end


if(isempty(testSVMList))
    foldList = dir(fullfile(TestFold,svmFold,'*.mat'));
    for i = 1:length(foldList)
        if(~foldList(i).isdir)
            [a testSVMList{end+1}] = fileparts(foldList(i).name);
        end
    end
end

[foo LabelSetFold] = fileparts(HOMELABELSETS{1});

dataFile = fullfile(TestFold,'parsingData.mat');

[fold base] = fileparts(testFileList{1});
load(fullfile(HOMELABELSETS{1},fold,[base '.mat'])); %S (ro x co) names
Labels = cell(1);Labels{1} = names;

%{-
predictedLabels = cell(size(testSVMList));
gtLabels = cell(size(testFileList));
close all;
pfig = ProgressBar('Loading SVM test data');
for f = rangeTest(:)'%[54]%[146  135 132 1 125 219 103  ]%1:500% rangeTest(:)'
    [fold base ext] = fileparts(testFileList{f});
    [foo LabelFolder] = fileparts(HOMELABELSETS{1});
    outFileName = fullfile(TestFold,testParams.MRFFold,LabelFolder,'DCRF-Sig-RetPoly0-rmStDet1-w16-w0.200-itt3',fold,[base '.mat']);
    if(exist(outFileName,'file'))
        continue;
    end
    
    if(web)
        imageToFold = fullfile(ObjectWebFold,'Images',fold,[base ext]);make_dir(imageToFold);
        copyfile(fullfile(HOME,'Images',testFileList{f}),imageToFold);
        fprintf(indexFID,'\t\t<td><center> <a href="%s">',['ImageWeb/' fold '/' base '.htm']);
        fprintf(indexFID,'<img  width="200" src="%s"></a> ',['Images/' fold '/' base ext]);
        fprintf(indexFID,'</center> </td>\n');
        colCount = colCount +1;
        if(colCount == numCols)
            colCount = 0;
            fprintf(indexFID,'\t</tr><tr>\n');
        end
        if(exist(fullfile(ObjectWebFold,'ImageWeb',fold,[base '.htm']),'file'))
            continue;
        end
    end
    
    %{
    busyFile = fullfile(TestFold,testParams.MRFFold,'BusyFiles',fold,[base '.mat']);make_dir(busyFile);
    if(exist(busyFile,'file'))
        fprintf('Busy %d: %s/%s\n',f,fold,base);
        continue;
    end
    a = 1; save(busyFile,'a');
    %}
    timingFile = fullfile(TestFold,'Timing',fold,[base '.mat']);make_dir(timingFile);
    if(exist(timingFile,'file'))
        load(timingFile);
    else
        fileStats = [];
    end
    
    fprintf('Working on %d: %s/%s\n',f,fold,base);
    
    %% Loading Code
    try
        load(fullfile(TestFold,'ExemplarDataTerm',detectorFold,fold,[base '.mat'])); %dataTerm (ro x co x #l) dataTermMax
    	load(fullfile(TestFold,'ExemplarDetectionResults',detectorFold,fold,[base '.mat'])); % test_struct polygons
        a = load(fullfile(TestFold,LabelSetFold,parserFold,fold,[base '.mat'])); %probPerLabel (#SP x #l)
        if(isfield(a,'probPerLabel'))
            probPerLabel = a.probPerLabel;
        elseif(isfield(a,'prob'))
            probPerLabel = a.prob;
        end
        load(fullfile(HOMEDATA,'Descriptors',spFold,'super_pixels',fold,[base '.mat'])); %superPixels (ro x co)
        load(fullfile(HOMEDATA,'Descriptors',spFold,'sp_adjacency',fold,[base '.mat'])); %adjPairs (pairs x 2)
        load(fullfile(HOMELABELSETS{1},fold,[base '.mat'])); %S (ro x co) names
        %load(fullfile(HOMEDESCRIPTOR,'Pb','globalPb25',fold,[base '.mat']));
        %ucm = imread(fullfile(HOMEDESCRIPTOR,'Pb','globalPb25',fold,[base '.png']));
        %[retInds rank] = FindRetrievalSet(trainGlobalDesc,SelectDesc(testGlobalDesc,f,1),TestFold,fullfile(fold,base),testParams,[]);
        clear im;
        try
            im = imread(fullfile(HOMEIMAGES,testFileList{f}));
        catch
            im = imread(fullfile(HOMEIMAGES,fold,[base '.jpg']));
        end
    catch
        continue;
    end
    %{
    rmInds = find(strcmp(trainFileList,testFileList{f}));
    [a keepInds] = setdiff(retInds,rmInds);
    keepInds = sort(keepInds);
    retInds = retInds(keepInds);
    %[gtObjDesc] = ComputeObjectDescriptors(trainFileList(retInds));
    %}
    
    uSP = unique(superPixels);
    spMap = zeros(max(uSP),1);
    spMap(uSP) = 1:length(uSP);
    feat = probPerLabel(spMap(superPixels),:);
    feat = [feat reshape(dataTerm,[],size(dataTerm,3))];
    featSP = zeros(length(uSP),size(feat,2));
    for i = 1:length(uSP)
        featSP(i,:) = mean(feat(superPixels==uSP(i),:));
    end
    label = S(:);
    %feat(label==0,:) = [];
    labelAll = label;
    label(label==0) = [];
    gtLabels{f} = label;
    labelList = names;
    numLs = length(names);    
    saveFile = fullfile(TestFold,testParams.MRFFold,LabelSetFold,'SuperParsing',fold,[base '.mat']);make_dir(saveFile);
    if(~exist(saveFile,'file'))
        [maxFeats pl] = max(feat(:,1:numLs),[],2);
        L = reshape(pl,size(superPixels));
        OutputLabeling(saveFile,L,labelList,S,names);
    end
    saveFile = fullfile(TestFold,testParams.MRFFold,LabelSetFold,'DetectorScore',fold,[base '.mat']);make_dir(saveFile);
    if(~exist(saveFile,'file'))
        [maxFeats pl] = max(feat(:,1+numLs:end),[],2);
        L = reshape(pl,size(superPixels));
        OutputLabeling(saveFile,L,labelList,S,names);
    end
    
    %% Inference
    for svmNdx = 1:2:length(testSVMList)
        predictorCell = cell(2,1);
        saveFile = cell(2,1);
        for i = svmNdx:svmNdx+1
            saveFile{i-svmNdx+1} = fullfile(TestFold,testParams.MRFFold,LabelSetFold,testSVMList{i},fold,[base '.mat']);make_dir(saveFile{i-svmNdx+1});
            pFile = fullfile(TestFold,svmFold,testSVMList{i},'Predictors',fold,[base '.mat']);
            svmFile = fullfile(TestFold,svmFold,[testSVMList{i} '.mat']);
            trainedSVM = load(svmFile);
            if(exist(pFile,'file'))
                load(pFile);
                predictorCell{i-svmNdx+1} = predictors;
            else
                if(exist(svmFile,'file'))
                    timerVar=tic;[rates, pl, predictorCell{i-svmNdx+1}] = MySVMTestInMem(feat,labelAll,trainedSVM.svm,1024^3);timerVar=toc(timerVar);
                    fileStats.(['timeSVM' num2str(i)]) = timerVar;
                    save(timingFile,'fileStats');
                end
            end
            
            [maxFeats pl] = max(predictorCell{i-svmNdx+1},[],2);
            L = reshape(pl,size(superPixels));
            OutputLabeling(saveFile{i-svmNdx+1},L,labelList,S,names);
            
            clear objDataTerms clsList;
        end
        i = 1;
        svmName = testSVMList{i};
        %predictors = predictorCell{i};
        %SmoothDetectorSVM;
        %SmoothDetectorTests;
        %clear predictors;
        ObjectEMProof;
        %OutputStuffParse;
        %TestSpatialPrior;
        %PerObjInference;
        %GeneratePerObjClusters;
    end
    ProgressBar(pfig,f,length(testFileList));
end
close(pfig);
if(web)
    fprintf(indexFID,'\t</tr>\n</table></center>');
    fclose(indexFID);
end

%}

