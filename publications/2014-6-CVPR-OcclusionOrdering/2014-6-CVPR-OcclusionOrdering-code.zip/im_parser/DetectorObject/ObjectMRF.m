function labels = ObjectMRF(in)

if(~exist('in','var'))
    in=evalin('base','in');
end

%{
in.im = im;
in.masks = masks;
in.objDataTerm = objDataTerm;
in.objLabel = objLabel;
in.overlapPixels = overlapPixels;
in.overlapScore = overlapScore;
in.overlapBehindHist = overlapBehindHist;
in.labelOrderHist = overlapStats.labelOrderHist;
in.names = names;
in.masks = masks;
in.labelColors = labelColors{1};
%}

%reduce histogram to just entry with over 1%
in.labelOrderHist = in.labelOrderHist(:,sum(in.labelOrderHist)/sum(in.labelOrderHist(:))>.01);
in.labelOrderHist = bsxfun(@rdivide,in.labelOrderHist,sum(in.labelOrderHist,2));
in.labelOrderHist(isnan(in.labelOrderHist)) = 0;

nlevels = size(in.labelOrderHist,2);
nStates = nlevels*2;
nObj = size(in.masks,1);
numBins = size(in.overlapBehindHist,3);
[ro co ch] = size(in.im);
numPix = ro*co;

zeroNodeBias = 1;
zeroEdgeBias = .3;
edgeWeight = 3;
labelTermRatio = 1;

inputMax = max(in.objDataTerm);
INTERSECT_COST = 0.01;

adj = in.overlapPixels>0;
adj = adj - diag(diag(adj));
edgeStruct = UGM_makeEdgeStruct(adj,nStates);

nodePot = ones(nObj,nStates)*zeroNodeBias;
dataTerm = in.objDataTerm.^(2-labelTermRatio) .* in.objLabelTerm.^labelTermRatio .* in.objClustScore .* sqrt(in.maskSize);
dataTerm = repmat(dataTerm,[1 nlevels]).*in.labelOrderHist(in.objLabel,1:(nlevels));
nodePot(:,2:end) = dataTerm(:,ceil(1:.5:nlevels));
%nodePot = nodePot.*repmat(log(in.maskSize),[1 nStates]);
%nodePot = nodePot./geomean(nodePot(:,1));

edgePot = ones(nStates,nStates,edgeStruct.nEdges)*zeroEdgeBias/zeroEdgeBias;
for e = 1:edgeStruct.nEdges
    n1 = edgeStruct.edgeEnds(e,1);
    n2 = edgeStruct.edgeEnds(e,2);

    bin = min(ceil(mod((numBins)*in.overlapScore(n2,n1),numBins+1)),numBins);
    %{=
    if(in.objLabel(n1) == in.objLabel(n2) && bin == size(in.overlapBehindHist,3))
        infront = INTERSECT_COST;
        behind = INTERSECT_COST;
    else
    %}
        %n1 infront of n2
        infront = in.overlapBehindHist(in.objLabel(n2),in.objLabel(n1),bin)/zeroEdgeBias;%*log(in.overlapPixels(n2,n1)+1);
        %infront = 1;
        %n1 behind n2
        behind = in.overlapBehindHist(in.objLabel(n1),in.objLabel(n2),bin)/zeroEdgeBias;%*log(in.overlapPixels(n1,n2)+1);
        %behind = 1;
    end
    edgePot(:,:,e) = edgePot(:,:,e);%*log(in.overlapPixels(n1,n2)+1);
    edgePot(2:end,2:end,e) = triu(ones(nStates-1)*behind,1)+tril(ones(nStates-1)*infront,-1)+diag(ones(nStates-1,1)*INTERSECT_COST);
    edgePot(:,:,e) = edgePot(:,:,e) .* sqrt((in.overlapPixels(n1,n2)));%./median(in.overlapPixels(in.overlapPixels>0))));%log(in.overlapPixels(n1,n2)+1);
    %fprintf('%.2f %.2f %.2f %s %s %f\n',[edgePot(2,3,e) edgePot(3,2,e)],edgePot(1,1,e),in.names{in.objLabel(n1)},in.names{in.objLabel(n2)},in.overlapScore(n2,n1));
end

edgePot = edgePot.^edgeWeight;

%edgeStruct.maxIter = int32(100);
burnIn = 100;

[m L] = max(nodePot,[],2);
%{-
initL = ones(size(L));
[curES curEP] = ComputeE(nodePot,edgePot,edgeStruct,initL);
initL(L==2) = 2;
workingL = 2;%nStates;
[curES curEP] = ComputeE(nodePot,edgePot,edgeStruct,initL);
maxItt = 2;
itt = 1;
show(in.im+80,1);
while(true)
    obj2Try = find(initL(:)'==1);
    e = ones(length(L),nStates-2)*curES;
    for objAdd = obj2Try
        for level = 1:nStates-2
            tryL = initL;
            tryL(objAdd) = level+2;
            e(objAdd,level) = ComputeE(nodePot,edgePot,edgeStruct,tryL);
        end
    end
    [m, l] = max(e(:));
    if(m>curES)
        curES = m;
        [a, b] = ind2sub(size(e),l);
        DrawObject(in,a);drawnow;
        initL(a) = b+2;
    else
        sum(initL>1)
        if(itt==maxItt)
            break;
        end
        workingL = 2;
        itt = itt+1;
    end
end
%{
while(true)
    [m l] = max(nodePot(:,workingL));
    obj2Try = find(initL(:)'==1);
    obj2Rm = [0 find(initL(:)'~=1)];
    e = ones(size(L),length(obj2Rm))*curES;
    for rmNdx = 1:length(obj2Rm)
        rmL = initL;
        if(obj2Rm(rmNdx)~=0)
            rmL(obj2Rm(rmNdx)) = 1;
        end
        for objAdd = obj2Try
            tryL = rmL;
            tryL(objAdd) = workingL;
            e(objAdd,rmNdx) = ComputeE(nodePot,edgePot,edgeStruct,tryL);
        end
    end
    [m l] = max(e(:));
    if(m>curES)
        curES = m;
        %DrawObject(in,l);
        [a b] = ind2sub(size(e),l);
        initL(a) = workingL;
    else
        %DispalyObjects(in,initL);
        workingL = workingL+1;
    end
    if(workingL==nStates)
        sum(initL>1)
        if(itt==maxItt)
            break;
        end
        workingL = 2;
        itt = itt+1;
    end
end
%}
if(isfield(in,'imFID'))
    backOutString = '../';
    if(isempty(in.fold))
        in.fold = '.';
        backOutString = '';
    else
        [fo bo] = fileparts(in.fold);
        if(~isempty(fo))
            backOutString = '../../';
        end
    end
    DispalyObjects(in,initL,1,1);
    make_dir(fullfile(in.ObjectWebFold,'ObjImages',in.fold,[in.base '-labels.jpg']));
    export_fig(fullfile(in.ObjectWebFold,'ObjImages',in.fold,[in.base '-labels.jpg']));
    fprintf(in.imFID,'<td>My Huristic Greedy Inference<br><img   src="%s"><br> Objects Assigned</td> ',[backOutString '../ObjImages/' in.fold '/' in.base '-labels.jpg']);
    DispalyObjects(in,initL,-1,1);
    export_fig(fullfile(in.ObjectWebFold,'ObjImages',in.fold,[in.base '-order.jpg']));
    fprintf(in.imFID,'<td><br><img  src="%s"><br> Order of objects (blue=far red=neer)</td> </tr><br><tr></tr><br><tr></tr><br><tr>',[backOutString '../ObjImages/' in.fold '/' in.base '-order.jpg']);
end
%}

%{
%[nodeBel{1},edgeBel,logZ] = UGM_Infer_Sample(nodePot,edgePot,edgeStruct,@UGM_Sample_Gibbs,burnIn);
[nodeBel{1},edgeBel,logZ] = UGM_Infer_LBP(nodePot,edgePot,edgeStruct);
edgeStruct.useMex = 0;
[nodeBel{2},edgeBel,logZ] = UGM_Infer_Sample(nodePot,edgePot,edgeStruct,@UGM_Sample_Gibbs,burnIn,initL);
%[nodeBel{1},edgeBel,logZ] = UGM_Infer_(nodePot,edgePot,edgeStruct);
E = zeros(size(nodeBel));
L = cell(size(nodeBel));
for i = 1:length(E)
    [e L{i}] = max(nodeBel{i},[],2);
    sum(L{i}>1)
    E(i) = sum(e);
    [potS,potP] = ComputeE(nodePot,edgePot,edgeStruct,L{i})
end
%}
L = UGM_Decode_SimAnneal(nodePot, edgePot, edgeStruct);
sum(L>1)

if(isfield(in,'imFID'))
    DispalyObjects(in,L,1,1);
    make_dir(fullfile(in.ObjectWebFold,'ObjImages',in.fold,[in.base '-sl-labels.jpg']));
    export_fig(fullfile(in.ObjectWebFold,'ObjImages',in.fold,[in.base '-sl-labels.jpg']));
    fprintf(in.imFID,'<td>Simulated Annealing<br> <img  src="%s"><br> Objects Assigned</td> ',[backOutString '../ObjImages/' in.fold '/' in.base '-sl-labels.jpg']);
    DispalyObjects(in,L,-1,1);
    export_fig(fullfile(in.ObjectWebFold,'ObjImages',in.fold,[in.base '-sl-order.jpg']));
    fprintf(in.imFID,'<td><br><img   src="%s"><br> Order of objects (blue=far red=neer)</td> </tr><tr>',[backOutString '../ObjImages/' in.fold '/' in.base '-sl-order.jpg']);
end


function [potS,potP] = ComputeE(nodePot,edgePot,edgeStruct,L)
    % Nodes
    [ind] = sub2ind(size(nodePot),1:double(edgeStruct.nNodes),L(:)');
    potS = sum(log(nodePot(ind)));
    if(nargout>1)
        potP = prod(nodePot(ind));
    end

    n1 = edgeStruct.edgeEnds(:,1);
    n2 = edgeStruct.edgeEnds(:,2);
    [ind] = sub2ind(size(edgePot),L(n1)',L(n2)',1:edgeStruct.nEdges);
    potS = potS+sum(log(edgePot(ind)));
    if(nargout>1)
        potP = potP*prod(edgePot(ind));
    end


function DispalyObjects(in,L,mode,figNo)
    if(~exist('mode','var'))
        mode = 0;
    end
    if(~exist('figNo','var'))
        figNo = 1;
    end
    [ro co ch] = size(in.im);
    [a, objOrder] = sort(L);
    objOrder(a<=1) = [];
    if(mode>=0)
        show(in.im,figNo);hold on;
        for i = objOrder(:)'
            b = bwboundaries(reshape(in.masks(i,:),[ro co]));
            patch(b{1}(:,2),b{1}(:,1),'r','FaceColor','none','EdgeColor',in.labelColors(in.objLabel(i),:),'LineWidth',2);
        end
        legend(in.names(in.objLabel(objOrder)));hold off;
    end

    if(mode==0)
        show(in.im,figNo+1);hold on;
    elseif(mode<0)
        show(in.im,figNo);hold on;
    end
    if(mode<=0)
        orderColors = jet(max(L)-1);
        for i = objOrder(:)'
            b = bwboundaries(reshape(in.masks(i,:),[ro co]));
            patch(b{1}(:,2),b{1}(:,1),'r','FaceColor','none','EdgeColor',orderColors(L(i)-1,:),'LineWidth',2);
        end
        hold off;
    end
    drawnow;

function DrawObject(in,i)
    b = bwboundaries(reshape(in.masks(i,:),[size(in.im,1) size(in.im,2)]));
    patch(b{1}(:,2),b{1}(:,1),'r','FaceColor','none','EdgeColor',in.labelColors(in.objLabel(i),:),'LineWidth',2);

