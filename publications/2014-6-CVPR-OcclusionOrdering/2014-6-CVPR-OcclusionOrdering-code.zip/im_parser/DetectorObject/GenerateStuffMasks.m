function [masks classes] = GenerateStuffMasks(L)

ls = unique(L);
SE = strel('disk', 3,0);

masks = cell(0,0,0);
classes = [];

for l = ls(:)'
    mask = L==l;
    mask = imdilate(mask,SE);
    mask = imerode(mask,SE);
    CC = bwconncomp(mask);
    for i = 1:CC.NumObjects
        if(length(CC.PixelIdxList{i})<500)
            continue;
        end
        masks{1,1,end+1} = false(size(mask));
        masks{1,1,end}(CC.PixelIdxList{i}) = true;
        classes(end+1,1) = l;
    end
end

masks = cell2mat(masks);